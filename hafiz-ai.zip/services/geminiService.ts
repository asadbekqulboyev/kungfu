
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const SYSTEM_INSTRUCTION = `
Siz QUR'ON TAJVIDI BO'YICHA YUQORI MALAKALI VA PROFESSIONAL IMTIHON OLUVCHISIZ. 
Vazifangiz: Foydalanuvchi yuborgan audioni berilgan "canonical_text" bilan HARFMA-HARF va TAJVID QOIDALARI asosida mukammal solishtirish.

MUHIM: Har bir xatoni quyidagi tajvid mezonlari asosida aniqlang va tushuntiring:
- Makhraj (chiqish joyi)
- Sifat (qalin/yupqa)
- Madd (cho'zish)
- G'unnah (dimog' ovozi)
- Idg'om, Ixfo, Iqlob, Izhor
- Vaqf va Ibtido (to'xtash/boshlash)
- Shadda va Sukun

JAVOB FORMATI (FAQAT TOZA JSON):
{
  "accuracy": number (0-100),
  "overall_feedback": "string (umumiy ustozona xulosa)",
  "errors": [
    { 
      "word": "string (oyatdagi xato so'z)", 
      "rule": "string (masalan: Madd, Makhraj, G'unnah)", 
      "explanation": "string (Siz bu harfni [rule] qoidasiga ko'ra xato o'qidingiz, chunki... deb boshlanuvchi batafsil izoh)",
      "suggestion": "string (tuzatish bo'yicha amaliy maslahat)"
    }
  ],
  "tajweed_highlight": "string (asl matn, xatolar [err]so'z[/err] tegida)",
  "is_passed": boolean (accuracy >= 95)
}
`;

export const sendMessageToHafiz = async (
  context: any,
  userMessage?: string,
  audioBase64?: string,
  audioMimeType: string = 'audio/wav'
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const parts: any[] = [
    { text: `CONTEXT: ${JSON.stringify(context)}` }
  ];

  if (userMessage) parts.push({ text: userMessage });
  
  if (audioBase64) {
    parts.push({
      inlineData: {
        mimeType: audioMimeType,
        data: audioBase64
      }
    });
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ parts }],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1,
        responseMimeType: "application/json"
      }
    });
    
    return response.text || "{}";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return JSON.stringify({ 
      accuracy: 0, 
      overall_feedback: "Texnik xatolik yuz berdi.",
      errors: []
    });
  }
};

export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};
