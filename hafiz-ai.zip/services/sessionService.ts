
import { Language } from '../types';

export interface SessionConfig {
  userId?: string | null;
  language: Language;
  mode: 'student' | 'teacher' | 'kids';
  reciter?: string;
}

export interface SessionResponse {
  sessionId: string;
  token: string;
  hafizUrl?: string;
  mode: string;
}

/**
 * Initiates an AI Hafiz session.
 * Mocks a POST /api/hafiz/session call.
 */
export const createHafizSession = async (config: SessionConfig): Promise<SessionResponse> => {
  // In a real app, this would be:
  // const response = await fetch('/api/hafiz/session', { method: 'POST', body: JSON.stringify(config) ... });
  
  // Simulation of network delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock Success Response
  return {
    sessionId: `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    token: `jwt_mock_${Date.now()}`,
    mode: config.mode,
    // hafizUrl: 'https://hafiz-ai-webapp.com' // Optional, if external
  };
};
