
import { Surah, Ayah, User } from '../types';

const QURAN_API = 'https://api.alquran.cloud/v1';
const BACKEND_URL = 'http://localhost:5000'; // Assume local backend as per files

const getHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
};

export const quranService = {
  getSurahs: async (): Promise<Surah[]> => {
    try {
      const res = await fetch(`${QURAN_API}/surah`);
      const data = await res.json();
      return data.data || [];
    } catch (error) {
      console.error("Quran API error:", error);
      return [];
    }
  },
  getSurahAyahs: async (surahNum: number, edition: string = 'quran-uthmani'): Promise<Ayah[]> => {
    try {
      const res = await fetch(`${QURAN_API}/surah/${surahNum}/${edition}`);
      const data = await res.json();
      return data.data?.ayahs || [];
    } catch (error) {
      console.error("Quran Ayahs error:", error);
      return [];
    }
  }
};

export const hifzService = {
  savePlan: async (planData: any) => {
    try {
      const res = await fetch(`${BACKEND_URL}/hifz/plan`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(planData)
      });
      return await res.json();
    } catch (error) {
      console.warn("Backend save failed, using fallback");
      localStorage.setItem('cached_hifz_plan', JSON.stringify(planData));
      return { success: true, plan: planData };
    }
  },
  getPlan: async () => {
    try {
      const res = await fetch(`${BACKEND_URL}/hifz/plan`, {
        headers: getHeaders()
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      return data.plan;
    } catch (error) {
      const cached = localStorage.getItem('cached_hifz_plan');
      return cached ? JSON.parse(cached) : null;
    }
  },
  saveProgress: async (surahNumber: number, ayahNumber: number, status: string) => {
    try {
      const res = await fetch(`${BACKEND_URL}/hifz/progress`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ surahNumber, ayahNumber, status })
      });
      return await res.json();
    } catch (error) {
      console.warn("Progress save failed");
    }
  }
};

export const authService = {
  register: async (userData: any): Promise<User> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: 'demo-id-' + Math.random(),
          name: userData.name || 'Mehmon',
          phone: userData.phone,
          role: 'student'
        });
      }, 500);
    });
  },
  login: async (credentials: any): Promise<User> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: 'demo-id',
          name: 'Demo Foydalanuvchi',
          phone: credentials.phone,
          role: 'student'
        });
      }, 500);
    });
  }
};
