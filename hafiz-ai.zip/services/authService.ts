
// Use a placeholder URL or your actual backend URL
const API_URL = 'http://localhost:5000/auth'; 

// Mock user for fallback
const MOCK_USER = {
  _id: 'mock_user_id',
  name: 'Demo User',
  phone: '+998901234567',
  language: 'uz',
  avatar: null
};

export const authService = {
  // Register (Send OTP)
  register: async (phone: string, name: string) => {
    try {
      const response = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, name }),
      });
      if (!response.ok) throw new Error('Network response was not ok');
      return await response.json();
    } catch (error) {
      console.warn("Backend unreachable, using mock data for Register");
      await new Promise(resolve => setTimeout(resolve, 800));
      return { success: true, message: 'OTP sent (Mock)' };
    }
  },

  // Login (Send OTP)
  login: async (phone: string) => {
    try {
      const response = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      if (!response.ok) throw new Error('Network response was not ok');
      return await response.json();
    } catch (error) {
      console.warn("Backend unreachable, using mock data for Login");
      await new Promise(resolve => setTimeout(resolve, 800));
      return { success: true, message: 'OTP sent (Mock)' };
    }
  },

  // Verify OTP
  verifyOtp: async (phone: string, code: string, name?: string) => {
    try {
      const response = await fetch(`${API_URL}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, code, name }),
      });
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      if (data.token) {
        localStorage.setItem('token', data.token);
      }
      return data;
    } catch (error) {
      console.warn("Backend unreachable, using mock data for Verify");
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const mockToken = `mock_jwt_${Date.now()}`;
      localStorage.setItem('token', mockToken);
      
      return {
        success: true,
        token: mockToken,
        user: { ...MOCK_USER, phone, name: name || MOCK_USER.name }
      };
    }
  },

  // Resend OTP
  resendOtp: async (phone: string) => {
    try {
      const response = await fetch(`${API_URL}/resend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      return await response.json();
    } catch (error) {
      console.warn("Backend unreachable, using mock data for Resend");
      return { success: true, message: 'OTP resent (Mock)' };
    }
  },

  // Google Login
  googleLogin: async (googleData: { token?: string, email: string, name: string, picture?: string, googleId: string }) => {
    try {
      // Sends Google data to OUR backend to save in MongoDB
      const response = await fetch(`${API_URL}/google`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(googleData),
      });
      
      if (!response.ok) throw new Error("Backend google auth failed");

      const data = await response.json();
      if (data.token) {
        localStorage.setItem('token', data.token);
      }
      return data;
    } catch (error) {
      console.warn("Backend unreachable, using mock data for Google Login");
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const mockToken = `mock_jwt_google_${Date.now()}`;
      localStorage.setItem('token', mockToken);
      
      return {
        success: true,
        token: mockToken,
        user: {
          _id: 'google_user_id',
          name: googleData.name,
          email: googleData.email,
          avatar: googleData.picture,
          language: 'uz'
        }
      };
    }
  },

  // Get Profile
  getProfile: async () => {
    const token = localStorage.getItem('token');
    if (!token) throw new Error("No token");

    try {
      const response = await fetch(`${API_URL}/profile`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) throw new Error("Failed to fetch profile");
      return await response.json();
    } catch (error) {
      console.warn("Backend unreachable, returning mock profile");
      return {
        success: true,
        user: MOCK_USER
      };
    }
  },

  logout: () => {
    localStorage.removeItem('token');
  }
};
