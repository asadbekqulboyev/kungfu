
import { Surah, CombinedAyahData, Language } from '../types';

const BASE_URL = 'https://api.alquran.cloud/v1';

export const fetchSurahList = async (): Promise<Surah[]> => {
  try {
    const response = await fetch(`${BASE_URL}/surah`);
    const data = await response.json();
    return data.data || [];
  } catch (error) {
    console.error("Failed to fetch surah list", error);
    return [];
  }
};

/**
 * Oyatning uzunligiga qarab uning 'vaznini' hisoblaydi.
 * O'rtacha 50 ta belgi = 1 vazn birligi.
 */
export const calculateAyahWeight = (text: string): number => {
  if (!text) return 1;
  const len = text.length;
  return Math.max(0.5, len / 60); 
};

export const JUZ_MAPPING: Record<number, { surah: number, ayah: number }> = {
  1: { surah: 1, ayah: 1 }, 2: { surah: 2, ayah: 142 }, 3: { surah: 2, ayah: 253 },
  4: { surah: 3, ayah: 93 }, 5: { surah: 4, ayah: 24 }, 6: { surah: 4, ayah: 148 },
  7: { surah: 5, ayah: 82 }, 8: { surah: 6, ayah: 111 }, 9: { surah: 7, ayah: 88 },
  10: { surah: 8, ayah: 41 }, 11: { surah: 9, ayah: 93 }, 12: { surah: 11, ayah: 6 },
  13: { surah: 12, ayah: 53 }, 14: { surah: 15, ayah: 1 }, 15: { surah: 17, ayah: 1 },
  16: { surah: 18, ayah: 75 }, 17: { surah: 21, ayah: 1 }, 18: { surah: 23, ayah: 1 },
  19: { surah: 25, ayah: 21 }, 20: { surah: 27, ayah: 56 }, 21: { surah: 29, ayah: 46 },
  22: { surah: 33, ayah: 31 }, 23: { surah: 36, ayah: 28 }, 24: { surah: 39, ayah: 32 },
  25: { surah: 41, ayah: 47 }, 26: { surah: 46, ayah: 1 }, 27: { surah: 51, ayah: 31 },
  28: { surah: 58, ayah: 1 }, 29: { surah: 67, ayah: 1 }, 30: { surah: 78, ayah: 1 }
};

export const fetchSurahData = async (surahNumber: number, lang: Language, reciterId: string = 'ar.alafasy'): Promise<CombinedAyahData[]> => {
  try {
    const translationId = lang === Language.UZ ? 'uz.sodik' : 'en.sahih';
    const tafsirId = 'ar.muyassar'; 
    const tajweedId = 'quran-tajweed'; 
    
    const response = await fetch(
      `${BASE_URL}/surah/${surahNumber}/editions/quran-uthmani,${tajweedId},${translationId},${reciterId},${tafsirId}`
    );
    const data = await response.json();
    if (!data.data || !Array.isArray(data.data)) return [];

    const arabicData = data.data.find((d: any) => d.edition.identifier === 'quran-uthmani')?.ayahs;
    const tajweedData = data.data.find((d: any) => d.edition.identifier === tajweedId)?.ayahs;
    const transData = data.data.find((d: any) => d.edition.identifier === translationId)?.ayahs;
    const audioData = data.data.find((d: any) => d.edition.identifier === reciterId)?.ayahs;
    const tafsirData = data.data.find((d: any) => d.edition.identifier === 'ar.muyassar')?.ayahs;

    return arabicData.map((ayah: any, index: number) => ({
      number: ayah.number,
      numberInSurah: ayah.numberInSurah,
      text: ayah.text,
      tajweed: tajweedData?.[index]?.text || ayah.text,
      translation: transData?.[index]?.text || '',
      audioUrl: audioData?.[index]?.audio || '',
      tafsir: tafsirData?.[index]?.text || ''
    }));
  } catch (error) {
    console.error("Failed to fetch surah details", error);
    return [];
  }
};

// Fixed: Added missing fetchWordTimings function used in Learning and KidsLesson components
export const fetchWordTimings = async (text: string, duration: number): Promise<any[]> => {
  const words = text.split(' ');
  const wordDuration = duration / (words.length || 1);
  return words.map((word, i) => ({
    id: i,
    word,
    start: i * wordDuration,
    end: (i + 1) * wordDuration
  }));
};

// Fixed: Added missing calculateAyahTimeRange function used in Testing component
export const calculateAyahTimeRange = (text: string): { min: number, max: number } => {
  const words = text.split(' ').length;
  // Standard tajweed pace is roughly 1.5 to 3 seconds per word
  return {
    min: Math.max(3, Math.floor(words * 1.5)),
    max: Math.ceil(words * 4.5)
  };
};
