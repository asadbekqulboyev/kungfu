
// Fix: Added missing properties (language, format, type) to mock edition objects to fully satisfy the Edition interface and resolve type mismatch in components.
import { Edition } from '../types';

const BASE_URL = 'https://api.alquran.cloud/v1';

export const fetchSurahs = async () => {
  try {
    const res = await fetch(`${BASE_URL}/surah`);
    const data = await res.json();
    return data.data || [];
  } catch (error) {
    console.error("fetchSurahs error:", error);
    return [];
  }
};

export const fetchSurahDetail = async (surahNumber: number, edition: string = 'quran-uthmani') => {
  try {
    const res = await fetch(`${BASE_URL}/surah/${surahNumber}/${edition}`);
    const data = await res.json();
    return data.data || null;
  } catch (error) {
    console.error("fetchSurahDetail error:", error);
    return null;
  }
};

export const fetchAyahAudio = async (ayahNumber: number, edition: string) => {
  try {
    const res = await fetch(`${BASE_URL}/ayah/${ayahNumber}/${edition}`);
    const data = await res.json();
    return data.data || null;
  } catch (error) {
    console.error("fetchAyahAudio error:", error);
    return null;
  }
};

export const getEditions = async (): Promise<Edition[]> => {
  // Mashhur qorilar ro'yxati (List of famous reciters supported by alquran.cloud Ayah Audio API)
  return [
    { 
      identifier: 'ar.alafasy', 
      name: 'Mishary Rashid Alafasy', 
      englishName: 'Alafasy',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.husary', 
      name: 'Mahmoud Khalil Al-Husary', 
      englishName: 'Husary',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.minshawi', 
      name: 'Mohamed Siddiq El-Minshawi', 
      englishName: 'Minshawi',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.abdulsamad', 
      name: 'Abdulbasit Abdulsamad', 
      englishName: 'AbdulSamad',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.abdurrahmansudais', 
      name: 'Abdurrahman As-Sudais', 
      englishName: 'Sudais',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.mahermuaiqly', 
      name: 'Maher Al Muaiqly', 
      englishName: 'Muaiqly',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.shatree', 
      name: 'Abu Bakr Al-Shatri', 
      englishName: 'Shatri',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    },
    { 
      identifier: 'ar.ajamy', 
      name: 'Ahmed Ibn Ali Al-Ajamy', 
      englishName: 'Ajamy',
      language: 'ar',
      format: 'audio',
      type: 'versebyverse'
    }
  ];
};
