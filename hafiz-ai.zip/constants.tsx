
import React from 'react';

export const SURAHS_LIST: any[] = [
  { "number": 1, "name": "سُورَةُ ٱلْفَاتِحَةِ", "englishName": "Al-Faatiha", "englishNameTranslation": "The Opening", "numberOfAyahs": 7, "revelationType": "Meccan" },
  { "number": 2, "name": "سُورَةُ ٱلْبَقَرَةِ", "englishName": "Al-Baqara", "englishNameTranslation": "The Cow", "numberOfAyahs": 286, "revelationType": "Medinan" },
  { "number": 18, "name": "سُورَةُ ٱلْكَهْفِ", "englishName": "Al-Kahf", "englishNameTranslation": "The Cave", "numberOfAyahs": 110, "revelationType": "Meccan" },
  { "number": 36, "name": "سُورَةُ يسٓ", "englishName": "Yaseen", "englishNameTranslation": "Ya Seen", "numberOfAyahs": 83, "revelationType": "Meccan" },
  { "number": 55, "name": "سُورَةُ ٱلرَّحْمَٰنِ", "englishName": "Ar-Rahmaan", "englishNameTranslation": "The Beneficent", "numberOfAyahs": 78, "revelationType": "Meccan" },
  { "number": 67, "name": "سُورَةُ ٱلْمُلْكِ", "englishName": "Al-Mulk", "englishNameTranslation": "The Sovereignty", "numberOfAyahs": 30, "revelationType": "Meccan" },
  { "number": 112, "name": "سُورَةُ ٱلْإِخْلَاصِ", "englishName": "Al-Ikhlaas", "englishNameTranslation": "Purity of Faith", "numberOfAyahs": 4, "revelationType": "Meccan" },
  { "number": 113, "name": "سُورَةُ ٱلْفَلَقِ", "englishName": "Al-Falaq", "englishNameTranslation": "The Daybreak", "numberOfAyahs": 5, "revelationType": "Meccan" },
  { "number": 114, "name": "سُورَةُ ٱلنَّاسِ", "englishName": "An-Naas", "englishNameTranslation": "Mankind", "numberOfAyahs": 6, "revelationType": "Meccan" }
];

export const APP_THEME = {
  primary: 'emerald-800',
  secondary: 'emerald-600',
  accent: 'amber-500',
  background: 'slate-50',
};
