
import { TAJWID_MAP } from "./tajweedMap";

const isDigit = (char: string) => /\d/.test(char);

export function parseTajweed(text: string): string {
  if (!text) return "";

  let result = "";
  let i = 0;

  // Avval [err]...[/err] teglarini qayta ishlaymiz
  if (text.includes('[err]')) {
    text = text.replace(/\[err\](.*?)\[\/err\]/g, '<span class="error_word" style="color:#FF0000; border-bottom: 2px dashed #FF0000; padding-bottom: 2px;">$1</span>');
  }

  while (i < text.length) {
    if (text[i] === "[" && text[i+1] !== 'e' && i + 1 < text.length && /[a-z]/.test(text[i+1])) {
      const code = text[i+1];
      const rule = TAJWID_MAP[code];
      
      if (!rule) {
        result += text[i];
        i++;
        continue;
      }

      i += 2;
      if (text[i] === ":") {
        i++;
        while (i < text.length && isDigit(text[i])) i++;
      }

      if (text[i] === "[") i++;

      let startContent = i;
      let depth = 1;
      while (i < text.length && depth > 0) {
        if (text[i] === "[") depth++;
        else if (text[i] === "]") depth--;
        if (depth > 0) i++;
      }

      const innerContent = text.substring(startContent, i);
      const parsedInner = parseTajweed(innerContent);
      
      result += `<span class="${rule.class}" style="color:${rule.color}">${parsedInner}</span>`;
      i++;
    } else {
      result += text[i];
      i++;
    }
  }

  return result;
}

export function parseTajweedAndWrap(encodedText: string): string {
  if (!encodedText) return "";

  // [err]...[/err] teglari orasidagi so'zlar bo'shliq bilan bo'linib ketmasligi uchun vaqtincha maskalash
  const maskedText = encodedText.replace(/\[err\](.*?)\[\/err\]/g, (match) => match.replace(/\s/g, '___'));
  
  const words: string[] = [];
  let currentWord = "";
  let depth = 0;

  for (let i = 0; i < maskedText.length; i++) {
    const char = maskedText[i];
    if (char === "[") depth++;
    else if (char === "]") depth--;

    if (char === " " && depth === 0) {
      if (currentWord.trim()) words.push(currentWord.replace(/___/g, ' '));
      currentWord = "";
    } else {
      currentWord += char;
    }
  }
  if (currentWord.trim()) words.push(currentWord.replace(/___/g, ' '));

  return words.map((wordCode, index) => {
    const parsedHtml = parseTajweed(wordCode);
    return `<span class="word" data-word-id="${index}">${parsedHtml}</span>`;
  }).join(" ");
}
