
export const TAJWID_MAP: Record<string, { class: string; color: string }> = {
  h: { class: "ham_wasl",          color: "#AAAAAA" },
  s: { class: "slnt",              color: "#AAAAAA" },
  l: { class: "slnt",              color: "#AAAAAA" },
  n: { class: "madda_normal",      color: "#537FFF" },
  p: { class: "madda_permissible", color: "#4050FF" },
  m: { class: "madda_necessary",   color: "#000EBC" },
  o: { class: "madda_obligatory",  color: "#2144C1" },
  q: { class: "qlq",               color: "#DD0008" },
  c: { class: "ikhf_shfw",         color: "#D500B7" },
  f: { class: "ikhf",              color: "#9400A8" },
  w: { class: "idghm_shfw",        color: "#58B800" },
  i: { class: "iqlb",              color: "#26BFFD" },
  a: { class: "idgh_ghn",          color: "#169777" },
  u: { class: "idgh_w_ghn",        color: "#169200" },
  d: { class: "idgh_mus",          color: "#A1A1A1" },
  b: { class: "idgh_mus",          color: "#A1A1A1" },
  g: { class: "ghn",               color: "#FF7E1E" },
  err: { class: "error_word",      color: "#FF0000" } // Yangi: Xatolar uchun qizil rang
};
