
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';
import { User } from './models';

const app = express();
app.use(cors());
// Fixed: Explicitly cast express.json() to resolve "No overload matches this call" error in strict TypeScript environments
app.use(express.json() as any);

const MONGO_URI = 'mongodb+srv://user:pass@cluster.mongodb.net/hafiz?retryWrites=true&w=majority';
const JWT_SECRET = 'your-very-secret-key';

mongoose.connect(MONGO_URI).then(() => console.log('MongoDB Atlas connected'));

// Auth Routes
app.post('/auth/register', async (req, res) => {
  try {
    const { name, phone, password } = req.body;
    const user = new User({ name, phone, password });
    await user.save();
    const token = jwt.sign({ id: user._id }, JWT_SECRET);
    res.json({ id: user._id, name, phone, token });
  } catch (err) {
    res.status(400).json({ error: 'Foydalanuvchi allaqachon mavjud' });
  }
});

app.post('/auth/login', async (req, res) => {
  const { phone, password } = req.body;
  const user = await User.findOne({ phone, password });
  if (user) {
    const token = jwt.sign({ id: user._id }, JWT_SECRET);
    res.json({ id: user._id, name: user.name, phone: user.phone, token });
  } else {
    res.status(401).json({ error: 'Telefon yoki parol xato' });
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
