
/**
 * SAMPLE BACKEND CODE (Node.js / Express)
 * 
 * This file demonstrates how the session creation endpoint would be implemented
 * on the server side to handle the POST /api/hafiz/session request.
 */

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken'); // Assuming JWT usage
const { v4: uuidv4 } = require('uuid');

// Mock Database/Service
const db = {
  createSession: async (userId, config) => {
    return {
      id: uuidv4(),
      userId,
      startTime: new Date(),
      config
    };
  }
};

/**
 * POST /api/hafiz/session
 * Initialize a new AI Tutor session
 */
router.post('/session', async (req, res) => {
  try {
    const { userId, language, mode, reciter } = req.body;

    // 1. Validation
    if (!['uz', 'en'].includes(language)) {
      return res.status(400).json({ error: 'Invalid language' });
    }

    // 2. Default Configuration
    const sessionConfig = {
      language: language || 'uz',
      mode: mode || 'student',
      reciter: reciter || 'ar.alafasy', // Default reciter
      features: {
        tajweedAnalysis: true,
        memorizationTracking: true,
        kidsMode: mode === 'kids'
      }
    };

    // 3. Create Session in DB
    const session = await db.createSession(userId || 'guest', sessionConfig);

    // 4. Generate Access Token for Session
    const token = jwt.sign(
      { sessionId: session.id, userId, role: sessionConfig.mode },
      process.env.JWT_SECRET || 'secret_key',
      { expiresIn: '2h' }
    );

    // 5. Response
    return res.status(201).json({
      success: true,
      sessionId: session.id,
      token: token,
      mode: sessionConfig.mode,
      // Optional: URL if the AI tutor is hosted on a separate subdomain
      // hafizUrl: `https://app.hafiz.ai/room/${session.id}` 
    });

  } catch (error) {
    console.error('Session creation failed:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
