import React, { useState, useEffect, useRef } from 'react';
import { AppMode, Language, Surah } from './types.ts';
import { quranService } from './services/api.ts';
import Learning from './components/Learning.tsx';
import Testing from './components/Testing.tsx';
import AnalysisView from './components/AnalysisView.tsx';
import UstozChat from './components/UstozChat.tsx';
import UstozPanel from './components/UstozPanel.tsx';
import AdminPanel from './components/AdminPanel.tsx';
import HifzPlanView from './components/HifzPlanView.tsx';
import TajweedRulesView from './components/TajweedRulesView.tsx';
import LandingPage from './components/LandingPage.tsx';
import AuthPage from './components/auth/AuthPage.tsx';
import IntroVideo from './components/IntroVideo.tsx';
import { 
  Book, MessageCircle, UserCheck, Search, Menu, X, 
  Calendar, ShieldCheck, Settings, 
  ChevronDown, LayoutGrid
} from 'lucide-react';
import { getSurahNameUz, getSurahMeaningUz } from './utils/quranUtils.ts';

const App: React.FC = () => {
  const [showIntro, setShowIntro] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('token'));
  const [showLanding, setShowLanding] = useState(true);
  
  const [currentSurah, setCurrentSurah] = useState<Surah | null>(null);
  const [currentAyahIdx, setCurrentAyahIdx] = useState(0);
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [mode, setMode] = useState<AppMode>(AppMode.TEACHING);
  const [language, setLanguage] = useState<Language>(Language.UZ);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAyahPickerOpen, setIsAyahPickerOpen] = useState(false);

  const ayahPickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const data = await quranService.getSurahs();
        if (data && data.length > 0) {
          setSurahs(data);
          setCurrentSurah(data[0]);
        }
      } catch (err) { 
        console.error("Failed to load surahs:", err); 
      }
      setLoading(false);
    };
    loadData();
  }, []);

  const handleStartFromPlan = (surahNum: number, ayahIdx: number) => {
    const found = surahs.find(s => s.number === surahNum);
    if (found) {
      setCurrentSurah(found);
      setCurrentAyahIdx(ayahIdx);
      setMode(AppMode.TEACHING);
    }
  };

  const NavItems = [
    { mode: AppMode.TEACHING, label: "Dars", icon: Book },
    { mode: AppMode.HIFZ_PLAN, label: "Reja", icon: Calendar },
    { mode: AppMode.TAJWEED_RULES, label: "Qoidalar", icon: ShieldCheck },
    { mode: AppMode.ANALYSIS, label: "Qidiruv", icon: Search },
    { mode: AppMode.USTOZ_CHAT, label: "Ustoz Chat", icon: MessageCircle },
    { mode: AppMode.USTOZ_PANEL, label: "Ustoz Paneli", icon: UserCheck },
    { mode: AppMode.ADMIN, label: "Admin", icon: Settings }
  ];

  const BottomNavItems = [
    { mode: AppMode.TEACHING, label: "Dars", icon: Book },
    { mode: AppMode.TAJWEED_RULES, label: "Qoidalar", icon: ShieldCheck },
    { mode: AppMode.ANALYSIS, label: "Qidiruv", icon: Search },
    { mode: AppMode.USTOZ_CHAT, label: "Chat", icon: MessageCircle },
    { mode: AppMode.USTOZ_PANEL, label: "Panel", icon: UserCheck },
    { mode: AppMode.ADMIN, label: "Admin", icon: Settings }
  ];

  if (showIntro) {
    return <IntroVideo onComplete={() => setShowIntro(false)} />;
  }

  if (showLanding) {
    return (
      <LandingPage 
        language={language} 
        setLanguage={setLanguage} 
        onModeChange={(m) => { 
          setMode(m); 
          setShowLanding(false); 
        }} 
      />
    );
  }

  if (!isAuthenticated) {
    return (
      <AuthPage 
        language={language} 
        onSuccess={() => setIsAuthenticated(true)} 
      />
    );
  }

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden font-sans relative">
      <aside className={`fixed inset-y-0 left-0 z-[200] w-[280px] bg-white border-r border-slate-100 transform transition-transform duration-300 lg:relative lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}>
        <div className="p-5 border-b border-slate-50 flex items-center justify-between h-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-black text-xl">H</div>
            <h1 className="text-sm font-black text-slate-800 uppercase tracking-tighter">Hafiz AI</h1>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400"><X /></button>
        </div>
        
        <div className="flex-1 overflow-y-auto h-[calc(100vh-80px)] scrollbar-hide pb-20">
          <div className="px-6 py-4 text-[8px] font-black text-slate-300 uppercase tracking-[0.3em]">Bo'limlar</div>
          <div className="px-2 space-y-1">
             {NavItems.map(item => (
               <button key={item.label} onClick={() => { setMode(item.mode); setIsSidebarOpen(false); }} className={`w-full px-4 py-3 flex items-center gap-3 rounded-xl transition-all ${mode === item.mode ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>
                 <item.icon size={18} />
                 <span className="text-[11px] font-black uppercase tracking-widest">{item.label}</span>
               </button>
             ))}
          </div>

          <div className="px-6 py-6 text-[8px] font-black text-slate-300 uppercase tracking-[0.3em]">Suralar</div>
          {surahs.map(s => (
            <button key={s.number} onClick={() => { setCurrentSurah(s); setCurrentAyahIdx(0); setMode(AppMode.TEACHING); setIsSidebarOpen(false); }} className={`w-full px-6 py-4 flex flex-col border-b border-slate-50 transition-all ${currentSurah?.number === s.number && (mode === AppMode.TEACHING || mode === AppMode.TESTING) ? 'bg-emerald-50 border-l-4 border-l-emerald-600' : 'hover:bg-slate-50'}`}>
              <div className="flex items-center justify-between w-full">
                <div className="text-left">
                  <div className="font-black text-[11px] text-slate-700 leading-tight">{getSurahNameUz(s.englishName)}</div>
                  <div className="text-[8px] text-slate-400 font-bold uppercase">{getSurahMeaningUz(s.englishName)}</div>
                </div>
                <div className="arabic-font text-sm text-emerald-800/30">{s.name}</div>
              </div>
            </button>
          ))}
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-white relative h-full">
        <header className="fixed top-0 left-0 right-0 lg:left-[280px] px-3 md:px-6 py-3 border-b border-slate-100 flex items-center justify-between bg-white/95 backdrop-blur-xl z-[150] h-16 md:h-20">
          <div className="flex items-center gap-2 md:gap-4 min-w-0 flex-1">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-1.5 bg-slate-50 rounded-lg text-slate-600 shrink-0"><Menu size={18} /></button>
            <div className="flex flex-col min-w-0">
              <h2 className="text-[12px] md:text-base font-black text-slate-800 leading-none truncate max-w-[80px] md:max-w-none">
                {mode === AppMode.HIFZ_PLAN ? 'Reja' : currentSurah ? getSurahNameUz(currentSurah.englishName) : 'Hafiz AI'}
              </h2>
              {currentSurah && (mode === AppMode.TEACHING || mode === AppMode.TESTING) && (
                <span className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Sura {currentSurah.number}</span>
              )}
            </div>
          </div>

          {currentSurah && (mode === AppMode.TEACHING || mode === AppMode.TESTING) && (
            <div className="flex bg-slate-100 p-0.5 md:p-1 rounded-xl md:rounded-2xl shrink-0 mx-2 md:mx-4">
              <button 
                onClick={() => setMode(AppMode.TEACHING)}
                className={`px-3 py-1.5 md:px-6 md:py-2 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-tight md:tracking-widest transition-all ${mode === AppMode.TEACHING ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Dars
              </button>
              <button 
                onClick={() => setMode(AppMode.TESTING)}
                className={`px-3 py-1.5 md:px-6 md:py-2 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-tight md:tracking-widest transition-all ${mode === AppMode.TESTING ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Sinov
              </button>
            </div>
          )}

          {currentSurah && (mode === AppMode.TEACHING || mode === AppMode.TESTING) && (
            <div className="relative" ref={ayahPickerRef}>
              <button 
                onClick={() => setIsAyahPickerOpen(!isAyahPickerOpen)}
                className="flex items-center gap-1 md:gap-2 px-2 py-1.5 md:px-4 md:py-3 bg-emerald-50 text-emerald-700 rounded-xl font-black text-[10px] md:text-xs uppercase tracking-tight md:tracking-widest hover:bg-emerald-100 transition-all shadow-sm border border-emerald-100 shrink-0"
              >
                <LayoutGrid size={12} className="hidden md:block" />
                <span>{currentAyahIdx + 1}-oyat</span>
                <ChevronDown size={12} className={`transition-transform ${isAyahPickerOpen ? 'rotate-180' : ''}`} />
              </button>

              {isAyahPickerOpen && (
                <div className="absolute top-full right-0 mt-3 w-[260px] md:w-[400px] bg-white rounded-3xl shadow-2xl border border-slate-100 p-5 animate-in slide-in-from-top-2 z-[300]">
                  <div className="flex items-center justify-between mb-4 border-b border-slate-50 pb-3">
                    <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Oyatga o'tish</h4>
                    <button onClick={() => setIsAyahPickerOpen(false)} className="text-slate-300 hover:text-slate-500"><X size={16} /></button>
                  </div>
                  <div className="grid grid-cols-5 md:grid-cols-8 gap-2 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
                    {Array.from({ length: currentSurah.numberOfAyahs }).map((_, i) => (
                      <button 
                        key={i} 
                        onClick={() => { setCurrentAyahIdx(i); setIsAyahPickerOpen(false); }}
                        className={`aspect-square rounded-lg md:rounded-xl flex items-center justify-center font-bold text-xs md:text-sm transition-all ${currentAyahIdx === i ? 'bg-emerald-600 text-white shadow-lg scale-110' : 'bg-slate-50 text-slate-500 hover:bg-emerald-50 hover:text-emerald-600'}`}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </header>

        <div className="flex-1 flex flex-col pt-16 md:pt-20 overflow-hidden relative">
          <div className="flex-1 overflow-y-auto relative scrollbar-hide">
            {mode === AppMode.TEACHING && currentSurah && (
              <Learning 
                surah={currentSurah} 
                currentIdx={currentAyahIdx} 
                onAyahChange={setCurrentAyahIdx} 
                onModeChange={setMode} 
              />
            )}
            {mode === AppMode.TESTING && currentSurah && (
              <Testing 
                surah={currentSurah} 
                initialAyahIdx={currentAyahIdx} 
                onModeChange={setMode} 
              />
            )}
            {mode === AppMode.HIFZ_PLAN && (
              <HifzPlanView 
                surahs={surahs} 
                onStartAyah={handleStartFromPlan} 
              />
            )}
            {mode === AppMode.TAJWEED_RULES && <TajweedRulesView />}
            {mode === AppMode.ANALYSIS && (
              <AnalysisView 
                language={language} 
                onGoToAyah={(s, a) => { handleStartFromPlan(s, a - 1); }} 
              />
            )}
            {mode === AppMode.USTOZ_CHAT && <UstozChat surah={currentSurah} mode={mode} />}
            {mode === AppMode.USTOZ_PANEL && <UstozPanel />}
            {mode === AppMode.ADMIN && <AdminPanel />}
          </div>
        </div>

        <nav className="lg:hidden shrink-0 bg-white border-t border-slate-100 z-[250] h-16 md:h-20 px-1 pb-safe shadow-[0_-10px_30px_rgba(0,0,0,0.03)]">
          <div className="grid grid-cols-6 h-full items-center">
            {BottomNavItems.map((item) => (
              <button 
                key={item.mode} 
                onClick={() => setMode(item.mode)}
                className={`flex flex-col items-center justify-center gap-1 transition-all ${mode === item.mode ? 'text-emerald-600' : 'text-slate-300 hover:text-slate-400'}`}
              >
                <item.icon size={18} className={mode === item.mode ? 'scale-110' : ''} />
                <span className={`text-[8px] font-black uppercase tracking-tighter ${mode === item.mode ? 'opacity-100' : 'opacity-60'}`}>
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </nav>
      </main>
    </div>
  );
};

export default App;