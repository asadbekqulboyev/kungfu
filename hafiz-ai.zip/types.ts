export enum AppMode {
  TEACHING = 'teaching',
  TESTING = 'testing',
  ANALYSIS = 'analysis',
  ADMIN = 'admin',
  USTOZ_PANEL = 'ustoz_panel',
  USTOZ_CHAT = 'ustoz_chat',
  HIFZ_PLAN = 'hifz_plan',
  TAJWEED_RULES = 'tajweed_rules',
  KIDS = 'kids'
}

export enum Language {
  UZ = 'uz',
  EN = 'en'
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface CombinedAyahData {
  number: number;
  numberInSurah: number;
  text: string;
  tajweed: string;
  translation: string;
  audioUrl: string;
  tafsir: string;
}

export interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  manzil: number;
  page: number;
  ruku: number;
  hizbQuarter: number;
  sajda: boolean;
  audio?: string;
}

export interface Edition {
  identifier: string;
  name: string;
  englishName: string;
  language: string;
  format: string;
  type: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  audioUrl?: string;
  timestamp: number;
  status?: 'pending' | 'reviewed';
  feedback?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  groundingMetadata?: any;
}

export interface LiveTranscription {
  text: string;
  role: 'user' | 'model';
}

export interface HifzScope {
  type: 'whole' | 'surahs' | 'juz';
  selectedSurahNumbers?: number[];
  selectedJuzNumbers?: number[];
  knownSurahNumbers?: number[];
}

export interface HifzDayTask {
  day: number;
  surahNumber: number;
  startAyah: number;
  endAyah: number;
  isCompleted: boolean;
  date: string;
}

export interface HifzPlanJSON {
  type: 'hifz_plan';
  target_date: string;
  notification_time: string;
  daily_goal_weight: number;
  total_ayahs_to_learn: number;
  days_required: number;
  schedule: HifzDayTask[];
  currentDay: number;
  scope: HifzScope;
  created_at: string;
  daily_goal?: number;
  total_ayahs?: number;
  completion_date?: string;
  target_surahs?: string[];
  schedule_summary?: string;
}

export interface User {
  id: string;
  name: string;
  phone: string;
  role: 'student' | 'ustoz' | 'admin';
}

export interface FeedbackJSON {
  type: 'analysis' | 'evaluation';
  accuracy: number;
  overall_feedback: string;
  transcription?: string;
  recognized_surah?: string;
  errors?: Array<{
    word: string;
    issue: string;
    suggestion: string;
    severity: 'low' | 'medium' | 'high';
  }>;
}

export interface IdentificationJSON {
  message: string;
  matches: Array<{
    surah_name: string;
    surah_number: number;
    ayah_number: number;
    global_ayah_number: number;
    confidence: number;
    text: string;
    tajweed: string;
    translation: string;
  }>;
}

export type ModelResponseJSON = FeedbackJSON | HifzPlanJSON | IdentificationJSON;

export enum CharacterState {
  IDLE = 'idle',
  TALKING = 'talking',
  CELEBRATING = 'celebrating'
}

export enum LessonStep {
  INTRO = 'intro',
  TEACHER_READS = 'teacher_reads',
  STUDENT_TURN = 'student_turn',
  FEEDBACK = 'feedback',
  CELEBRATE = 'celebrate'
}