
import React, { useState, useRef, useEffect } from 'react';
import { Surah, ChatMessage, Language } from '../types';
import AudioRecorder from './AudioRecorder';
import { UserCheck, Clock, Volume2, Send, MessageCircle, ChevronLeft } from 'lucide-react';

interface Props {
  surah: Surah | null;
  mode: string;
}

const UstozChat: React.FC<Props> = ({ surah }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
      id: '1',
      role: 'model', 
      content: "Assalomu alaykum! Bu yerda tilovatingizni audioda yuboring. Ustozlarimiz uni tekshirib, xatolaringizni tuzatib berishadi.", 
      timestamp: Date.now() 
    }
  ]);
  const [isSending, setIsSending] = useState(false);
  const [inputText, setInputText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleRecitationSubmission = async (blob: Blob) => {
    setIsSending(true);
    const audioUrl = URL.createObjectURL(blob);
    const msgId = Math.random().toString(36).substr(2, 9);
    
    const userMsg: ChatMessage = { 
      id: msgId,
      role: 'user', 
      content: "Ustoz, tilovatimni yubordim.", 
      audioUrl,
      timestamp: Date.now(),
      status: 'pending'
    };
    
    setMessages(prev => [...prev, userMsg]);

    setTimeout(() => {
      const systemMsg: ChatMessage = {
        id: Math.random().toString(36),
        role: 'model',
        content: "Qiroatingiz ustozlarga yuborildi. Tez orada javob olasiz.",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, systemMsg]);
      setIsSending(false);
    }, 1200);
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    const msg: ChatMessage = {
      id: Math.random().toString(36),
      role: 'user',
      content: inputText,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, msg]);
    setInputText("");
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: Math.random().toString(36),
        role: 'model',
        content: "Xabaringiz qabul qilindi.",
        timestamp: Date.now()
      }]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] overflow-hidden">
      
      {/* COMPACT HEADER */}
      <header className="h-16 shrink-0 bg-white border-b border-slate-100 flex items-center justify-between px-4 md:px-6 z-20 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shrink-0">
             <MessageCircle size={18} />
          </div>
          <div className="flex flex-col">
            <h3 className="text-[13px] font-black text-slate-800 leading-tight">Ustoz Chat</h3>
            <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mt-0.5 flex items-center gap-1.5">
               <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Ustozlar onlayn
            </p>
          </div>
        </div>
      </header>

      {/* SCROLLABLE CHAT AREA */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-6 bg-white/50 space-y-4">
        <div className="max-w-3xl mx-auto space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} group animate-in slide-in-from-bottom-2`}>
              <div className={`max-w-[85%] md:max-w-[75%] p-4 rounded-2xl text-[14px] shadow-sm relative border ${msg.role === 'user' ? 'bg-emerald-600 border-emerald-500 text-white rounded-tr-none shadow-emerald-100' : 'bg-white border-slate-100 text-slate-700 rounded-tl-none'}`}>
                <p className="leading-relaxed font-medium">{msg.content}</p>
                
                {msg.audioUrl && (
                  <div className={`mt-3 p-3 rounded-xl flex flex-col gap-2 ${msg.role === 'user' ? 'bg-black/10' : 'bg-slate-50 border border-slate-100'}`}>
                    <div className="flex items-center gap-2">
                      <Volume2 size={12} className="opacity-60" />
                      <span className="text-[8px] font-black uppercase tracking-widest opacity-60">Audio qiroat</span>
                    </div>
                    <audio src={msg.audioUrl} controls className={`h-8 w-full filter ${msg.role === 'user' ? 'invert' : ''}`} />
                  </div>
                )}

                {msg.status === 'pending' && (
                  <div className="mt-3 pt-3 border-t border-white/10 flex items-center gap-2 text-[8px] font-black uppercase tracking-widest text-emerald-100">
                    <Clock size={10} className="animate-pulse" /> Kutishda...
                  </div>
                )}
              </div>
              <span className="text-[9px] text-slate-300 mt-1.5 font-black uppercase tracking-widest px-2">
                {new Date(msg.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}
              </span>
            </div>
          ))}
          {isSending && (
            <div className="flex items-center gap-2 text-emerald-500 px-2 animate-pulse">
              <div className="flex gap-1">
                <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce"></span>
                <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
              <span className="text-[9px] font-black uppercase tracking-widest">Yuborilmoqda</span>
            </div>
          )}
        </div>
      </div>

      {/* COMPACT INPUT FOOTER */}
      <footer className="shrink-0 bg-white border-t border-slate-100 p-4 md:p-6 z-30 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
        <div className="max-w-3xl mx-auto">
          <div className="bg-slate-50 p-1.5 rounded-full border border-slate-100 flex items-center gap-2 transition-all focus-within:ring-4 focus-within:ring-emerald-50 focus-within:bg-white focus-within:border-emerald-100">
            <div className="shrink-0 flex items-center pl-1">
               <AudioRecorder onRecordingComplete={handleRecitationSubmission} isProcessing={isSending} language={Language.UZ} />
            </div>
            
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Xabar yozing..." 
              className="flex-1 min-w-0 bg-transparent border-none outline-none text-[14px] font-medium placeholder:text-slate-300 py-2.5" 
            />
            
            <button 
              onClick={handleSendMessage}
              disabled={!inputText.trim()}
              className="shrink-0 w-11 h-11 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-emerald-700 active:scale-95 transition-all disabled:opacity-20"
            >
              <Send size={18} className="ml-0.5" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default UstozChat;
