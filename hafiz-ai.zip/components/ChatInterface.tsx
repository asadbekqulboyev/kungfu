
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Message } from '../types';
import { Send, Sparkles, Globe, ExternalLink, Bot, Activity } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: '# Assalomu alaykum! Men Hofiz AI Professionalsiz.\nSizga Qur\'on ilmlari, tajvid qoidalari yoki hifz bo\'yicha istalgan savolingizda yordam bera olaman.',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { id: Date.now().toString(), role: 'user', text: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: input,
        config: {
          systemInstruction: 'Siz "Hafiz Pro" mutaxassis islomshunos va Qur\'on ustozi rolidasiz. Javoblaringiz ilmiy asoslangan, professional va odob doirasida bo\'lsin. Ma\'lumotlarni tasdiqlash uchun Google Search groundingdan foydalaning.',
          tools: [{ googleSearch: {} }]
        }
      });

      const modelMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text || 'Kechirasiz, ma\'lumotni yuklashda xatolik yuz berdi.',
        timestamp: new Date(),
        groundingMetadata: response.candidates?.[0]?.groundingMetadata
      };

      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] relative">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-10 space-y-8 pb-40 scrollbar-hide">
        <div className="max-w-4xl mx-auto space-y-8">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
              <div className={`flex gap-4 max-w-[92%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-10 h-10 md:w-12 md:h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${msg.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white'}`}>
                  {msg.role === 'user' ? <div className="text-[10px] font-black uppercase">Siz</div> : <Bot size={24} />}
                </div>
                <div className={`rounded-[2rem] p-6 md:p-8 ${
                  msg.role === 'user' 
                  ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-900/10 rounded-tr-none' 
                  : 'bg-white border border-slate-100 text-slate-800 shadow-sm rounded-tl-none'
                }`}>
                  <div className="prose prose-slate max-w-none prose-headings:font-black prose-p:leading-relaxed text-sm md:text-base">
                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                  </div>
                  
                  {msg.groundingMetadata?.groundingChunks && (
                    <div className="mt-8 pt-6 border-t border-slate-100">
                      <div className="flex items-center gap-2 mb-4 text-slate-400">
                        <Globe size={14} />
                        <span className="text-[9px] font-black uppercase tracking-widest">Tasdiqlangan Manbalar</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {msg.groundingMetadata.groundingChunks.map((chunk: any, i: number) => (
                          chunk.web && (
                            <a 
                              key={i} href={chunk.web.uri} target="_blank" rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-50 hover:bg-emerald-50 rounded-full border border-slate-100 text-[10px] transition-all group"
                            >
                              <span className="max-w-[150px] truncate text-slate-600 font-bold group-hover:text-emerald-700">{chunk.web.title}</span>
                              <ExternalLink size={10} className="text-slate-300 group-hover:text-emerald-500" />
                            </a>
                          )
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start items-center space-x-4 animate-pulse">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center"><Activity size={24} className="text-emerald-500" /></div>
              <div className="flex gap-1.5">
                 {[1,2,3].map(i => <div key={i} className="w-2 h-2 bg-emerald-200 rounded-full animate-bounce" style={{ animationDelay: `${i*0.2}s` }}></div>)}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-6 left-0 right-0 px-4 md:px-10 z-[100] mb-14 lg:mb-0">
        <div className="max-w-4xl mx-auto bg-white/80 backdrop-blur-3xl p-2 rounded-[2.5rem] shadow-[0_25px_60px_rgba(0,0,0,0.1)] border border-white flex items-center gap-2">
          <textarea
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Ustozdan savol so'rang..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-slate-800 px-5 py-4 resize-none text-base md:text-lg font-medium placeholder:text-slate-300"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-30 text-white w-12 h-12 md:w-14 md:h-14 rounded-3xl transition-all flex items-center justify-center shadow-xl shadow-emerald-200 active:scale-90"
          >
            <Send size={22} className="ml-1" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
