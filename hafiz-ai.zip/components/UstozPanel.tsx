
import React, { useState, useRef, useEffect } from 'react';
// Fix: Added missing 'MessageCircle' icon import from lucide-react
import { 
  Users, CheckCircle, Clock, MessageSquare, MessageCircle, Star, Search, 
  Play, FileText, ChevronLeft, MoreVertical, Send, Mic, 
  Volume2, Check, CheckCheck, Sparkles, X, Paperclip, 
  ArrowLeft, Award, Activity
} from 'lucide-react';
import { parseTajweedAndWrap } from '../utils/tajweedParser';

interface ChatMessage {
  id: string;
  sender: 'student' | 'teacher' | 'ai';
  type: 'text' | 'audio' | 'analysis';
  content: string;
  timestamp: string;
  status?: 'sent' | 'delivered' | 'read';
  audioUrl?: string;
  accuracy?: number;
}

interface StudentChat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  avatar: string;
  surah: string;
  ayah: number;
  messages: ChatMessage[];
}

const MOCK_CHATS: StudentChat[] = [
  {
    id: '1',
    name: 'Abdurahmon G\'ofurov',
    lastMessage: 'Vazifani topshirdim, ustoz.',
    time: '14:20',
    unreadCount: 1,
    avatar: 'AG',
    surah: 'Al-Baqara',
    ayah: 12,
    messages: [
      { id: 'm1', sender: 'student', type: 'text', content: 'Assalomu alaykum ustoz, bugungi vazifani yuboryapman.', timestamp: '14:18', status: 'read' },
      { id: 'm2', sender: 'student', type: 'audio', content: 'Al-Baqara 12-oyat', audioUrl: 'https://cdn.islamic.network/quran/audio/128/ar.alafasy/19.mp3', timestamp: '14:19', status: 'read' },
      { id: 'm3', sender: 'ai', type: 'analysis', content: 'AI Tahlili: Tajvid aniqligi 84%. Madd cho\'zilishlarida biroz xatolik bor.', accuracy: 84, timestamp: '14:19' }
    ]
  },
  {
    id: '2',
    name: 'Salimbek Orifov',
    lastMessage: 'Rahmat, ustoz!',
    time: 'Kecha',
    unreadCount: 0,
    avatar: 'SO',
    surah: 'Yasin',
    ayah: 1,
    messages: []
  },
  {
    id: '3',
    name: 'Oydina Karimova',
    lastMessage: 'Keyingi dars qachon?',
    time: '10:05',
    unreadCount: 0,
    avatar: 'OK',
    surah: 'Mulk',
    ayah: 5,
    messages: []
  }
];

const UstozPanel: React.FC = () => {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [inputText, setInputText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  const selectedChat = MOCK_CHATS.find(c => c.id === selectedChatId);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [selectedChatId, selectedChat?.messages]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    // Real ilovada bu yerda API chaqiriladi
    setInputText("");
  };

  return (
    <div className="flex h-full w-full bg-[#F0F2F5] overflow-hidden font-sans">
      
      {/* --- Chap Panel: Chatlar Ro'yxati --- */}
      <div className={`
        w-full lg:w-[380px] h-full flex flex-col bg-white border-r border-slate-200 z-40 transition-all
        ${selectedChatId ? 'hidden lg:flex' : 'flex'}
      `}>
        {/* Sidebar Header */}
        <div className="p-4 bg-white sticky top-0 z-10">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-black text-slate-800 tracking-tight">Xabarlar</h2>
            <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <MoreVertical size={20} className="text-slate-400" />
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
            <input 
              type="text" 
              placeholder="Qidirish..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-2.5 bg-slate-100 border-none rounded-xl text-sm font-medium outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
            />
          </div>
        </div>

        {/* Chats List */}
        <div className="flex-1 overflow-y-auto">
          {MOCK_CHATS.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map((chat) => (
            <button 
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`w-full p-4 flex items-center gap-3 transition-all border-b border-slate-50 hover:bg-slate-50 relative ${selectedChatId === chat.id ? 'bg-emerald-50' : 'bg-white'}`}
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-black text-sm shadow-md shrink-0">
                {chat.avatar}
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="flex justify-between items-center mb-0.5">
                  <h4 className="font-black text-slate-800 text-sm truncate">{chat.name}</h4>
                  <span className="text-[10px] font-bold text-slate-400">{chat.time}</span>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-xs text-slate-400 truncate pr-4">{chat.lastMessage}</p>
                  {chat.unreadCount > 0 && (
                    <span className="bg-emerald-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* --- O'ng Panel: Chat Oynasi --- */}
      <div className={`
        flex-1 h-full flex flex-col bg-[#E5DDD5] relative
        ${!selectedChatId ? 'hidden lg:flex' : 'flex'}
      `}>
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <header className="bg-white px-4 py-3 border-b border-slate-200 flex items-center justify-between z-30 shadow-sm">
              <div className="flex items-center gap-3">
                <button onClick={() => setSelectedChatId(null)} className="lg:hidden p-2 -ml-2 text-slate-400 hover:bg-slate-100 rounded-full">
                  <ArrowLeft size={22} />
                </button>
                <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-white font-black text-xs">
                  {selectedChat.avatar}
                </div>
                <div className="flex flex-col">
                  <h3 className="text-sm font-black text-slate-800 leading-none mb-1">{selectedChat.name}</h3>
                  <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest leading-none">
                    {selectedChat.surah} • {selectedChat.ayah}-oyat
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all">
                  <Search size={20} />
                </button>
                <button className="p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all">
                  <MoreVertical size={20} />
                </button>
              </div>
            </header>

            {/* Messages Content */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 custom-scrollbar bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] bg-repeat bg-fixed">
              <div className="max-w-4xl mx-auto space-y-4">
                
                {selectedChat.messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full py-20 text-center">
                    <div className="bg-white/80 backdrop-blur-sm p-4 rounded-2xl shadow-sm border border-white">
                      <p className="text-slate-500 text-xs font-medium">Hali xabarlar yo'q. Muloqotni boshlang.</p>
                    </div>
                  </div>
                ) : (
                  selectedChat.messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === 'teacher' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                      
                      {/* Message Bubble */}
                      <div className={`
                        max-w-[85%] md:max-w-[70%] rounded-2xl p-3 shadow-sm relative group
                        ${msg.sender === 'teacher' ? 'bg-[#DCF8C6] rounded-tr-none' : msg.sender === 'ai' ? 'bg-white/95 border border-emerald-100 w-full md:w-auto text-center mx-auto rounded-3xl' : 'bg-white rounded-tl-none'}
                      `}>
                        
                        {/* Audio Type */}
                        {msg.type === 'audio' && (
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-3">
                              <button className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center text-white shadow-sm hover:scale-105 transition-all">
                                <Play size={18} fill="white" className="ml-0.5" />
                              </button>
                              <div className="flex-1 min-w-[120px] md:min-w-[200px]">
                                <div className="h-1 bg-slate-200 rounded-full relative overflow-hidden">
                                  <div className="absolute top-0 left-0 h-full bg-emerald-500" style={{ width: '40%' }} />
                                </div>
                                <div className="flex justify-between mt-1 text-[8px] font-bold text-slate-400">
                                  <span>0:15</span>
                                  <span>0:45</span>
                                </div>
                              </div>
                            </div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{msg.content}</p>
                          </div>
                        )}

                        {/* Analysis Type (AI) */}
                        {msg.type === 'analysis' && (
                          <div className="flex items-center gap-4 py-1 px-2">
                            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
                              <Activity size={20} />
                            </div>
                            <div className="text-left flex-1">
                               <div className="flex justify-between items-center mb-1">
                                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">AI Tahlili</span>
                                  <span className="text-[12px] font-black text-emerald-700">{msg.accuracy}%</span>
                               </div>
                               <p className="text-[11px] font-medium text-slate-600 leading-relaxed">{msg.content}</p>
                            </div>
                          </div>
                        )}

                        {/* Text Type */}
                        {msg.type === 'text' && (
                          <p className="text-sm text-slate-800 font-medium leading-relaxed">{msg.content}</p>
                        )}

                        {/* Timestamp & Status */}
                        <div className="flex items-center justify-end gap-1 mt-1 opacity-60">
                          <span className="text-[8px] font-bold text-slate-500 uppercase">{msg.timestamp}</span>
                          {msg.sender === 'teacher' && (
                            msg.status === 'read' ? <CheckCheck size={12} className="text-blue-500" /> : <Check size={12} className="text-slate-400" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
                <div ref={chatEndRef} />
              </div>
            </div>

            {/* Chat Input Bar */}
            <div className="bg-[#F0F2F5] px-4 py-3 border-t border-slate-200 z-30">
              <div className="max-w-4xl mx-auto flex items-center gap-2">
                <button className="p-2 text-slate-500 hover:bg-slate-200 rounded-full transition-all">
                  <Paperclip size={22} />
                </button>
                <div className="flex-1 bg-white rounded-2xl flex items-center px-4 py-1.5 shadow-sm border border-slate-200 focus-within:border-emerald-500/50 transition-all">
                  <textarea 
                    rows={1}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Xabar yozing..."
                    className="flex-1 bg-transparent border-none outline-none text-sm font-medium py-1.5 max-h-32 resize-none overflow-y-auto"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                  />
                  <div className="flex items-center gap-2">
                    <button className="text-slate-400 hover:text-emerald-500 p-1">
                      <Sparkles size={18} />
                    </button>
                  </div>
                </div>
                <button 
                  onClick={handleSendMessage}
                  className={`p-3 rounded-full flex items-center justify-center transition-all shadow-md active:scale-90 ${inputText.trim() ? 'bg-emerald-600 text-white' : 'bg-white text-slate-400'}`}
                >
                  {inputText.trim() ? <Send size={22} /> : <Mic size={22} />}
                </button>
              </div>
            </div>
          </>
        ) : (
          /* Empty State */
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center">
            <div className="w-24 h-24 bg-white/50 backdrop-blur-md rounded-[2.5rem] flex items-center justify-center text-slate-300 mb-6 shadow-sm">
              <MessageCircle size={48} />
            </div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-widest">Chatni Tanlang</h3>
            <p className="text-slate-400 text-xs font-medium mt-2 max-w-xs">Talabalar tilovatlarini tekshirish uchun chap tarafdagi ro'yxatdan birini tanlang</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UstozPanel;
