
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Image as ImageIcon, Download, RefreshCw, Layers, Sparkles } from 'lucide-react';

const ImageGen: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);

  const generateImage = async () => {
    if (!prompt.trim() || isGenerating) return;

    // MANDATORY check for API key when using gemini-3-pro-image-preview
    if (window.aistudio?.hasSelectedApiKey) {
      const selected = await window.aistudio.hasSelectedApiKey();
      if (!selected) {
        if (window.aistudio.openSelectKey) {
          await window.aistudio.openSelectKey();
        }
        return;
      }
    }

    setIsGenerating(true);
    try {
      // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // Using gemini-3-pro-image-preview for "Professional" quality
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: { parts: [{ text: prompt }] },
        config: { 
          imageConfig: { aspectRatio: '1:1', imageSize: '1K' },
          // Fix: Use googleSearch instead of google_search as per type definition and guidelines
          tools: [{ googleSearch: {} }]
        }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          // Find the image part, do not assume it is the first part.
          if (part.inlineData) {
            setResultImage(`data:image/png;base64,${part.inlineData.data}`);
            break;
          } else if (part.text) {
            console.log(part.text);
          }
        }
      }
    } catch (e) {
      console.error(e);
      alert("Xatolik: Ehtimol tanlangan API kalitda tasvir yaratish huquqi yo'q.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 md:p-12 items-center bg-[#020617] overflow-y-auto">
      <div className="max-w-2xl w-full text-center space-y-4 mb-12 animate-in slide-in-from-top-4 duration-700">
        <h2 className="text-4xl font-display font-bold text-white tracking-tight">Image Studio</h2>
        <p className="text-slate-400 text-lg">Xayolingizni professional vizual san'at asariga aylantiring.</p>
        <div className="flex justify-center">
           <div className="bg-blue-600/10 border border-blue-600/20 text-blue-400 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-2">
             <Sparkles size={14} /> Powered by Gemini 3 Pro
           </div>
        </div>
      </div>

      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-10 items-start">
        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-[2rem] shadow-2xl backdrop-blur-xl">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2 mb-4">
              <ImageIcon size={14} /> Vizual Instruksiya
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="O'rta asrlar uslubidagi kiberpunk kutubxonasi, oltin rangli chiroqlar, koinot manzarasi..."
              className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl p-6 text-slate-100 focus:ring-2 focus:ring-blue-600 outline-none h-48 transition-all resize-none mb-6 placeholder-slate-700"
            />
            <button
              onClick={generateImage}
              disabled={!prompt.trim() || isGenerating}
              className="w-full h-16 bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 disabled:opacity-50 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl shadow-blue-900/20 transform active:scale-[0.98]"
            >
              {isGenerating ? <RefreshCw className="animate-spin" size={20} /> : <Layers size={20} />}
              {isGenerating ? 'San\'at yaratilmoqda...' : 'Tasvir Yaratish'}
            </button>
          </div>
        </div>

        <div className="aspect-square bg-slate-900/30 border-2 border-dashed border-slate-800/50 rounded-[2.5rem] flex items-center justify-center relative overflow-hidden group shadow-inner">
          {resultImage ? (
            <div className="w-full h-full animate-in zoom-in-95 duration-700">
              <img src={resultImage} alt="Hofiz AI Art" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 backdrop-blur-sm">
                <a 
                  href={resultImage} 
                  download="hofiz-ai-masterpiece.png" 
                  className="bg-white text-black px-8 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-200 transition-all transform hover:scale-105"
                >
                  <Download size={18} /> Yuklab olish
                </a>
              </div>
            </div>
          ) : (
            <div className="text-center p-8 space-y-4">
              <div className="w-20 h-20 bg-slate-800/50 rounded-[1.5rem] flex items-center justify-center mx-auto mb-4 border border-slate-700">
                <ImageIcon size={32} className="text-slate-600" />
              </div>
              <p className="text-slate-500 text-sm font-medium">Bu yerda generatsiya qilingan natija chiqadi</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ImageGen;
