
import React, { useState, useEffect } from 'react';
import { Surah, Language, HifzScope, HifzPlanJSON, HifzDayTask } from '../types';
import { 
  Loader2, Book, Check, ChevronRight, LayoutGrid, 
  Calendar as CalendarIcon, Bell, Clock, Trash2, 
  Target, Search, ArrowRight, Layers, Zap, Brain, Sparkles,
  ArrowDown10, ArrowUp01, ChevronLeft, CalendarDays
} from 'lucide-react';
import { getSurahNameUz } from '../utils/quranUtils';

interface Props {
  surahs: Surah[];
  language: Language;
  onClose: () => void;
  onComplete: (plan: HifzPlanJSON) => void;
}

const HifzPlanningWizard: React.FC<Props> = ({ surahs, language, onClose, onComplete }) => {
  const [step, setStep] = useState(1);
  const [scopeType, setScopeType] = useState<HifzScope['type']>('whole');
  const [isReverseOrder, setIsReverseOrder] = useState(true);
  const [selectedSurahNums, setSelectedSurahNums] = useState<number[]>([]);
  const [knownSurahNums, setKnownSurahNums] = useState<number[]>([]);
  
  const [targetDate, setTargetDate] = useState<Date | null>(null);
  const [notifTime, setNotifTime] = useState("07:00");
  const [isProcessing, setIsProcessing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Kalendar uchun holatlar
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const sortedSurahs = [...surahs].sort((a, b) => isReverseOrder ? b.number - a.number : a.number - b.number);
  const filteredSurahs = sortedSurahs.filter(s => 
    s.englishName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    getSurahNameUz(s.englishName).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleList = (num: number, list: number[], setter: (val: number[]) => void) => {
    setter(list.includes(num) ? list.filter(n => n !== num) : [...list, num]);
  };

  const calculateHifzPlan = () => {
    if (!targetDate) return null;

    let baseSurahs = isReverseOrder 
      ? [...surahs].sort((a, b) => b.number - a.number) 
      : [...surahs].sort((a, b) => a.number - b.number);

    const targets = scopeType === 'whole' 
      ? baseSurahs.filter(s => !knownSurahNums.includes(s.number))
      : baseSurahs.filter(s => selectedSurahNums.includes(s.number));

    const today = new Date();
    const diffTime = Math.abs(targetDate.getTime() - today.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 3) return null;

    const totalAyahs = targets.reduce((acc, s) => acc + s.numberOfAyahs, 0);
    const avgAyahsPerDay = Math.ceil(totalAyahs / diffDays);

    const schedule: HifzDayTask[] = [];
    let currentDayIdx = 0;
    let tempDate = new Date(today);

    targets.forEach(surah => {
      let ayahsRemaining = surah.numberOfAyahs;
      let currentAyahStart = 1;

      while (ayahsRemaining > 0) {
        let weightingFactor = surah.number > 78 ? 1.4 : surah.number < 10 ? 0.7 : 1.0;
        let dayLoad = Math.max(1, Math.round(avgAyahsPerDay * weightingFactor));
        let ayahsForToday = Math.min(dayLoad, ayahsRemaining);
        
        schedule.push({
          day: currentDayIdx + 1,
          surahNumber: surah.number,
          startAyah: currentAyahStart,
          endAyah: currentAyahStart + ayahsForToday - 1,
          isCompleted: false,
          date: new Date(tempDate).toISOString().split('T')[0]
        });

        currentAyahStart += ayahsForToday;
        ayahsRemaining -= ayahsForToday;
        currentDayIdx++;
        tempDate.setDate(tempDate.getDate() + 1);
      }
    });

    return {
      type: 'hifz_plan' as const,
      target_date: targetDate.toISOString().split('T')[0],
      notification_time: notifTime,
      daily_goal_weight: avgAyahsPerDay,
      total_ayahs_to_learn: totalAyahs,
      days_required: schedule.length,
      schedule: schedule,
      currentDay: 1,
      scope: { type: scopeType, selectedSurahNumbers: selectedSurahNums, knownSurahNumbers: knownSurahNums },
      created_at: new Date().toISOString()
    };
  };

  const handleFinish = async () => {
    if (!targetDate) return alert("Iltimos, tugatish sanasini tanlang!");
    setIsProcessing(true);
    const plan = calculateHifzPlan();
    if (!plan) {
      alert("Tanlangan muddat juda qisqa.");
      setIsProcessing(false);
      return;
    }
    if ("Notification" in window) await Notification.requestPermission();
    localStorage.setItem('active_hifz_plan', JSON.stringify(plan));
    setTimeout(() => {
      onComplete(plan);
      setIsProcessing(false);
    }, 2000);
  };

  // Kalendar generatsiyasi
  const renderCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    today.setHours(0,0,0,0);

    const days = [];
    // Oldingi oydan qolgan bo'sh kataklar
    for (let i = 0; i < (firstDay === 0 ? 6 : firstDay - 1); i++) {
      days.push(<div key={`empty-${i}`} className="h-12 w-full"></div>);
    }

    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      const isPast = date < today;
      const isSelected = targetDate?.toDateString() === date.toDateString();

      days.push(
        <button
          key={d}
          disabled={isPast}
          onClick={() => setTargetDate(date)}
          className={`h-12 w-full rounded-xl flex items-center justify-center text-xs font-bold transition-all
            ${isPast ? 'text-slate-200 cursor-not-allowed' : 'hover:bg-emerald-50 text-slate-700'}
            ${isSelected ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : ''}
          `}
        >
          {d}
        </button>
      );
    }
    return days;
  };

  const changeMonth = (offset: number) => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + offset, 1));
  };

  const monthNames = ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"];

  return (
    <div className="fixed inset-0 z-[600] bg-white flex flex-col animate-in slide-in-from-bottom-10 font-sans">
      <header className="px-6 py-5 border-b flex items-center justify-between bg-white shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg">
             <Target size={20} />
          </div>
          <div>
            <h2 className="text-sm font-black text-slate-800 uppercase tracking-widest">Hifz Rejalashtirish</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Bosqich {step === 4 ? 3 : step} / 3</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={20} /></button>
      </header>

      <div className="flex-1 overflow-y-auto p-6 md:p-12 flex flex-col items-center">
        <div className="w-full max-w-xl">
          
          {step === 1 && (
            <div className="animate-in fade-in space-y-8">
               <div className="text-center space-y-2">
                 <h3 className="text-2xl font-black text-slate-900">Maqsadingiz qanday?</h3>
                 <p className="text-slate-400 text-sm">Biz orqadan boshlab (30-pora) yodlashni tavsiya qilamiz.</p>
               </div>

               <div className="bg-slate-50 p-4 rounded-3xl mb-4 flex items-center justify-between border border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
                       {isReverseOrder ? <ArrowDown10 size={20} /> : <ArrowUp01 size={20} />}
                    </div>
                    <div>
                       <h4 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Yodlash tartibi</h4>
                       <p className="text-[11px] font-bold text-emerald-600">{isReverseOrder ? "Orqadan Boshiga (114 -> 1)" : "Boshidan Oxiriga (1 -> 114)"}</p>
                    </div>
                  </div>
                  <button onClick={() => setIsReverseOrder(!isReverseOrder)} className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">O'zgartirish</button>
               </div>

               <div className="grid gap-4">
                  {[
                    { id: 'whole', title: 'Butun Qur\'on', icon: Book, desc: 'Barcha suralarni qamrab oladi' },
                    { id: 'surahs', title: 'Tanlangan Suralar', icon: LayoutGrid, desc: 'Ma\'lum suralar ro\'yxati' },
                  ].map(opt => (
                    <button key={opt.id} onClick={() => { setScopeType(opt.id as any); setStep(opt.id === 'surahs' ? 2 : 3); }} className="p-6 rounded-[2rem] border-2 border-slate-50 hover:border-emerald-500 hover:bg-emerald-50/30 transition-all flex items-center gap-5 text-left bg-white group">
                      <div className="w-14 h-14 bg-slate-50 group-hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 group-hover:text-emerald-600 transition-colors shadow-sm"><opt.icon size={24} /></div>
                      <div className="flex-1">
                        <div className="font-black text-slate-800 text-base">{opt.title}</div>
                        <div className="text-[11px] text-slate-400 font-bold uppercase tracking-tight">{opt.desc}</div>
                      </div>
                      <ChevronRight className="text-slate-200 group-hover:text-emerald-500 transition-colors" />
                    </button>
                  ))}
               </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in fade-in space-y-6">
               <div className="text-center space-y-2">
                 <h3 className="text-xl font-black text-slate-900">Suralarni belgilang</h3>
                 <p className="text-slate-400 text-xs uppercase font-bold tracking-widest">Siz tanlagan suralar: {selectedSurahNums.length} ta</p>
               </div>
               <div className="relative">
                 <input type="text" placeholder="Sura qidirish..." className="w-full p-4 pl-12 bg-slate-50 rounded-2xl outline-none font-bold text-sm border-2 border-transparent focus:border-emerald-100 transition-all" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                 <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
               </div>
               <div className="grid grid-cols-2 gap-2 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                  {filteredSurahs.map(s => (
                    <button key={s.number} onClick={() => toggleList(s.number, selectedSurahNums, setSelectedSurahNums)} className={`p-4 rounded-2xl border-2 text-left text-xs font-black uppercase tracking-tight transition-all ${selectedSurahNums.includes(s.number) ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg' : 'bg-white border-slate-50 text-slate-600 hover:border-emerald-100'}`}>{getSurahNameUz(s.englishName)}</button>
                  ))}
               </div>
               {/* OPTIMIZATSIYA: Muayyan sura tanlasa, 3-bosqichni (Bilganlarni belgilash) o'tkazib yuboramiz */}
               <button onClick={() => setStep(4)} className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest text-[11px] shadow-xl hover:bg-emerald-600 transition-all">Davom etish</button>
            </div>
          )}

          {step === 3 && (
            <div className="animate-in fade-in space-y-8">
               <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-[2rem] flex items-center justify-center mx-auto mb-4 shadow-inner"><Brain size={32} /></div>
                  <h3 className="text-xl font-black text-slate-900">Bilgan suralaringiz bormi?</h3>
                  <p className="text-slate-400 text-sm">Bular rejamizdan chiqarib tashlanadi.</p>
               </div>
               <div className="grid grid-cols-2 gap-2 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
                  {sortedSurahs.map(s => (
                    <button key={s.number} onClick={() => toggleList(s.number, knownSurahNums, setKnownSurahNums)} className={`p-4 rounded-2xl border-2 text-left text-xs font-black uppercase tracking-tight transition-all ${knownSurahNums.includes(s.number) ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : 'bg-white border-slate-50 text-slate-600 hover:border-emerald-100'}`}>{getSurahNameUz(s.englishName)}</button>
                  ))}
               </div>
               <button onClick={() => setStep(4)} className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest text-[11px] shadow-xl hover:bg-emerald-600 transition-all">Vaqtlarni belgilash</button>
            </div>
          )}

          {step === 4 && (
            <div className="animate-in fade-in space-y-8 pb-12">
               <div className="text-center space-y-2">
                 <h3 className="text-xl font-black text-slate-900">Yakuniy Muddatni Tanlang</h3>
                 <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Qur'onni qachongacha tugatmoqchisiz?</p>
               </div>

               {/* CUSTOM CALENDAR */}
               <div className="bg-white rounded-[2.5rem] p-6 border-2 border-slate-50 shadow-sm">
                  <div className="flex items-center justify-between mb-6 px-2">
                     <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-slate-50 rounded-full text-slate-400"><ChevronLeft size={20} /></button>
                     <h4 className="font-black text-slate-800 text-sm uppercase tracking-widest">{monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}</h4>
                     <button onClick={() => changeMonth(1)} className="p-2 hover:bg-slate-50 rounded-full text-slate-400"><ChevronRight size={20} /></button>
                  </div>
                  
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'].map(d => (
                      <div key={d} className="text-center text-[10px] font-black text-slate-300 uppercase py-2">{d}</div>
                    ))}
                  </div>

                  <div className="grid grid-cols-7 gap-1">
                    {renderCalendar()}
                  </div>
               </div>

               <div className="bg-slate-900 p-8 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
                  <div className="relative z-10 flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-amber-400"><Bell size={20} /></div>
                        <div>
                          <h4 className="text-[10px] font-black uppercase tracking-widest opacity-60">Eslatma vaqti</h4>
                          <input 
                            type="time" 
                            value={notifTime} 
                            onChange={e => setNotifTime(e.target.value)} 
                            className="bg-transparent font-black text-2xl outline-none w-full border-none p-0 mt-1" 
                          />
                        </div>
                     </div>
                     <Clock className="text-slate-500" size={24} />
                  </div>
               </div>

               <button 
                 disabled={isProcessing || !targetDate} 
                 onClick={handleFinish} 
                 className="w-full py-6 bg-emerald-600 text-white rounded-[2.5rem] font-black uppercase tracking-widest text-xs shadow-2xl shadow-emerald-200 flex items-center justify-center gap-4 hover:bg-emerald-700 active:scale-95 transition-all disabled:opacity-20 disabled:grayscale"
               >
                 {isProcessing ? <Loader2 className="animate-spin" size={24} /> : (
                   <>Rejani Shakllantirish <ArrowRight size={24} /></>
                 )}
               </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default HifzPlanningWizard;
