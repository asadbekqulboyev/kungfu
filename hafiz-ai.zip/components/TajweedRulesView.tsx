
import React, { useState } from 'react';
import { ShieldCheck, BookOpen, Layers, Zap, Volume2, Sparkles, Info as InfoIcon, ArrowRight } from 'lucide-react';

interface Rule {
  id: string;
  title: string;
  code: string;
  color: string;
  desc: string;
  group: 'prolongation' | 'noon_meem' | 'idgham' | 'symbols';
}

const TAJWEED_RULES: Rule[] = [
  // Symbols & Basics
  { 
    id: 'h', 
    group: 'symbols', 
    title: "Hamzatul Vasl", 
    code: "h", 
    color: "#AAAAAA", 
    desc: "Oyatlar boshida sado berib, so'zlar birikkanda esa sokinlikka burkanuvchi bog'lovchi hamza. U go'yo bir ko'prikdir – qiroatni nafislik bilan davom ettirishga xizmat qiladi." 
  },
  { 
    id: 's', 
    group: 'symbols', 
    title: "Silent (O'qilmas harf)", 
    code: "s", 
    color: "#AAAAAA", 
    desc: "Yozuvda bor, ammo tilda yo'q – sirlilik libosini kiygan, talaffuzdan pinhon tutilgan harflar. Ular xatda ko'rinsa-da, ohangda o'z o'rnini keyingi harfga bo'shatib beradi." 
  },
  { 
    id: 'l', 
    group: 'symbols', 
    title: "Lam Shamsiyyah", 
    code: "l", 
    color: "#AAAAAA", 
    desc: "Quyosh nurlari kabi o'zidan keyingi harfni yoritib, o'zi esa uning ichiga singib ketuvchi nafis Lam. U talaffuz etilmaydi, balki keyingi harfni mardona shadda bilan mustahkamlaydi." 
  },
  { 
    id: 'q', 
    group: 'symbols', 
    title: "Qalaqah (Tebranish)", 
    code: "q", 
    color: "#DD0008", 
    desc: "Tog'lar orasidagi aks-sado misoli, harfni ohangdor qilib chayqatib, maromiga yetkazib tebratish. Beshta harfda namoyon bo'luvchi bu xususiyat tilovatga o'zgacha haybat baxsh etadi." 
  },

  // Madda (Prolongation)
  { 
    id: 'n', 
    group: 'prolongation', 
    title: "Madda Tabiiy", 
    code: "n", 
    color: "#537FFF", 
    desc: "Tabiiy va go'zal cho'zilish – harfning asl latofatini namoyon etuvchi ikki harakatli nafas oromi. Bu cho'zilish ortiqcha zo'riqishsiz, xuddi daryo oqimidek ravon bo'lishi lozim." 
  },
  { 
    id: 'p', 
    group: 'prolongation', 
    title: "Madda Joiiz", 
    code: "p", 
    color: "#4050FF", 
    desc: "Tilovatchining ixtiyoriga topshirilgan, erkinlik va nafosat ila cho'ziluvchi go'zal ohang. Uni ixtiyoringizga ko'ra qisqa yoki uzoqroq cho'zishingiz mumkin, bu qiroatga rang-baranglik beradi." 
  },
  { 
    id: 'o', 
    group: 'prolongation', 
    title: "Madda Vojib", 
    code: "o", 
    color: "#2144C1", 
    desc: "Majburiy va salobatli cho'zilish – oyatning vaznini belgilab beruvchi qat'iy cho'zish. Uni to'rt-besh harakat miqdorida cho'zish shart, aks holda oyatning go'zal muvozanati buziladi." 
  },
  { 
    id: 'm', 
    group: 'prolongation', 
    title: "Madda Lozim", 
    code: "m", 
    color: "#000EBC", 
    desc: "Eng uzun va quvvatli cho'zilish – tilovatning cho'qqisi bo'lib, to'liq olti harakat davom etuvchi buyuk cho'zish. U so'zdagi ma'noni yanada teranlashtirib, tinglovchining qalbini junbushga keltiradi." 
  },

  // Noon & Meem (Ghunnah/Ikhfa/Iqlab)
  { 
    id: 'g', 
    group: 'noon_meem', 
    title: "G'unnah", 
    code: "g", 
    color: "#FF7E1E", 
    desc: "Dimog'dan chiquvchi sehrli navo – go'yo ari g'o'ng'illashi kabi nafis ushlanib turuvchi ovoz. Nun va Mim harflari shaddali bo'lganda, ular o'zlarining bor jozibasini mana shu dimog' ovozi bilan ko'rsatadi." 
  },
  { 
    id: 'f', 
    group: 'noon_meem', 
    title: "Ixfa (Yashirish)", 
    code: "f", 
    color: "#9400A8", 
    desc: "Nun tovushini pinhon tutib, uni burun bo'shlig'ida nafislik bilan yashirib talaffuz etish san'ati. Bu tovush go'yo parda ortidagi shivir kabi mayin va yoqimli yangraydi." 
  },
  { 
    id: 'c', 
    group: 'noon_meem', 
    title: "Ixfa Shafaviy", 
    code: "c", 
    color: "#D500B7", 
    desc: "Lablar orqali yashiriluvchi Mim – go'yo sirlarni pinhon tutgandek, lablarni ohista birlashtirib o'qish. Bu qoida tilovatning ohangdorligini oshirib, harflar o'rtasidagi bog'liqlikni mustahkamlaydi." 
  },
  { 
    id: 'i', 
    group: 'noon_meem', 
    title: "Iqlab (Aylantirish)", 
    code: "i", 
    color: "#26BFFD", 
    desc: "Bir rangdan ikkinchi rangga o'tgandek, Nun tovushini ohista Mim tovushiga aylantiruvchi mo'jizaviy o'zgarish. Bunda tovush mayinlashib, keyingi harfga yo'l ochadi." 
  },

  // Idgham
  { 
    id: 'a', 
    group: 'idgham', 
    title: "Idg'om G'unnah", 
    code: "a", 
    color: "#169777", 
    desc: "Ikki ayro harfning bir vujudga aylanib, dimog'da go'zal ohang bilan birlashib ketishi. Bu birlashuv qiroatga yaxlitlik va musiqiy joziba bag'ishlaydi." 
  },
  { 
    id: 'u', 
    group: 'idgham', 
    title: "Idg'om Bila-G'unnah", 
    code: "u", 
    color: "#169200", 
    desc: "Hech qanday ortiqcha ovozsiz, ikki harfning bir-biriga shiddat va poklik bilan singishi. Bu qoida tilovatni tezlatib, ma'noning uzluksizligini ta'minlaydi." 
  },
  { 
    id: 'w', 
    group: 'idgham', 
    title: "Idg'om Shafaviy", 
    code: "w", 
    color: "#58B800", 
    desc: "Ikki o'xshash Mim harfining lablarda to'qnashib, bir ohangdor harfga aylanib ketishi. Lablar orasidagi bu harakat qiroatning eng nozik nuqtalaridan biridir." 
  },
  { 
    id: 'd', 
    group: 'idgham', 
    title: "Idg'om Mutajanisayn", 
    code: "d", 
    color: "#A1A1A1", 
    desc: "Chiqish joyi bir, ammo tabiati har xil bo'lgan harflarning do'stona birlashuvi va bir-biriga singib ketishi. Ular go'yo egizaklar kabi uyg'unlikda o'qiladi." 
  },
  { 
    id: 'b', 
    group: 'idgham', 
    title: "Idg'om Mutaqaribayn", 
    code: "b", 
    color: "#A1A1A1", 
    desc: "Bir-biriga yaqin va mahram bo'lgan harflarning o'zaro ittifoqi va birlashib o'qilishi. Bu qoida tilovatdagi qiyinchiliklarni bartaraf etib, so'zlarni yengil talaffuz qilishga yordam beradi." 
  }
];

const TajweedRulesView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');

  const tabs = [
    { id: 'all', name: 'Barchasi', icon: Layers },
    { id: 'prolongation', name: 'Madda (Cho\'zilish)', icon: Zap },
    { id: 'noon_meem', name: 'Nun va Mim', icon: Volume2 },
    { id: 'idgham', name: 'Idg\'om (Qo\'shish)', icon: Sparkles },
    { id: 'symbols', name: 'Belgi va Sado', icon: InfoIcon }
  ];

  const filteredRules = activeTab === 'all' 
    ? TAJWEED_RULES 
    : TAJWEED_RULES.filter(r => r.group === activeTab);

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 md:p-12 pb-40">
      <div className="max-w-6xl mx-auto">
        
        {/* Header Hero Section */}
        <div className="bg-emerald-600 rounded-[2.5rem] p-10 md:p-16 text-white mb-10 relative overflow-hidden shadow-2xl">
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 rounded-full mb-6 border border-white/10">
              <ShieldCheck size={14} />
              <span className="text-[10px] font-black uppercase tracking-widest italic">Ma'rifat Chirog'i</span>
            </div>
            <h2 className="text-3xl md:text-5xl font-black mb-4 leading-tight tracking-tight">Qur'on Ohangini <br/> Ranglar Jilvosida O'rganing</h2>
            <p className="text-emerald-100 text-sm md:text-base max-w-xl opacity-90 font-medium leading-relaxed italic">
              Har bir rang qiroatingizga bir nafosat, har bir kod oyatlarga bir sado beradi. Bu qo'llanma tilovatingizni tartil darajasiga ko'tarishda sizga yo'lchi bo'lgusi.
            </p>
          </div>
          <BookOpen className="absolute right-[-20px] top-[-20px] w-64 h-64 text-white/5" />
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {tabs.map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-2xl flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border-2 ${activeTab === tab.id ? 'bg-slate-900 text-white border-slate-900 shadow-lg' : 'bg-white text-slate-400 border-transparent hover:border-emerald-100 shadow-sm'}`}
            >
              <tab.icon size={16} /> {tab.name}
            </button>
          ))}
        </div>

        {/* Rules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRules.map((rule) => (
            <div key={rule.id} className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group overflow-hidden relative flex flex-col">
              <div className="flex items-center justify-between mb-6">
                 <div 
                   className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg"
                   style={{ backgroundColor: rule.color, boxShadow: `0 10px 20px ${rule.color}33` }}
                 >
                   [{rule.code}]
                 </div>
                 <div className="px-2.5 py-1 bg-slate-50 text-slate-300 rounded-lg text-[8px] font-black uppercase tracking-tighter">
                   {rule.group.replace('_', ' & ')}
                 </div>
              </div>
              
              <h4 className="text-lg font-black text-slate-900 mb-3 tracking-tight">{rule.title}</h4>
              <p className="text-slate-500 text-xs font-medium leading-relaxed mb-6 flex-1 italic">
                {rule.desc}
              </p>

              <div className="pt-4 border-t border-slate-50 flex items-center justify-between text-emerald-600">
                <span className="text-[9px] font-black uppercase tracking-widest">Qoidaga nazar solish</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
              
              <div 
                className="absolute -right-4 -bottom-4 w-24 h-24 rounded-full blur-[40px] opacity-0 group-hover:opacity-10 transition-opacity"
                style={{ backgroundColor: rule.color }}
              ></div>
            </div>
          ))}
        </div>

        {/* Final CTA */}
        <div className="mt-16 bg-white p-8 md:p-12 rounded-[2.5rem] border border-slate-100 text-center shadow-sm relative overflow-hidden">
           <div className="relative z-10">
             <h3 className="text-xl md:text-2xl font-black text-slate-900 mb-4">Ilohiy Kalomni Tartil Ila O'qing</h3>
             <p className="text-slate-400 text-sm font-medium mb-8 max-w-md mx-auto italic">
               Ushbu qoidalarni qalbingizga muhrlang va tilovatingizni sun'iy intellekt yordamida yanada yuksaltiring.
             </p>
             <button className="px-10 py-5 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95">
               Hifz Sari Olga
             </button>
           </div>
           <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 text-emerald-500/5 -z-0" />
        </div>

      </div>
    </div>
  );
};

export default TajweedRulesView;
