
import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';
import { t } from '../translations';

interface AudioRecorderProps {
  onRecordingComplete: (blob: Blob) => void;
  onStartRecording?: () => void;
  onStateChange?: (isRecording: boolean) => void;
  isProcessing: boolean;
  language: Language;
}

const AudioRecorder: React.FC<AudioRecorderProps> = ({ 
  onRecordingComplete, 
  onStartRecording, 
  onStateChange,
  isProcessing,
  language 
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerIntervalRef = useRef<number | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // Get current translations
  const text = t[language];

  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      stopRecordingCleanup();
    };
  }, []);

  const stopRecordingCleanup = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const startRecording = async () => {
    if (onStartRecording) {
      onStartRecording();
    }
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        chunksRef.current = [];
        onRecordingComplete(blob);
        stream.getTracks().forEach(track => track.stop());
        
        // Notify parent state
        if (onStateChange) onStateChange(false);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      if (onStateChange) onStateChange(true);
      
      setRecordingTime(0);
      
      timerIntervalRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Microphone access is required to recite.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col items-center justify-center">
      {isProcessing ? (
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-emerald-50 border border-emerald-100 shadow-sm animate-pulse">
           <div className="w-4 h-4 rounded-full bg-emerald-500 animate-ping"></div>
        </div>
      ) : (
        <button
          onClick={isRecording ? stopRecording : startRecording}
          className={`group relative flex items-center justify-center transition-all duration-300 shadow-md active:scale-95 ${
            isRecording 
              ? 'w-12 h-12 rounded-full bg-red-500 hover:bg-red-600 ring-2 ring-red-100' 
              : 'w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 ring-2 ring-emerald-50'
          }`}
          title={isRecording ? "Stop" : text.record}
        >
           {isRecording ? (
             <div className="w-4 h-4 bg-white rounded-sm shadow-sm"></div>
           ) : (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white drop-shadow-sm" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
             </svg>
           )}
           {isRecording && (
             <span className="absolute -top-8 bg-slate-800 text-white text-[10px] font-bold px-2 py-0.5 rounded-full font-mono shadow-md whitespace-nowrap">
               {formatTime(recordingTime)}
             </span>
           )}
        </button>
      )}
    </div>
  );
};

export default AudioRecorder;
