
import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, CheckCircle, RefreshCcw, Info } from 'lucide-react';
import { Ayah } from '../types';

interface TestingModeProps {
  ayah: Ayah;
  onComplete: () => void;
}

const TestingMode: React.FC<TestingModeProps> = ({ ayah, onComplete }) => {
  const [isListening, setIsListening] = useState(false);
  const [progress, setProgress] = useState(0);
  const [feedback, setFeedback] = useState("Tayyor bo'lsangiz, mikrofonni yoqing va tilovatni boshlang.");
  const [isMemorized, setIsMemorized] = useState(false);

  // Simulyatsiya: Haqiqiy Gemini Live integratsiyasi RecitationRoom dagi kabi bo'ladi
  const handleTest = () => {
    setIsListening(!isListening);
    if (!isListening) {
      // Progress simulyatsiyasi
      let current = 0;
      const interval = setInterval(() => {
        current += 5;
        setProgress(current);
        if (current >= 100) {
          clearInterval(interval);
          setIsMemorized(true);
          setFeedback("Ajoyib! Oyatni to'liq va to'g'ri yod olibsiz.");
          setIsListening(false);
          onComplete();
        }
      }, 200);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4">
      <div className="bg-white rounded-[2rem] shadow-xl p-8 border border-emerald-100 flex flex-col items-center gap-8">
        <div className="text-center w-full">
          <h3 className="text-emerald-800 font-bold mb-4 flex items-center justify-center gap-2">
            <Info className="w-4 h-4" /> Matn xira qilingan (Blur)
          </h3>
          <div className={`arabic-font text-5xl leading-relaxed text-slate-800 transition-all duration-1000 ${isMemorized ? 'blur-0' : 'blur-xl select-none'} dir-rtl`}>
            {ayah.text}
          </div>
        </div>

        <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-500 transition-all duration-300" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <button
            onClick={handleTest}
            className={`w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-90 ${isListening ? 'bg-red-500 animate-pulse' : 'bg-emerald-600'}`}
          >
            {isListening ? <MicOff className="text-white w-10 h-10" /> : <Mic className="text-white w-10 h-10" />}
          </button>
          <p className="text-slate-600 font-medium text-center">{feedback}</p>
        </div>

        {isMemorized && (
          <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-6 py-3 rounded-2xl animate-bounce">
            <CheckCircle className="w-6 h-6" />
            <span className="font-bold text-lg">Muvaffaqiyatli: Yodlandi!</span>
          </div>
        )}

        <button 
          onClick={() => { setProgress(0); setIsMemorized(false); setFeedback("Qayta urinib ko'ring."); }}
          className="text-slate-400 hover:text-emerald-600 flex items-center gap-2 text-sm font-bold uppercase tracking-widest"
        >
          <RefreshCcw className="w-4 h-4" /> Qayta boshlash
        </button>
      </div>
    </div>
  );
};

export default TestingMode;
