
import React, { useState } from 'react';
import { 
  Users, BarChart, Settings, Database, Edit3, Trash2, 
  Search, Shield, UserCheck, GraduationCap, X, Check,
  MoreVertical, Filter, Download
} from 'lucide-react';

interface UserRecord {
  id: string;
  name: string;
  phone: string;
  role: 'student' | 'ustoz' | 'admin';
  joinedAt: string;
  status: 'active' | 'inactive';
}

const MOCK_USERS: UserRecord[] = [
  { id: '1', name: 'Abdurahmon G\'ofurov', phone: '+998 90 123 45 67', role: 'admin', joinedAt: '2024-01-15', status: 'active' },
  { id: '2', name: 'Salimbek Orifov', phone: '+998 91 222 33 44', role: 'ustoz', joinedAt: '2024-02-10', status: 'active' },
  { id: '3', name: 'Oydina Karimova', phone: '+998 93 444 55 66', role: 'student', joinedAt: '2024-03-01', status: 'active' },
  { id: '4', name: 'Jasur Mavlonov', phone: '+998 94 555 66 77', role: 'student', joinedAt: '2024-03-05', status: 'inactive' },
  { id: '5', name: 'Malika Ergasheva', phone: '+998 97 777 88 99', role: 'ustoz', joinedAt: '2024-03-10', status: 'active' },
];

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<UserRecord[]>(MOCK_USERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingUser, setEditingUser] = useState<UserRecord | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.phone.includes(searchQuery)
  );

  const handleEditClick = (user: UserRecord) => {
    setEditingUser({ ...user });
    setIsModalOpen(true);
  };

  const handleSaveUser = () => {
    if (editingUser) {
      setUsers(users.map(u => u.id === editingUser.id ? editingUser : u));
      setIsModalOpen(false);
      setEditingUser(null);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Shield size={14} />;
      case 'ustoz': return <UserCheck size={14} />;
      default: return <GraduationCap size={14} />;
    }
  };

  const getRoleBadgeClass = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'ustoz': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    }
  };

  return (
    <div className="p-4 md:p-10 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-32">
      
      {/* Top Stats Section */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {[
          { label: 'Jami Foydalanuvchilar', value: users.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Faol Ustozlar', value: users.filter(u => u.role === 'ustoz').length, icon: UserCheck, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Yangi Talabalar', value: users.filter(u => u.role === 'student').length, icon: GraduationCap, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Tizim Holati', value: '100%', icon: Settings, color: 'text-slate-600', bg: 'bg-slate-50' }
        ].map((stat, i) => (
          <div key={i} className="bg-white p-5 md:p-6 rounded-[2rem] border border-slate-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className={`w-12 h-12 rounded-2xl ${stat.bg} flex items-center justify-center ${stat.color} shrink-0`}>
              <stat.icon size={24} />
            </div>
            <div className="min-w-0">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest truncate">{stat.label}</p>
              <p className="text-xl font-black text-slate-800">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Management Section */}
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        {/* Table Header / Toolbar */}
        <div className="p-6 md:p-8 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-black text-slate-800 tracking-tight">Foydalanuvchilar Boshqaruvi</h3>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Rollarni biriktirish va tahrirlash</p>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
              <input 
                type="text" 
                placeholder="Ism yoki telefon..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border-none rounded-xl text-xs font-bold focus:ring-2 focus:ring-emerald-500/20 transition-all"
              />
            </div>
            <button className="p-2.5 bg-slate-50 text-slate-400 rounded-xl hover:bg-slate-100 transition-colors">
              <Filter size={18} />
            </button>
            <button className="p-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-100">
              <Download size={18} />
            </button>
          </div>
        </div>

        {/* Desktop Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/50 text-[10px] uppercase tracking-[0.2em] text-slate-400 font-black">
              <tr>
                <th className="px-8 py-5">Foydalanuvchi</th>
                <th className="px-6 py-5">Rol</th>
                <th className="px-6 py-5">Sana</th>
                <th className="px-6 py-5">Holat</th>
                <th className="px-8 py-5 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="text-sm divide-y divide-slate-50">
              {filteredUsers.map(user => (
                <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-black text-slate-400 text-xs border-2 border-white shadow-sm">
                         {user.name.split(' ').map(n => n[0]).join('')}
                       </div>
                       <div className="flex flex-col">
                         <span className="font-black text-slate-800 text-sm">{user.name}</span>
                         <span className="text-[10px] font-bold text-slate-400">{user.phone}</span>
                       </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${getRoleBadgeClass(user.role)}`}>
                      {getRoleIcon(user.role)}
                      {user.role}
                    </div>
                  </td>
                  <td className="px-6 py-5 text-slate-400 font-bold text-xs">{user.joinedAt}</td>
                  <td className="px-6 py-5">
                    <div className={`flex items-center gap-1.5 ${user.status === 'active' ? 'text-emerald-500' : 'text-slate-300'}`}>
                       <div className={`w-1.5 h-1.5 rounded-full ${user.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                       <span className="text-[10px] font-black uppercase tracking-widest">{user.status === 'active' ? 'Faol' : 'Nofaol'}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => handleEditClick(user)}
                        className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit User Modal */}
      {isModalOpen && editingUser && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)} />
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl relative z-10 overflow-hidden animate-in zoom-in-95 duration-200">
             <div className="p-8 border-b border-slate-50 flex items-center justify-between">
                <div>
                   <h4 className="text-xl font-black text-slate-800 tracking-tight">Foydalanuvchini tahrirlash</h4>
                   <p className="text-slate-400 text-[10px] font-bold uppercase mt-1">ID: {editingUser.id}</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-300 hover:text-slate-600">
                  <X size={24} />
                </button>
             </div>

             <div className="p-8 space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest">To'liq ism</label>
                   <input 
                    type="text" 
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({...editingUser, name: e.target.value})}
                    className="w-full px-5 py-3.5 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500/20 font-bold text-slate-700 transition-all"
                   />
                </div>

                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Tizimdagi roli</label>
                   <div className="grid grid-cols-3 gap-2">
                      {['student', 'ustoz', 'admin'].map((role) => (
                        <button 
                          key={role}
                          onClick={() => setEditingUser({...editingUser, role: role as any})}
                          className={`py-3 rounded-xl text-[10px] font-black uppercase transition-all border-2 ${editingUser.role === role ? 'bg-emerald-600 border-emerald-600 text-white shadow-lg' : 'bg-slate-50 border-transparent text-slate-400 hover:bg-slate-100'}`}
                        >
                          {role}
                        </button>
                      ))}
                   </div>
                </div>

                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Hisob holati</label>
                   <div className="flex bg-slate-50 p-1 rounded-2xl">
                      <button 
                        onClick={() => setEditingUser({...editingUser, status: 'active'})}
                        className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${editingUser.status === 'active' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}
                      >
                        Faol
                      </button>
                      <button 
                        onClick={() => setEditingUser({...editingUser, status: 'inactive'})}
                        className={`flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase transition-all ${editingUser.status === 'inactive' ? 'bg-white text-red-600 shadow-sm' : 'text-slate-400'}`}
                      >
                        Nofaol
                      </button>
                   </div>
                </div>
             </div>

             <div className="p-8 pt-0 flex gap-3">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-slate-50 text-slate-400 font-black text-[11px] uppercase tracking-widest rounded-2xl hover:bg-slate-100 transition-all"
                >
                  Bekor qilish
                </button>
                <button 
                  onClick={handleSaveUser}
                  className="flex-1 py-4 bg-emerald-600 text-white font-black text-[11px] uppercase tracking-widest rounded-2xl shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                >
                  <Check size={18} /> Saqlash
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
