
import React, { useState, useEffect, useRef } from 'react';
import { Surah, CombinedAyahData, AppMode, Language } from '../types';
import { fetchSurahData, fetchWordTimings } from '../services/quranService';
import { AyahSkeleton } from './Skeleton';
import { 
  Play, Pause, ChevronLeft, ChevronRight, Repeat, Repeat1, 
  Users, ChevronDown, Check
} from 'lucide-react';
import { parseTajweed } from '../utils/tajweedParser';

interface LearningProps {
  surah: Surah;
  currentIdx: number;
  onAyahChange: (idx: number) => void;
  onModeChange: (m: AppMode) => void;
}

const RECITERS = [
  { id: 'ar.alafasy', name: 'Mishary Alafasy' },
  { id: 'ar.husary', name: 'Khalil Al-Husary' },
  { id: 'ar.minshawi', name: 'Siddiq El-Minshawi' },
  { id: 'ar.abdulsamad', name: 'AbdulBaset AbdulSamad' },
  { id: 'ar.abdurrahmansudais', name: 'Abdurrahman Sudais' }
];

const Learning: React.FC<LearningProps> = ({ surah, currentIdx, onAyahChange }) => {
  const [ayahs, setAyahs] = useState<CombinedAyahData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedReciter, setSelectedReciter] = useState('ar.alafasy');
  const [repeatMode, setRepeatMode] = useState<'single' | 'surah'>('surah');
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [activeWordIdx, setActiveWordIdx] = useState<number | null>(null);
  const [wordTimings, setWordTimings] = useState<any[]>([]);
  const [showReciterDropdown, setShowReciterDropdown] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const requestRef = useRef<number | undefined>(undefined);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadSurah = async () => {
      setIsLoading(true);
      try {
        const data = await fetchSurahData(surah.number, Language.UZ, selectedReciter);
        setAyahs(data || []);
      } catch (err) {
        console.error("Sura yuklashda xatolik:", err);
      } finally {
        setIsLoading(false);
      }
    };
    loadSurah();
  }, [surah.number, selectedReciter]);

  useEffect(() => {
    if (isPlaying && audioRef.current && ayahs.length > 0) {
      audioRef.current.pause();
      audioRef.current.load();
      audioRef.current.play().catch(e => console.log("Autoplay blocked or failed", e));
    }
  }, [currentIdx, ayahs]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowReciterDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const syncWords = () => {
      if (audioRef.current && !audioRef.current.paused) {
        const time = audioRef.current.currentTime;
        const active = wordTimings.find(t => time >= t.start && time < t.end);
        if (active && activeWordIdx !== active.id) {
          setActiveWordIdx(active.id);
        }
        requestRef.current = requestAnimationFrame(syncWords);
      }
    };
    if (isPlaying) requestRef.current = requestAnimationFrame(syncWords);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [isPlaying, wordTimings, activeWordIdx]);

  const updateTimings = async () => {
    if (ayahs[currentIdx] && audioRef.current) {
      const timings = await fetchWordTimings(ayahs[currentIdx].tajweed || "", audioRef.current.duration);
      setWordTimings(timings);
    }
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = playbackSpeed;
      audioRef.current.play().then(() => setIsPlaying(true));
    }
  };

  const handleAudioEnd = () => {
    if (repeatMode === 'single') {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    } else {
      if (currentIdx < ayahs.length - 1) {
        onAyahChange(currentIdx + 1);
      } else {
        setIsPlaying(false);
      }
    }
  };

  if (isLoading) return <AyahSkeleton />;
  const currentAyah = ayahs[currentIdx] || ayahs[0];
  const currentReciter = RECITERS.find(r => r.id === selectedReciter);

  return (
    <div className="flex flex-col h-full bg-white relative overflow-hidden">
      
      {/* Oyat matni maydoni */}
      <div className="flex-1 overflow-y-auto px-4 pt-4 pb-12 flex flex-col items-center">
        <div className="max-w-5xl w-full text-center relative py-12 md:py-24">
          <div className="text-[120px] md:text-[240px] font-black text-slate-100 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -z-0 opacity-20 select-none pointer-events-none tracking-tighter">
            {currentAyah?.numberInSurah}
          </div>
          
          <div className="relative z-10 mb-10 md:mb-16" dir="rtl">
            <div className="arabic-font text-4xl md:text-5xl lg:text-7xl leading-[2.6] md:leading-[3] text-slate-800 px-4">
               {(currentAyah?.tajweed || "").split(' ').map((word, idx) => (
                 <span 
                  id={`word-${idx}`} 
                  key={idx} 
                  className={`word ${activeWordIdx === idx ? 'active' : ''}`} 
                  dangerouslySetInnerHTML={{ __html: parseTajweed(word) }} 
                />
               ))}
            </div>
          </div>
          
          <div className="relative z-10 px-8 max-w-4xl mx-auto">
            <p className="text-slate-500 text-sm md:text-2xl font-medium italic leading-relaxed opacity-70 border-t border-slate-50 pt-8">
              "{currentAyah?.translation}"
            </p>
          </div>
        </div>
      </div>

      {/* Player Panel (Desktop: Fixed above bottom, Mobile: Inline above bottom nav) */}
      <div className="shrink-0 bg-white/95 backdrop-blur-md border-t border-slate-100 px-3 py-4 md:px-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-[200]">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
          
          <div className="flex-1 flex items-center justify-start min-w-0">
            <div className="relative" ref={dropdownRef}>
              <button 
                onClick={() => setShowReciterDropdown(!showReciterDropdown)} 
                className="flex items-center gap-2 px-2.5 py-2.5 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all border border-slate-100 shadow-sm shrink-0"
              >
                <Users size={16} className="text-emerald-600" />
                <div className="hidden sm:block text-left">
                  <p className="text-[7px] font-black text-slate-400 uppercase leading-none mb-0.5 tracking-widest">Qiroat</p>
                  <p className="text-[11px] font-black text-slate-800 truncate max-w-[80px]">
                    {currentReciter?.name.split(' ').pop()}
                  </p>
                </div>
                <ChevronDown size={12} className={`text-slate-300 transition-transform ${showReciterDropdown ? 'rotate-180' : ''}`} />
              </button>
              
              {showReciterDropdown && (
                <div className="absolute bottom-full left-0 mb-3 w-48 md:w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-1.5 animate-in slide-in-from-bottom-2 z-[300]">
                   <div className="p-2 text-[8px] font-black text-slate-300 uppercase tracking-widest border-b border-slate-50 mb-1">Qorini tanlang</div>
                   {RECITERS.map(r => (
                     <button 
                       key={r.id} 
                       onClick={() => { setSelectedReciter(r.id); setShowReciterDropdown(false); }} 
                       className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-[10px] md:text-[11px] font-bold ${selectedReciter === r.id ? 'bg-emerald-50 text-emerald-600' : 'hover:bg-slate-50 text-slate-600'}`}
                     >
                        <span className="truncate">{r.name}</span>
                        {selectedReciter === r.id && <Check size={12} />}
                     </button>
                   ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-center gap-3 sm:gap-6 md:gap-10">
            <button 
              onClick={() => onAyahChange(Math.max(0, currentIdx - 1))} 
              className="text-slate-300 hover:text-emerald-600 transition-all active:scale-90 p-1 shrink-0"
            >
              <ChevronLeft size={28} className="md:size-10" />
            </button>
            
            <button 
              onClick={togglePlay} 
              className="w-12 h-12 md:w-16 md:h-16 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-emerald-200/50 hover:scale-105 active:scale-95 transition-all shrink-0 aspect-square"
            >
              {isPlaying ? <Pause size={24} className="md:size-8" fill="white" /> : <Play size={24} className="md:size-8 ml-0.5" fill="white" />}
            </button>
            
            <button 
              onClick={() => onAyahChange(Math.min(ayahs.length - 1, currentIdx + 1))} 
              className="text-slate-300 hover:text-emerald-600 transition-all active:scale-90 p-1 shrink-0"
            >
              <ChevronRight size={28} className="md:size-10" />
            </button>
          </div>

          <div className="flex-1 flex items-center justify-end gap-1.5 md:gap-3">
             <button 
               onClick={() => setRepeatMode(repeatMode === 'surah' ? 'single' : 'surah')} 
               className={`w-9 h-9 md:w-11 md:h-11 rounded-xl flex items-center justify-center transition-all border shrink-0 ${repeatMode === 'single' ? 'bg-emerald-600 text-white border-emerald-500 shadow-md' : 'bg-white text-slate-300 border-slate-100 hover:border-emerald-200 hover:text-emerald-600'}`}
               title={repeatMode === 'single' ? "Oyatni qaytarish" : "Surani qaytarish"}
             >
               {repeatMode === 'single' ? <Repeat1 size={16} className="md:size-5" /> : <Repeat size={16} className="md:size-5" />}
             </button>
             
             <button 
               onClick={() => setPlaybackSpeed(playbackSpeed === 1 ? 1.5 : playbackSpeed === 1.5 ? 2 : 1)} 
               className={`w-9 h-9 md:w-11 md:h-11 rounded-xl flex items-center justify-center text-[10px] md:text-[11px] font-black transition-all border shrink-0 ${playbackSpeed !== 1 ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-white text-slate-400 border-slate-100 hover:border-emerald-200'}`}
               title="Tezlik"
             >
               {playbackSpeed}x
             </button>
          </div>
        </div>
      </div>

      <audio 
        ref={audioRef} 
        src={currentAyah?.audioUrl} 
        onEnded={handleAudioEnd} 
        onPlay={() => setIsPlaying(true)} 
        onPause={() => setIsPlaying(false)} 
        onLoadedMetadata={updateTimings} 
        preload="auto"
      />
    </div>
  );
};

export default Learning;
