
import React, { useState, useRef, useEffect } from 'react';
import { Language, AppMode, IdentificationJSON } from '../types';
import AudioRecorder from './AudioRecorder';
import { sendMessageToHafiz, blobToBase64 } from '../services/geminiService';
import { Play, Search, Sparkles, BookOpen, ChevronRight, CheckCircle2, AlertTriangle, Activity } from 'lucide-react';
import { parseTajweedAndWrap } from '../utils/tajweedParser';

interface Props {
  language: Language;
  onGoToAyah: (surah: number, ayah: number) => void;
}

const AnalysisView: React.FC<Props> = ({ language, onGoToAyah }) => {
  const [inputText, setInputText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<IdentificationJSON | null>(null);
  const [playingUrl, setPlayingUrl] = useState<string | null>(null);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const handleIdentification = async (audioBlob?: Blob) => {
    if (!audioBlob && !inputText.trim()) return;
    setIsProcessing(true);
    try {
      let base64Audio = undefined;
      let mimeType = undefined;
      if (audioBlob) {
         base64Audio = await blobToBase64(audioBlob);
         mimeType = audioBlob.type;
      }
      const context = { mode: AppMode.ANALYSIS, task: 'identification' };
      const prompt = audioBlob ? "Audiodagi tilovatni tahlil qiling." : `Qidiruv: "${inputText}"`;
      const response = await sendMessageToHafiz(context, prompt, base64Audio, mimeType);
      const data = JSON.parse(response) as IdentificationJSON;
      setResults(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
      setInputText("");
    }
  };

  const playAyahAudio = (globalAyahId: number) => {
    const url = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyahId}.mp3`;
    if (playingUrl === url) {
      audioRef.current?.pause();
      setPlayingUrl(null);
      return;
    }
    setPlayingUrl(url);
    if (audioRef.current) audioRef.current.pause();
    audioRef.current = new Audio(url);
    audioRef.current.play();
    audioRef.current.onended = () => setPlayingUrl(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] overflow-hidden">
      
      {/* COMPACT HEADER */}
      <header className="h-16 shrink-0 bg-white border-b border-slate-100 flex items-center justify-between px-4 md:px-6 z-20 shadow-sm">
        <div className="flex items-center gap-3">
           <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shrink-0">
             <Search size={18} />
           </div>
           <div>
             <h2 className="text-[13px] font-black text-slate-800 leading-tight">Oyat Qidirish</h2>
             <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-0.5">Ma'no yoki tilovat orqali</p>
           </div>
        </div>
      </header>

      {/* SCROLLABLE RESULTS AREA */}
      <div className="flex-1 overflow-y-auto bg-white/50 relative">
        <div className="max-w-3xl mx-auto p-4 md:p-6 space-y-6">
          {results ? (
             <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className={`p-4 rounded-2xl border mb-6 flex items-center gap-3 ${results.message.includes('100%') ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-amber-50 border-amber-100 text-amber-700'}`}>
                   <Activity size={18} />
                   <p className="text-[11px] font-bold italic">"{results.message}"</p>
                </div>
                
                <div className="space-y-4">
                  {(results.matches || []).map((match, idx) => (
                      <div key={idx} className="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-sm hover:shadow-md transition-all">
                          <div className="flex items-center justify-between mb-6">
                             <div className="flex flex-col">
                               <h4 className="text-[13px] font-black text-slate-800">{match.surah_name}</h4>
                               <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{match.ayah_number}-oyat</p>
                             </div>
                             <div className="bg-emerald-50 px-3 py-1 rounded-full text-[10px] font-black text-emerald-600 uppercase tracking-widest">
                               {Math.round(match.confidence * 100)}% moslik
                             </div>
                          </div>
                          <div className="arabic-font text-3xl md:text-5xl text-center leading-[2.4] text-slate-900 mb-8" dir="rtl" dangerouslySetInnerHTML={{ __html: parseTajweedAndWrap(match.tajweed || match.text) }} />
                          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 mb-8 text-center">
                             <p className="text-[14px] text-slate-500 font-medium italic">"{match.translation}"</p>
                          </div>
                          <div className="flex gap-3">
                              <button onClick={() => playAyahAudio(match.global_ayah_number)} className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${playingUrl?.includes(String(match.global_ayah_number)) ? 'bg-amber-500 text-white shadow-lg' : 'bg-slate-100 text-slate-400 hover:bg-emerald-50 hover:text-emerald-600'}`}>
                                <Play size={20} fill={playingUrl?.includes(String(match.global_ayah_number)) ? "white" : "none"} />
                              </button>
                              <button onClick={() => onGoToAyah(match.surah_number, match.ayah_number)} className="flex-1 bg-emerald-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-2">
                                Oyatni o'rganish <ChevronRight size={16} />
                              </button>
                          </div>
                      </div>
                  ))}
                </div>
             </div>
          ) : (
             <div className="flex flex-col items-center justify-center h-[60vh] text-center px-10">
                {isProcessing ? (
                   <div className="flex flex-col items-center gap-4 animate-pulse">
                      <div className="w-12 h-12 border-4 border-emerald-50 border-t-emerald-600 rounded-full animate-spin" />
                      <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Qidirilmoqda...</span>
                   </div>
                ) : (
                   <div className="space-y-4 max-w-sm">
                      <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center mx-auto border border-slate-50">
                        <Search size={32} className="text-slate-100" />
                      </div>
                      <h3 className="text-slate-800 font-black text-[14px] uppercase tracking-widest">Oyat Qidiruvi</h3>
                      <p className="text-slate-400 text-[11px] font-medium leading-relaxed">Oyatning ma'nosini yozing yoki tilovat qilib bering. AI eng mos javobni topadi.</p>
                   </div>
                )}
             </div>
          )}
        </div>
      </div>

      {/* COMPACT INPUT FOOTER */}
      <footer className="shrink-0 bg-white border-t border-slate-100 p-4 md:p-6 z-30 shadow-[0_-10px_40px_rgba(0,0,0,0.02)]">
         <div className="max-w-2xl mx-auto">
            <div className="bg-slate-50 p-1.5 rounded-full border border-slate-100 flex items-center gap-2 transition-all focus-within:ring-4 focus-within:ring-emerald-50 focus-within:bg-white focus-within:border-emerald-100">
               <div className="flex-1 relative flex items-center">
                  <Search size={18} className="absolute left-4 text-slate-300" />
                  <input 
                    type="text" 
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleIdentification()}
                    placeholder="Ma'no bo'yicha qidiring..."
                    className="w-full pl-12 pr-4 py-3 bg-transparent border-none outline-none font-bold text-slate-700 text-sm placeholder:text-slate-200"
                  />
               </div>
               <AudioRecorder onRecordingComplete={handleIdentification} isProcessing={isProcessing} language={language} />
               <button onClick={() => handleIdentification()} disabled={!inputText.trim() || isProcessing} className="w-11 h-11 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-emerald-700 active:scale-95 transition-all disabled:opacity-20 shrink-0">
                  <Search size={18} />
               </button>
            </div>
         </div>
      </footer>
    </div>
  );
};

export default AnalysisView;
