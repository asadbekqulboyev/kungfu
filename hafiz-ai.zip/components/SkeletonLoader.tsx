
import React from 'react';

export const SurahListSkeleton = () => (
  <div className="space-y-4 p-4">
    {[1, 2, 3, 4, 5].map(i => (
      <div key={i} className="h-20 bg-emerald-50/50 animate-pulse rounded-2xl border border-emerald-100"></div>
    ))}
  </div>
);

export const AyahSkeleton = () => (
  <div className="space-y-6 p-8">
    <div className="h-8 bg-slate-100 animate-pulse w-1/3 mx-auto rounded"></div>
    <div className="h-32 bg-slate-100 animate-pulse w-full rounded-3xl"></div>
    <div className="h-12 bg-slate-100 animate-pulse w-2/3 mx-auto rounded"></div>
  </div>
);
