
import React from 'react';
import { Language, AppMode } from '../types';
import { t } from '../translations';
import { Globe, Calendar, MessageSquare, ChevronRight, ShieldCheck, Zap, Star, Mic, ArrowUpRight, Award, Users, BookOpen } from 'lucide-react';

interface Props {
  language: Language;
  setLanguage: (lang: Language) => void;
  onModeChange: (mode: AppMode) => void;
}

const LandingPage: React.FC<Props> = ({ language, setLanguage, onModeChange }) => {
  const text = t[language];

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 overflow-x-hidden selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* --- Floating Navbar --- */}
      <nav className="fixed top-0 left-0 right-0 z-[200] px-3 py-3 md:px-6 md:py-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center bg-white/80 backdrop-blur-xl border border-slate-100 px-4 py-2.5 md:px-8 md:py-4 rounded-2xl md:rounded-[3rem] shadow-sm">
          <div className="flex items-center gap-2 md:gap-4 group cursor-pointer">
            <div className="w-8 h-8 md:w-11 md:h-11 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-emerald-100 shrink-0">
               <span className="font-serif font-black text-lg md:text-2xl">H</span>
            </div>
            <div className="flex flex-col min-w-0">
              <h1 className="text-[10px] md:text-base font-black text-slate-950 tracking-tight uppercase leading-none truncate">Hafiz AI</h1>
              <span className="text-[7px] md:text-[9px] font-black text-emerald-600 uppercase tracking-[0.2em] mt-1 truncate">Smart Tutor</span>
            </div>
          </div>

          <div className="flex items-center gap-2 md:gap-4">
             <button 
               onClick={() => setLanguage(language === Language.EN ? Language.UZ : Language.EN)}
               className="flex items-center gap-1.5 px-2.5 py-1.5 md:px-5 md:py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-full border border-slate-100 transition-all text-[8px] md:text-[10px] font-black uppercase tracking-widest shrink-0"
             >
               <Globe size={12} className="text-emerald-500" /> 
               <span>{language === Language.EN ? 'UZ' : 'EN'}</span>
             </button>
             
             <button 
               onClick={() => onModeChange(AppMode.TEACHING)}
               className="px-4 py-2 md:px-8 md:py-3 bg-slate-950 text-white rounded-full text-[8px] md:text-[10px] font-black uppercase tracking-widest hover:bg-emerald-600 transition-all active:scale-95 flex items-center gap-1.5 group shrink-0"
             >
               Kirish <ArrowUpRight size={12} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
             </button>
          </div>
        </div>
      </nav>

      {/* --- Hero Section --- */}
      <section className="relative pt-24 md:pt-48 pb-16 md:pb-32 px-4">
        {/* Background Decorative Grid */}
        <div className="absolute top-0 left-0 w-full h-full -z-10 opacity-20 pointer-events-none">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="grid-hero" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.05" className="text-emerald-500" />
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#grid-hero)" />
          </svg>
        </div>

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          
          <div className="relative z-10 text-center lg:text-left order-2 lg:order-1">
             <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 rounded-full text-emerald-700 text-[8px] md:text-[10px] font-black uppercase tracking-[0.2em] mb-6 border border-emerald-100 mx-auto lg:mx-0">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div> Kelajak Texnologiyasi & Ma'rifat
             </div>
             
             <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-black text-slate-950 leading-[1.1] mb-6 tracking-tight">
               Qur'onni <span className="text-emerald-600 italic">Hafiz AI</span> <br className="hidden md:block" /> Bilan Hifz Qiling
             </h2>
             
             <p className="text-sm md:text-lg text-slate-500 font-medium leading-relaxed mb-10 max-w-lg mx-auto lg:mx-0">
               Sun'iy intellekt yordamida tilovatingizni tekshiring, tajvidingizni mukammallashtiring va shaxsiy hifz rejangiz asosida muvaffaqiyatga erishing.
             </p>
             
             <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center lg:justify-start">
                <button 
                  onClick={() => onModeChange(AppMode.TEACHING)}
                  className="px-8 py-5 md:px-12 md:py-6 bg-emerald-600 text-white rounded-2xl font-black text-[10px] md:text-xs uppercase tracking-widest shadow-2xl shadow-emerald-200 hover:bg-emerald-700 hover:-translate-y-1 transition-all flex items-center justify-center gap-3 group"
                >
                  O'rganishni boshlash <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button 
                  onClick={() => onModeChange(AppMode.HIFZ_PLAN)}
                  className="px-8 py-5 md:px-10 md:py-6 bg-white text-slate-800 border border-slate-200 rounded-2xl font-black text-[10px] md:text-xs uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center justify-center gap-3 shadow-sm"
                >
                  <Calendar size={20} className="text-emerald-500" /> Hifz rejasi
                </button>
             </div>

             <div className="mt-12 md:mt-16 flex flex-col md:flex-row items-center justify-center lg:justify-start gap-6">
                <div className="flex -space-x-3">
                   {[1, 2, 3, 4].map(i => (
                     <div key={i} className="w-10 h-10 md:w-12 md:h-12 rounded-full border-4 border-white bg-slate-100 shadow-md overflow-hidden shrink-0">
                        <img 
                          src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i + 20}`} 
                          alt="Student" 
                          className="w-full h-full object-cover" 
                        />
                     </div>
                   ))}
                   <div className="w-10 h-10 md:w-12 md:h-12 rounded-full border-4 border-white bg-emerald-600 flex items-center justify-center text-white text-[10px] font-black shadow-md shrink-0">
                      +12k
                   </div>
                </div>
                <div className="flex flex-col items-center md:items-start">
                  <div className="flex items-center gap-1.5 mb-1">
                     {[...Array(5)].map((_, i) => <Star key={i} size={12} className="fill-amber-400 text-amber-400" />)}
                  </div>
                  <div className="text-slate-400 text-[8px] font-black uppercase tracking-widest">
                    <span className="text-slate-900">4.9/5</span> Reyting • Dunyo bo'ylab
                  </div>
                </div>
             </div>
          </div>

          {/* RIGHT SIDE: BEAUTIFUL QURAN HERO IMAGE */}
          <div className="relative order-1 lg:order-2 animate-in fade-in zoom-in duration-1000 lg:h-[700px] flex items-center justify-center">
             
             {/* Glow Backdrop */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-emerald-100 rounded-full blur-[120px] opacity-40 animate-pulse"></div>
             
             <div className="relative w-full max-w-lg lg:max-w-xl group">
                {/* Floating Elements */}
                <div className="absolute -top-10 -left-6 md:-left-12 z-20 bg-white p-4 md:p-6 rounded-3xl shadow-2xl border border-slate-50 flex items-center gap-4 animate-bounce-slow">
                   <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 shadow-inner">
                      <Award size={24} />
                   </div>
                   <div>
                      <h4 className="font-black text-slate-800 text-[10px] md:text-xs">Muvaffaqiyatli Hifz</h4>
                      <p className="text-[8px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Sura: Al-Mulk</p>
                   </div>
                </div>

                <div className="absolute -bottom-6 -right-6 md:-right-10 z-20 bg-slate-950 p-5 md:p-7 rounded-[2.5rem] shadow-2xl border border-white/10 flex flex-col items-center gap-4 animate-[float_4s_ease-in-out_infinite]">
                   <div className="flex items-center justify-center gap-1">
                      {[...Array(10)].map((_, i) => (
                        <div key={i} className="w-1 bg-emerald-400 rounded-full animate-wave" style={{ height: `${10 + Math.random() * 30}px`, animationDelay: `${i * 0.1}s` }}></div>
                      ))}
                   </div>
                   <div className="text-center">
                      <p className="text-[7px] md:text-[9px] font-black text-emerald-400 uppercase tracking-[0.3em] mb-1">Jonli Analiz</p>
                      <p className="text-[12px] md:text-base font-black text-white">99.2% Aniqlik</p>
                   </div>
                </div>

                {/* Main Quran Image Container */}
                <div className="relative rounded-[4rem] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.15)] border-[12px] border-white/50 backdrop-blur-md bg-white/20">
                   <div className="aspect-[4/5] md:aspect-square lg:h-[600px] bg-slate-100 relative overflow-hidden">
                      <img 
                        src="https://images.unsplash.com/photo-1609599006353-e629aaabfeae?q=80&w=1200&auto=format&fit=crop" 
                        alt="The Holy Quran" 
                        className="w-full h-full object-cover scale-105 group-hover:scale-100 transition-transform duration-[6s] ease-out"
                        loading="eager"
                      />
                      {/* Artistic Overlays */}
                      <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/40 via-transparent to-emerald-950/20"></div>
                      <div className="absolute inset-0 bg-emerald-600/10 mix-blend-overlay"></div>
                      
                      {/* Floating Particles (CSS Only) */}
                      <div className="absolute inset-0 overflow-hidden pointer-events-none">
                         {[...Array(6)].map((_, i) => (
                           <div 
                             key={i} 
                             className="absolute w-2 h-2 bg-white/40 rounded-full blur-[2px] animate-pulse"
                             style={{ 
                               top: `${Math.random() * 100}%`, 
                               left: `${Math.random() * 100}%`,
                               animationDuration: `${2 + Math.random() * 3}s`
                             }}
                           ></div>
                         ))}
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* --- Statistika --- */}
      <section className="py-12 md:py-24 border-y border-slate-50 bg-white relative z-10">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { label: 'Talabalar', value: '18K+', icon: Users, color: 'text-blue-500' },
            { label: 'Mukofotlar', value: '120+', icon: Award, color: 'text-amber-500' },
            { label: 'Oyatlar Tahlili', value: '2.4M+', icon: Zap, color: 'text-emerald-500' },
            { label: 'Suralar', value: '114', icon: BookOpen, color: 'text-purple-500' }
          ].map((stat, i) => (
            <div key={i} className="flex flex-col items-center text-center group">
              <div className={`flex items-center gap-2 ${stat.color} mb-3`}>
                 <stat.icon size={16} />
                 <span className="text-[8px] md:text-[10px] font-black uppercase tracking-widest text-slate-400">{stat.label}</span>
              </div>
              <div className="text-2xl md:text-4xl font-black text-slate-900 tracking-tighter">{stat.value}</div>
            </div>
          ))}
        </div>
      </section>

      {/* --- Xususiyatlar --- */}
      <section className="py-20 md:py-40 bg-slate-50/50 relative z-10">
        <div className="max-w-7xl mx-auto px-4">
           <div className="text-center mb-16 md:mb-32">
              <h3 className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.4em] mb-4">Afzalliklarimiz</h3>
              <h2 className="text-3xl md:text-5xl font-black text-slate-950 tracking-tight">Qur'on o'rganishda yangi davr</h2>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
              {[
                { title: 'Jonli Tajvid', icon: ShieldCheck, desc: 'AI tilovatingizdagi makhraj va g\'unna xatolarini real vaqtda aniqlab, darhol tuzatib beradi.', color: 'emerald' },
                { title: 'Aqlli Hifz', icon: Calendar, desc: 'Sizning qobiliyatingiz va bo\'sh vaqtingizga qarab individual yodlash jadvalini generatsiya qiladi.', color: 'amber' },
                { title: 'Ustoz Muloqoti', icon: MessageSquare, desc: 'Murakkab savollaringiz bo\'lsa, real mutaxassislarimiz bilan chat orqali maslahat olish imkoniyati.', color: 'blue' }
              ].map((f, i) => (
                <div key={i} className="bg-white p-10 md:p-14 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:-translate-y-2 transition-all group relative overflow-hidden">
                   <div className={`w-14 h-14 md:w-20 md:h-20 rounded-3xl flex items-center justify-center mb-8 md:mb-12 transition-all ${f.color === 'emerald' ? 'bg-emerald-50 text-emerald-600 shadow-emerald-50' : f.color === 'amber' ? 'bg-amber-50 text-amber-600 shadow-amber-50' : 'bg-blue-50 text-blue-600 shadow-blue-50'} shadow-inner`}>
                      <f.icon size={28} className="md:size-10" />
                   </div>
                   <h4 className="text-xl md:text-2xl font-black text-slate-900 mb-4">{f.title}</h4>
                   <p className="text-sm md:text-base text-slate-500 font-medium leading-relaxed">{f.desc}</p>
                   
                   {/* Decorative circle */}
                   <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-slate-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* --- Footer --- */}
      <footer className="py-16 md:py-32 border-t border-slate-100 px-4 bg-white relative z-10">
         <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16 md:mb-24 text-center md:text-left">
               <div className="md:col-span-2">
                  <div className="flex items-center justify-center md:justify-start gap-4 mb-6">
                     <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black text-2xl">H</div>
                     <h3 className="text-2xl font-black text-slate-900">Hafiz AI</h3>
                  </div>
                  <p className="text-slate-400 text-sm md:text-base font-medium max-w-sm mx-auto md:mx-0 leading-relaxed">
                     Eng zamonaviy texnologiyalar orqali muqaddas kalomni o'rganishni har bir xonadon uchun oson va maroqli qilish - bizning maqsadimizdir.
                  </p>
               </div>
               <div>
                  <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-6">Asosiy</h4>
                  <ul className="space-y-4">
                     {['O\'rganish', 'Hifz Rejasi', 'Tajvid', 'Qidiruv'].map(l => (
                       <li key={l}><a href="#" className="text-xs md:text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors uppercase tracking-tight">{l}</a></li>
                     ))}
                  </ul>
               </div>
               <div>
                  <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-6">Bog'lanish</h4>
                  <ul className="space-y-4">
                     {['Yordam', 'Maxfiylik', 'Qoidalar', 'Aloqa'].map(l => (
                       <li key={l}><a href="#" className="text-xs md:text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors uppercase tracking-tight">{l}</a></li>
                     ))}
                  </ul>
               </div>
            </div>
            <div className="pt-10 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6">
               <p className="text-[9px] md:text-[11px] font-black text-slate-300 uppercase tracking-widest">© 2025 Hafiz AI. Barcha huquqlar himoyalangan.</p>
               <div className="flex gap-8">
                  <a href="#" className="text-[9px] md:text-[11px] font-black text-slate-400 hover:text-emerald-600 transition-colors uppercase tracking-[0.2em]">Privacy Policy</a>
                  <a href="#" className="text-[9px] md:text-[11px] font-black text-slate-400 hover:text-emerald-600 transition-colors uppercase tracking-[0.2em]">Terms of Service</a>
               </div>
            </div>
         </div>
      </footer>

      {/* Custom Styles for Keyframes */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-20px); }
        }
        .animate-float {
          animation: float 5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default LandingPage;
