
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Video, Play, Download, Loader2, Sparkles } from 'lucide-react';

const VideoGen: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState('');

  const generateVideo = async () => {
    if (!prompt.trim() || isGenerating) return;

    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio.openSelectKey();
      return;
    }

    setIsGenerating(true);
    setLoadingStep('Inisializatsiya qilinmoqda...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      setLoadingStep('Video generatsiya qilinmoqda (bu bir necha daqiqa olishi mumkin)...');

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await response.blob();
        setVideoUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error('Video error:', error);
      alert('Video yaratishda xatolik yuz berdi. Iltimos, Billing sozlamalarini tekshiring.');
    } finally {
      setIsGenerating(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="h-full flex flex-col items-center p-8 bg-[#020617] overflow-y-auto">
      <div className="max-w-3xl w-full text-center mb-12">
        <h2 className="text-4xl font-display font-bold text-white mb-4">Cinematic Video Studio</h2>
        <p className="text-slate-400">G'oyalaringizni professional darajadagi qisqa videolarga aylantiring.</p>
        <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-medium">
          <Sparkles size={12} /> Veo 3.1 Pro Model Powered
        </div>
      </div>

      <div className="w-full max-w-4xl space-y-8">
        <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-3xl shadow-2xl backdrop-blur-xl">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Kamera oldidan o'tib ketayotgan neon mushuk, kiberpunk shahri, 4k detallar..."
            className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl p-6 text-slate-100 focus:ring-2 focus:ring-blue-600 outline-none h-32 transition-all resize-none mb-6"
          />
          <button
            onClick={generateVideo}
            disabled={!prompt.trim() || isGenerating}
            className="w-full h-16 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white font-bold rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-blue-900/20"
          >
            {isGenerating ? <Loader2 className="animate-spin" /> : <Video />}
            {isGenerating ? 'Generatsiya kutilmoqda...' : 'Video Yaratish'}
          </button>
          
          <p className="text-[10px] text-slate-500 mt-4 text-center">
            * Video generatsiya qilish uchun pullik API kalit talab qilinadi.
          </p>
        </div>

        {isGenerating && (
          <div className="bg-blue-600/10 border border-blue-600/20 p-6 rounded-2xl text-center animate-pulse">
            <p className="text-blue-400 font-medium">{loadingStep}</p>
          </div>
        )}

        {videoUrl && (
          <div className="space-y-4 animate-in zoom-in duration-500">
            <div className="aspect-video rounded-3xl overflow-hidden border border-slate-800 shadow-2xl group relative">
              <video src={videoUrl} controls className="w-full h-full object-cover" />
              <div className="absolute top-4 right-4">
                <a 
                  href={videoUrl} 
                  download="hofiz-ai-video.mp4" 
                  className="bg-white/10 backdrop-blur-md text-white p-3 rounded-xl hover:bg-white/20 transition-all border border-white/10"
                >
                  <Download size={20} />
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoGen;
