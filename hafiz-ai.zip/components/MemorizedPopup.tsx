
import React, { useEffect, useState } from 'react';
import { t } from '../translations';
import { Language } from '../types';

interface Props {
  onClose: () => void;
  language?: Language;
}

const MemorizedPopup: React.FC<Props> = ({ onClose, language = Language.UZ }) => {
  const [show, setShow] = useState(false);
  const text = t[language];

  useEffect(() => {
    setShow(true);
    // Auto close after 4s
    const timer = setTimeout(() => {
        setShow(false);
        setTimeout(onClose, 300); // Wait for exit animation
    }, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 transition-all duration-500 ${show ? 'bg-black/60 backdrop-blur-sm' : 'bg-transparent pointer-events-none'}`}>
       <div className={`bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl transform transition-all duration-500 flex flex-col items-center relative overflow-hidden ${show ? 'scale-100 opacity-100 translate-y-0' : 'scale-50 opacity-0 translate-y-20'}`}>
         
         {/* Confetti / Burst Background Effect */}
         <div className="absolute inset-0 z-0">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-emerald-100 rounded-full blur-3xl opacity-60 animate-pulse"></div>
         </div>

         <div className="relative z-10 mb-6 flex items-center justify-center">
             <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center animate-[bounce_2s_infinite]">
                <svg className="w-10 h-10 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
             </div>
             <div className="absolute inset-0 rounded-full border-2 border-emerald-200 animate-[ping_2s_infinite_0.5s]"></div>
         </div>

         <h2 className="relative z-10 text-2xl font-black text-slate-800 mb-2 text-center">{text.mastered}!</h2>
         <p className="relative z-10 text-slate-500 font-medium text-center mb-6">MashaAllah! {text.mastered}!</p>

         <button 
           onClick={onClose}
           className="relative z-10 bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-10 rounded-full shadow-lg shadow-emerald-200 active:scale-95 transition-all"
         >
           OK
         </button>
       </div>
    </div>
  );
};

export default MemorizedPopup;
