
import React, { useEffect, useState } from 'react';

interface Props {
  accuracy: number | null;
}

const TajweedProgress: React.FC<Props> = ({ accuracy }) => {
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (accuracy !== null) {
      // Small delay to trigger animation
      const timer = setTimeout(() => setWidth(accuracy), 100);
      return () => clearTimeout(timer);
    } else {
      setWidth(0);
    }
  }, [accuracy]);

  if (accuracy === null) return null;

  let colorClass = 'bg-red-500';
  let textColorClass = 'text-red-600';
  
  if (accuracy >= 75) {
    colorClass = 'bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.4)]';
    textColorClass = 'text-green-600';
  } else if (accuracy >= 40) {
    colorClass = 'bg-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.4)]';
    textColorClass = 'text-yellow-600';
  }

  return (
    <div className="w-full max-w-lg mx-auto mt-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-end mb-2 px-1">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tajwid Progress</span>
        <span className={`text-xl font-black ${textColorClass} transition-colors duration-500`}>
          {accuracy}%
        </span>
      </div>
      
      <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200 shadow-inner">
        <div 
          className={`h-full ${colorClass} transition-all duration-1000 ease-out rounded-full relative`}
          style={{ width: `${width}%` }}
        >
          <div className="absolute inset-0 bg-white/20 w-full h-full animate-[shimmer_2s_infinite]"></div>
        </div>
      </div>
    </div>
  );
};

export default TajweedProgress;
