
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCw, FastForward, Rewind, User, Settings } from 'lucide-react';
import { Ayah, Edition } from '../types';
import { fetchAyahAudio, getEditions } from '../services/quranApi';

interface LearningModeProps {
  surahNumber: number;
  ayahs: Ayah[];
}

const LearningMode: React.FC<LearningModeProps> = ({ surahNumber, ayahs }) => {
  const [currentAyahIdx, setCurrentAyahIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [selectedEdition, setSelectedEdition] = useState('ar.alafasy');
  const [editions, setEditions] = useState<Edition[]>([]);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    getEditions().then(setEditions);
  }, []);

  useEffect(() => {
    const loadAudio = async () => {
      const ayah = ayahs[currentAyahIdx];
      const data = await fetchAyahAudio(ayah.number, selectedEdition);
      setAudioUrl(data.audio);
    };
    if (ayahs.length > 0) loadAudio();
  }, [currentAyahIdx, selectedEdition, ayahs]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) audioRef.current.pause();
    else audioRef.current.play();
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    if (currentAyahIdx < ayahs.length - 1) setCurrentAyahIdx(prev => prev + 1);
  };

  const handlePrev = () => {
    if (currentAyahIdx > 0) setCurrentAyahIdx(prev => prev - 1);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      <div className="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-emerald-100 flex flex-col min-h-[500px]">
        {/* Header */}
        <div className="p-6 bg-emerald-600 text-white flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold">O'rganish Bo'limi</h2>
            <p className="text-emerald-100 text-sm">Oyat {ayahs[currentAyahIdx]?.numberInSurah} / {ayahs.length}</p>
          </div>
          <select 
            className="bg-emerald-700/50 text-white border-none rounded-xl px-3 py-2 text-sm focus:ring-0"
            value={selectedEdition}
            onChange={(e) => setSelectedEdition(e.target.value)}
          >
            {editions.map(ed => (
              <option key={ed.identifier} value={ed.identifier}>{ed.name}</option>
            ))}
          </select>
        </div>

        {/* Ayah Text */}
        <div className="flex-grow flex items-center justify-center p-8 bg-slate-50/50">
          <div className="text-center">
            <p className="arabic-font text-5xl md:text-7xl leading-[1.6] text-slate-800 mb-8 dir-rtl">
              {ayahs[currentAyahIdx]?.text}
            </p>
            <p className="text-slate-500 text-lg italic max-w-2xl mx-auto">
              (Tajvidli format va Ma'nosi shu yerda bo'ladi)
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="p-8 bg-white border-t border-slate-100">
          <div className="flex flex-col items-center gap-6">
            <div className="flex items-center gap-8">
              <button onClick={handlePrev} className="text-emerald-600 hover:scale-110 transition-transform"><Rewind className="w-8 h-8 fill-current" /></button>
              <button 
                onClick={togglePlay}
                className="w-20 h-20 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-xl hover:bg-emerald-700 active:scale-95 transition-all"
              >
                {isPlaying ? <Pause className="w-10 h-10 fill-current" /> : <Play className="w-10 h-10 fill-current ml-1" />}
              </button>
              <button onClick={handleNext} className="text-emerald-600 hover:scale-110 transition-transform"><FastForward className="w-8 h-8 fill-current" /></button>
            </div>

            <div className="flex items-center gap-4 w-full justify-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tezlik</span>
              <div className="flex bg-slate-100 p-1 rounded-2xl">
                {[1, 1.25, 1.5, 2, 2.5, 3, 4].map(speed => (
                  <button
                    key={speed}
                    onClick={() => setPlaybackSpeed(speed)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${playbackSpeed === speed ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-emerald-500'}`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
              <button 
                onClick={() => { if(audioRef.current) audioRef.current.currentTime = 0 }}
                className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-full transition-colors"
              >
                <RotateCw className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        <audio 
          ref={audioRef} 
          src={audioUrl} 
          onEnded={() => setIsPlaying(false)}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        />
      </div>
    </div>
  );
};

export default LearningMode;
