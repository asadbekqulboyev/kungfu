
import React, { useState, useEffect } from 'react';
import { Surah } from '../types';
import { quranService } from '../services/api';
import { ListSkeleton } from './Skeleton';
import { Search, BookOpen, Star } from 'lucide-react';

const Dashboard: React.FC<{ onSelectSurah: (s: Surah) => void }> = ({ onSelectSurah }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    quranService.getSurahs().then(data => {
      setSurahs(data);
      setLoading(false);
    });
  }, []);

  const filtered = surahs.filter(s => 
    s.englishName.toLowerCase().includes(search.toLowerCase()) || 
    s.number.toString().includes(search)
  );

  return (
    <div className="space-y-8 p-2">
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-[2.5rem] p-10 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl font-black mb-2">Hifz Rejangiz</h2>
          <p className="text-emerald-100 opacity-80 mb-6">Baqara surasini yodlashga 80% qoldi</p>
          <div className="flex gap-4">
            <div className="bg-white/10 px-4 py-2 rounded-2xl flex items-center gap-2"><Star size={16} fill="white" /> 120 XP</div>
            <div className="bg-white/10 px-4 py-2 rounded-2xl flex items-center gap-2"><BookOpen size={16} /> 5 Sura</div>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          placeholder="Surani qidiring..." 
          className="w-full pl-12 pr-6 py-4 bg-white border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-200 shadow-sm"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? <ListSkeleton /> : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(surah => (
            <button 
              key={surah.number} 
              onClick={() => onSelectSurah(surah)}
              className="group bg-white p-6 rounded-3xl border border-slate-50 hover:border-emerald-200 hover:shadow-lg transition-all text-left flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-700 font-black group-hover:bg-emerald-600 group-hover:text-white transition-all">
                  {surah.number}
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">{surah.englishName}</h4>
                  <p className="text-xs text-slate-400 uppercase tracking-widest">{surah.numberOfAyahs} oyat</p>
                </div>
              </div>
              <div className="arabic-font text-2xl text-emerald-800 opacity-50">{surah.name}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
