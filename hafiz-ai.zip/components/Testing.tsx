
import React, { useState, useEffect, useRef } from 'react';
import { Surah, CombinedAyahData, AppMode, Language, HifzPlanJSON } from '../types';
import { fetchSurahData, calculateAyahTimeRange } from '../services/quranService';
import { hifzService } from '../services/api';
import { AyahSkeleton } from './Skeleton';
import { 
  ChevronRight, RotateCcw, ShieldCheck, 
  Play, Info, ChevronLeft, Sparkles, AlertCircle
} from 'lucide-react';
import AudioRecorder from './AudioRecorder';
import { sendMessageToHafiz, blobToBase64 } from '../services/geminiService';
import { parseTajweedAndWrap } from '../utils/tajweedParser';
import { getSurahNameUz } from '../utils/quranUtils';

interface TestError {
  word: string;
  rule: string;
  explanation: string;
  suggestion: string;
}

interface TestMessage {
  id: string;
  sender: 'ai' | 'user';
  type: 'text' | 'audio' | 'result';
  content: string;
  timestamp: string;
  accuracy?: number;
  tajweed_highlight?: string;
  audioUrl?: string;
  errors_list?: TestError[];
}

const Testing: React.FC<{ surah: Surah; initialAyahIdx?: number; onModeChange: (m: AppMode) => void }> = ({ surah, initialAyahIdx = 0, onModeChange }) => {
  const [ayahs, setAyahs] = useState<CombinedAyahData[]>([]);
  const [currentIdx, setCurrentIdx] = useState(initialAyahIdx);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<TestMessage[]>([]);
  const [isBonusMode, setIsBonusMode] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { loadTestingData(); }, [surah]);

  useEffect(() => {
    if (ayahs.length > 0 && initialAyahIdx !== currentIdx) {
      setCurrentIdx(initialAyahIdx);
      startNewTest(ayahs[initialAyahIdx], initialAyahIdx);
    }
  }, [initialAyahIdx, ayahs]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isProcessing]);

  const loadTestingData = async () => {
    setIsLoading(true);
    try {
      const data = await fetchSurahData(surah.number, Language.UZ);
      setAyahs(data || []);
      
      const savedPlan = localStorage.getItem('active_hifz_plan');
      if (savedPlan) {
        const plan = JSON.parse(savedPlan) as HifzPlanJSON;
        const currentTask = plan.schedule.find(t => t.date === new Date().toISOString().split('T')[0]);
        if (currentTask?.isCompleted) {
          setIsBonusMode(true);
        }
      }

      if (data && data.length > initialAyahIdx) {
        startNewTest(data[initialAyahIdx], initialAyahIdx);
      }
    } catch (err) { console.error(err); }
    setIsLoading(false);
  };

  const startNewTest = (ayah: CombinedAyahData, idx: number) => {
    const { min, max } = calculateAyahTimeRange(ayah.text);
    const bonusPrefix = isBonusMode ? "🌟 BONUS: " : "";
    const welcomeMsg: TestMessage = {
      id: 'welcome-' + Date.now(),
      sender: 'ai',
      type: 'text',
      content: `${bonusPrefix}${ayah.numberInSurah}-oyat. \n⏱ Vaqt: ${min}-${max} sek.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, welcomeMsg]);
  };

  const adjustPlanForBonus = (surahNum: number, ayahNum: number) => {
    const savedPlan = localStorage.getItem('active_hifz_plan');
    if (!savedPlan) return;
    const plan = JSON.parse(savedPlan) as HifzPlanJSON;
    
    // Kelgusi vazifani qidiramiz (bajarilmagan birinchi vazifa)
    const nextTaskIdx = plan.schedule.findIndex(t => !t.isCompleted);
    if (nextTaskIdx !== -1) {
      const task = plan.schedule[nextTaskIdx];
      // Agar yodlangan oyat ertangi vazifaga tegishli bo'lsa
      if (task.surahNumber === surahNum && ayahNum >= task.startAyah && ayahNum <= task.endAyah) {
        if (ayahNum === task.endAyah) {
          plan.schedule[nextTaskIdx].isCompleted = true;
        } else {
          plan.schedule[nextTaskIdx].startAyah = ayahNum + 1;
        }
        localStorage.setItem('active_hifz_plan', JSON.stringify(plan));
      }
    }
  };

  const handleRecitationTest = async (blob: Blob) => {
    const currentAyah = ayahs[currentIdx];
    const audioUrl = URL.createObjectURL(blob);

    setMessages(prev => [...prev, {
      id: 'user-audio-' + Date.now(),
      sender: 'user',
      type: 'audio',
      content: 'Tilovat yozildi',
      audioUrl,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }]);

    setIsProcessing(true);
    try {
      const base64Audio = await blobToBase64(blob);
      const context = {
        mode: 'strict_hifz_testing',
        surah: surah.englishName,
        ayah_number: currentAyah.numberInSurah,
        canonical_text: currentAyah.text,
      };

      const responseText = await sendMessageToHafiz(context, "Tilovatni tahlil qil", base64Audio, blob.type);
      const data = JSON.parse(responseText);
      
      setMessages(prev => [...prev, {
        id: 'result-' + Date.now(),
        sender: 'ai',
        type: 'result',
        content: data.overall_feedback,
        accuracy: data.accuracy,
        tajweed_highlight: data.tajweed_highlight,
        errors_list: data.errors,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      
      if (data.accuracy >= 95) {
        await hifzService.saveProgress(surah.number, currentAyah.numberInSurah, 'mastered');
        if (isBonusMode) adjustPlanForBonus(surah.number, currentAyah.numberInSurah);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const nextAyah = () => {
    if (currentIdx < ayahs.length - 1) {
      const nextIdx = currentIdx + 1;
      setCurrentIdx(nextIdx);
      startNewTest(ayahs[nextIdx], nextIdx);
    }
  };

  if (isLoading) return <AyahSkeleton />;
  const currentAyah = ayahs[currentIdx];

  return (
    <div className="flex flex-col h-full bg-[#F5F7F9] overflow-hidden">
      <header className={`h-14 shrink-0 border-b flex items-center justify-between px-4 md:px-6 z-20 ${isBonusMode ? 'bg-emerald-50 border-emerald-100' : 'bg-white border-slate-100'}`}>
        <div className="flex items-center gap-3">
           <button onClick={() => onModeChange(AppMode.TEACHING)} className="p-1.5 text-slate-400 hover:bg-slate-50 rounded-full lg:hidden"><ChevronLeft size={18} /></button>
           <div className="flex flex-col">
              <h3 className="text-[12px] font-black text-slate-800 leading-tight flex items-center gap-2">
                {isBonusMode && <Sparkles size={14} className="text-emerald-500 animate-pulse" />}
                {getSurahNameUz(surah.englishName)}: {currentAyah?.numberInSurah}-oyat
              </h3>
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{isBonusMode ? 'Bonus O'rganish' : 'Hifz Sinovi'}</span>
           </div>
        </div>
        <button onClick={() => setMessages([])} className="p-1.5 text-slate-300 hover:text-red-500"><RotateCcw size={16} /></button>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto bg-white/40 custom-scrollbar">
        <div className="max-w-3xl mx-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
              <div className={`max-w-[90%] md:max-w-[80%] rounded-2xl p-4 shadow-sm border ${msg.sender === 'user' ? 'bg-emerald-600 border-emerald-500 text-white rounded-tr-none' : 'bg-white border-slate-100 text-slate-700 rounded-tl-none'}`}>
                
                {msg.type === 'text' && <p className="text-[13px] font-medium leading-relaxed">{msg.content}</p>}

                {msg.type === 'audio' && (
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-black/10 flex items-center justify-center"><Play size={12} fill="currentColor" /></div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Tilovat</span>
                  </div>
                )}

                {msg.type === 'result' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-50 pb-2">
                       <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">AI Tahlil Natijasi</span>
                       <span className={`text-xl font-black ${msg.accuracy! >= 95 ? 'text-emerald-600' : 'text-amber-600'}`}>{msg.accuracy}%</span>
                    </div>
                    
                    <div className="arabic-font text-2xl md:text-4xl text-center leading-relaxed text-slate-800 bg-slate-50 p-4 rounded-xl" dir="rtl" dangerouslySetInnerHTML={{ __html: parseTajweedAndWrap(msg.tajweed_highlight || "") }} />
                    
                    <div className="p-3 bg-emerald-50/50 rounded-xl border border-emerald-100 italic text-[12px] font-bold text-slate-700">"{msg.content}"</div>

                    {msg.errors_list && msg.errors_list.length > 0 && (
                      <div className="space-y-2 mt-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Aniqlangan Xatolar:</p>
                        {msg.errors_list.map((err, i) => (
                          <div key={i} className="bg-red-50 p-3 rounded-xl border border-red-100 animate-in slide-in-from-left-2" style={{animationDelay: `${i*100}ms`}}>
                             <div className="flex items-center justify-between mb-1">
                                <span className="text-[10px] font-black text-red-600 uppercase bg-red-100 px-2 py-0.5 rounded-full">{err.rule}</span>
                                <span className="arabic-font text-lg font-bold">{err.word}</span>
                             </div>
                             <p className="text-[11px] text-slate-700 leading-relaxed font-medium mb-1">{err.explanation}</p>
                             <div className="flex items-start gap-1.5 text-[10px] text-emerald-700 font-bold bg-white/60 p-1.5 rounded-lg border border-emerald-50">
                                <Sparkles size={12} className="shrink-0 mt-0.5" />
                                <span>Maslahat: {err.suggestion}</span>
                             </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {msg.accuracy! >= 95 ? (
                      <button onClick={nextAyah} className="w-full py-3 bg-emerald-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-2">
                         Keyingi Oyat <ChevronRight size={14} />
                      </button>
                    ) : (
                      <div className="flex items-center gap-2 text-amber-600 bg-amber-50 p-3 rounded-xl border border-amber-100">
                        <AlertCircle size={16} />
                        <span className="text-[10px] font-black uppercase">Aniqlik past. Iltimos, xatolarni tuzatib qayta o'qing!</span>
                      </div>
                    )}
                  </div>
                )}
                <div className={`text-[8px] font-bold mt-2 text-right opacity-40 ${msg.sender === 'user' ? 'text-white' : 'text-slate-400'}`}>{msg.timestamp}</div>
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex justify-start">
               <div className="bg-white border border-slate-100 rounded-xl p-3 flex items-center gap-2 shadow-sm">
                  <div className="flex gap-1"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce"></div><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.2s]"></div><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-bounce [animation-delay:0.4s]"></div></div>
                  <span className="text-[9px] font-black text-emerald-600 uppercase">AI Ustoz tahlil qilmoqda...</span>
               </div>
            </div>
          )}
        </div>
      </div>

      <footer className="shrink-0 bg-white border-t border-slate-100 p-6 shadow-xl">
        <div className="max-w-xl mx-auto flex flex-col items-center gap-3">
           <AudioRecorder onRecordingComplete={handleRecitationTest} isProcessing={isProcessing} language={Language.UZ} />
           <p className="text-[9px] font-black uppercase text-slate-300 tracking-widest">Tilovatni boshlash uchun bosing</p>
        </div>
      </footer>
    </div>
  );
};

export default Testing;
