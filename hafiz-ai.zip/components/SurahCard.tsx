
import React from 'react';
import { Surah } from '../types';
import { BookOpen, ChevronRight } from 'lucide-react';

interface SurahCardProps {
  surah: Surah;
  onClick: (surah: Surah) => void;
}

const SurahCard: React.FC<SurahCardProps> = ({ surah, onClick }) => {
  return (
    <button
      onClick={() => onClick(surah)}
      className="group bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all text-left w-full"
    >
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-lg group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            {surah.number}
          </div>
          <div>
            <h3 className="font-bold text-slate-800 text-lg">{surah.englishName}</h3>
            <p className="text-slate-500 text-sm">{surah.englishNameTranslation} • {surah.numberOfAyahs} Verses</p>
          </div>
        </div>
        <div className="text-right flex items-center gap-4">
          <div className="arabic-font text-2xl text-emerald-800 font-bold">{surah.name}</div>
          <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-emerald-500 transition-colors" />
        </div>
      </div>
    </button>
  );
};

export default SurahCard;
