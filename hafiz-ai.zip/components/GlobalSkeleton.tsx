
import React from 'react';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';

const GlobalSkeleton: React.FC = () => {
  return (
    <SkeletonTheme baseColor="#f1f5f9" highlightColor="#ffffff">
      <div className="flex flex-col h-[100dvh] bg-slate-50 overflow-hidden">
        
        {/* Header Skeleton */}
        <div className="bg-white border-b border-slate-200 px-4 py-3 shrink-0 flex items-center justify-between">
          <div className="flex flex-col gap-1">
             <Skeleton width={120} height={24} />
             <Skeleton width={80} height={12} />
          </div>
          <div className="flex gap-2">
             <Skeleton width={40} height={24} borderRadius={20} />
             <Skeleton width={80} height={24} borderRadius={20} />
          </div>
        </div>
        
        <div className="flex-1 flex overflow-hidden">
          
          {/* Sidebar Skeleton */}
          <div className="hidden md:flex flex-col w-80 bg-white border-r border-slate-200 shrink-0">
             <div className="p-4 border-b border-slate-100">
               <Skeleton width={100} height={16} />
             </div>
             <div className="p-2 space-y-2 overflow-hidden">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                  <div key={i} className="flex items-center gap-3 p-3">
                     <Skeleton circle width={32} height={32} />
                     <div className="flex-1">
                        <Skeleton width={`70%`} height={16} />
                        <Skeleton width={`40%`} height={12} />
                     </div>
                  </div>
                ))}
             </div>
          </div>

          {/* Main Content Skeleton */}
          <main className="flex-1 flex flex-col relative bg-slate-50/30 p-4 md:p-8 items-center">
             
             {/* Ayah Header Skeleton */}
             <div className="w-full max-w-4xl flex justify-between mb-8">
                <Skeleton width={150} height={24} />
                <Skeleton width={200} height={30} borderRadius={8} />
             </div>

             {/* Ayah Text Area */}
             <div className="w-full max-w-2xl flex flex-col items-center gap-6 mt-10">
                <Skeleton width="100%" height={80} />
                <Skeleton width="80%" height={80} />
                
                <div className="w-full mt-8">
                  <Skeleton count={3} />
                </div>
             </div>

             {/* Bottom Controls */}
             <div className="absolute bottom-0 left-0 w-full p-6 bg-white border-t border-slate-200">
                <div className="max-w-4xl mx-auto flex justify-between items-center">
                   <Skeleton circle width={48} height={48} />
                   <Skeleton width={150} height={56} borderRadius={28} />
                   <Skeleton circle width={48} height={48} />
                </div>
             </div>
          </main>
        </div>
      </div>
    </SkeletonTheme>
  );
};

export default GlobalSkeleton;
