
import React, { useEffect, useState } from 'react';

interface Props {
  onComplete: () => void;
}

const IntroVideo: React.FC<Props> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 2500; 
    const intervalTime = 20;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const p = Math.min(100, (elapsed / duration) * 100);
      setProgress(p);

      if (elapsed >= duration) {
        clearInterval(interval);
        onComplete();
      }
    }, intervalTime);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[1000] bg-white flex flex-col items-center justify-center overflow-hidden">
      {/* Soft background aesthetics */}
      <div className="absolute top-[-10%] left-[-5%] w-[50%] h-[50%] bg-emerald-50 rounded-full blur-[100px] opacity-40"></div>
      <div className="absolute bottom-[-10%] right-[-5%] w-[50%] h-[50%] bg-teal-50 rounded-full blur-[100px] opacity-40"></div>

      <div className="relative z-10 flex flex-col items-center">
        {/* Animated Minimalist Logo */}
        <div className="w-20 h-20 md:w-28 md:h-28 mb-6 relative flex items-center justify-center">
           <div className="absolute inset-0 border-2 border-emerald-100 rounded-3xl rotate-45 animate-[spin_10s_linear_infinite]"></div>
           <div className="w-14 h-14 md:w-20 md:h-20 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-emerald-100">
              <span className="text-3xl md:text-5xl font-serif font-black text-white select-none">H</span>
           </div>
        </div>

        <div className="text-center">
            <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-[0.2em] uppercase mb-1">
              Hafiz AI
            </h1>
            <div className="h-0.5 w-8 bg-emerald-500 mx-auto rounded-full"></div>
        </div>
      </div>

      {/* Progress Bar Container */}
      <div className="absolute bottom-20 left-0 right-0 px-16 flex flex-col items-center max-w-[280px] mx-auto">
        <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-emerald-500 transition-all duration-75 ease-linear"
              style={{ width: `${progress}%` }}
            />
        </div>
        <span className="mt-4 text-[8px] font-black text-slate-300 uppercase tracking-[0.4em] animate-pulse">
          Yuklanmoqda...
        </span>
      </div>
    </div>
  );
};

export default IntroVideo;
