
import React, { useState, useEffect, useRef } from 'react';
import { CombinedAyahData, Language, CharacterState, LessonStep, AppMode } from '../../types';
import { t } from '../../translations';
import { sendMessageToHafiz, blobToBase64 } from '../../services/geminiService';
import { fetchWordTimings } from '../../services/quranService';
import AudioRecorder from '../AudioRecorder';
import ThreeCharacter from './ThreeCharacter';
import RewardPopup from './RewardPopup';
import { parseTajweedAndWrap } from '../../utils/tajweedParser';

interface Props {
  ayah: CombinedAyahData;
  surahNumber: number;
  language: Language;
  onNext: () => void;
  onBack: () => void;
}

const KidsLesson: React.FC<Props> = ({ ayah, surahNumber, language, onNext, onBack }) => {
  const [step, setStep] = useState<LessonStep>(LessonStep.INTRO);
  const [characterState, setCharacterState] = useState<CharacterState>(CharacterState.IDLE);
  const [wordTimings, setWordTimings] = useState<any[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [reward, setReward] = useState<{stars: number, msg: string} | null>(null);
  const [feedbackText, setFeedbackText] = useState("");

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const text = t[language];

  // --- Voice Synthesis (Ustoz Noor) ---
  const speak = (message: string, onEnd?: () => void) => {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = language === Language.UZ ? 'uz-UZ' : 'en-US';
    utterance.pitch = 1.1; // Slightly higher pitch for friendly tone
    utterance.rate = 0.9;  // Slightly slower

    // Character Animation Sync
    utterance.onstart = () => setCharacterState(CharacterState.TALKING);
    utterance.onend = () => {
      setCharacterState(CharacterState.IDLE);
      if (onEnd) onEnd();
    };

    window.speechSynthesis.speak(utterance);
  };

  // --- Audio Player for Quran ---
  const playQuran = () => {
    if (!audioRef.current) {
        audioRef.current = new Audio(ayah.audioUrl);
        audioRef.current.onended = () => {
            setIsPlaying(false);
            // Move to next step if we were in teacher_reads phase
            if (step === LessonStep.TEACHER_READS) {
                setStep(LessonStep.STUDENT_TURN);
            }
        };
        // Load timings
        fetchWordTimings(ayah.text, 5).then(timings => setWordTimings(timings)); // Approx duration
    }
    
    // Recalculate timings on metadata load for better accuracy
    audioRef.current.onloadedmetadata = async () => {
        const timings = await fetchWordTimings(ayah.text, audioRef.current?.duration || 0);
        setWordTimings(timings);
    };

    setIsPlaying(true);
    audioRef.current.play();
  };

  // --- Sync Highlight Loop ---
  useEffect(() => {
    let frameId: number;
    const loop = () => {
      if (isPlaying && audioRef.current && wordTimings.length > 0) {
        const time = audioRef.current.currentTime;
        const active = wordTimings.find(t => time >= t.start && time <= t.end);
        
        document.querySelectorAll('.word.active').forEach(el => el.classList.remove('active'));
        if (active) {
            const el = document.getElementById(`word-${active.id}`);
            if (el) el.classList.add('active');
        }
      }
      frameId = requestAnimationFrame(loop);
    };
    if (isPlaying) loop();
    return () => cancelAnimationFrame(frameId);
  }, [isPlaying, wordTimings]);


  // --- Lesson Flow Controller ---
  useEffect(() => {
    if (step === LessonStep.INTRO) {
        const introMsg = text.ustozGreeting.replace('{surah}', surahNumber.toString());
        // Small delay to let component mount
        setTimeout(() => {
            speak(introMsg, () => setStep(LessonStep.TEACHER_READS));
        }, 1000);
    }

    if (step === LessonStep.TEACHER_READS) {
        // Wait a beat, then say "Listen to me"
        setTimeout(() => {
             speak(text.ustozListen, () => {
                 playQuran();
             });
        }, 500);
    }

    if (step === LessonStep.STUDENT_TURN) {
        speak(text.ustozYourTurn);
        // Now waiting for user to press record
    }
  }, [step]);


  // --- Handle Recording Evaluation ---
  const handleRecording = async (blob: Blob) => {
    setStep(LessonStep.FEEDBACK);
    setFeedbackText(text.analyzing);
    
    try {
        const base64 = await blobToBase64(blob);
        const context = {
            mode: AppMode.KIDS, // Special mode for simplified feedback
            language,
            surah: surahNumber,
            ayah: ayah.numberInSurah,
            ayah_text: ayah.text,
            translation: "",
            canonical_audio_url: ""
        };
        
        // Send to AI
        const rawResponse = await sendMessageToHafiz(context, "Rate this recitation for a kid (0-3 stars) and give 1 simple sentence feedback.", base64, blob.type);
        
        // Parse "fake" JSON from text if possible, or just parse stars from text
        // For this demo, let's assume valid JSON or simple heuristic
        let stars = 2;
        let aiMsg = text.goodTry;
        
        if (rawResponse.toLowerCase().includes("perfect") || rawResponse.includes("3 stars")) stars = 3;
        else if (rawResponse.toLowerCase().includes("good") || rawResponse.includes("2 stars")) stars = 2;
        else stars = 1;

        if (stars === 3) aiMsg = text.ustozCorrect;
        else if (stars === 2) aiMsg = text.ustozAlmost;
        else aiMsg = text.ustozRetry;

        setFeedbackText(aiMsg);
        
        // Ustoz Speaks Feedback
        speak(aiMsg, () => {
            if (stars >= 2) {
                setCharacterState(CharacterState.CELEBRATING);
                setReward({ stars, msg: stars === 3 ? text.perfect : text.goodTry });
                setStep(LessonStep.CELEBRATE);
            } else {
                setStep(LessonStep.STUDENT_TURN); // Retry
            }
        });

    } catch (e) {
        console.error(e);
        speak(text.networkError);
        setStep(LessonStep.STUDENT_TURN);
    }
  };

  const closeReward = () => {
    setReward(null);
    onNext(); // Auto go to next ayah
  };

  return (
    <div className="flex flex-col h-full bg-cyan-50 kids-theme relative overflow-hidden">
      
      {/* 3D Scene Background Layer (Top Half) */}
      <div className="absolute top-0 left-0 w-full h-[45%] z-0 bg-gradient-to-b from-sky-200 to-cyan-50 rounded-b-[3rem] shadow-inner overflow-hidden">
         {/* Decorative Clouds */}
         <div className="absolute top-10 left-10 w-20 h-20 bg-white rounded-full opacity-60 blur-xl animate-pulse"></div>
         <div className="absolute top-20 right-10 w-32 h-32 bg-white rounded-full opacity-60 blur-xl animate-pulse delay-700"></div>
         
         <ThreeCharacter state={characterState} />
      </div>

      {/* Foreground Content */}
      <div className="relative z-10 flex flex-col h-full">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4">
            <button onClick={onBack} className="bg-white/80 p-2 rounded-full shadow-sm hover:scale-110 transition">
                <svg className="w-6 h-6 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            </button>
            <div className="bg-white/80 px-4 py-1 rounded-full shadow-sm text-sm font-bold text-sky-600">
                Surah {surahNumber} : Ayah {ayah.numberInSurah}
            </div>
            <div className="w-10"></div> {/* Spacer */}
        </div>

        {/* Spacer for 3D area */}
        <div className="h-[30vh]"></div>

        {/* Lesson Card */}
        <div className="flex-1 bg-white rounded-t-[2.5rem] shadow-[0_-10px_40px_rgba(0,0,0,0.05)] p-6 flex flex-col items-center animate-in slide-in-from-bottom duration-700 relative">
           
           {/* Feedback Bubble */}
           {(step === LessonStep.STUDENT_TURN || step === LessonStep.FEEDBACK) && (
              <div className="absolute -top-12 bg-white px-6 py-3 rounded-2xl shadow-lg border-2 border-sky-100 animate-bounce-slow">
                 <p className="text-sky-600 font-bold text-lg">{feedbackText || text.ustozYourTurn}</p>
                 <div className="absolute bottom-[-8px] left-1/2 -translate-x-1/2 w-4 h-4 bg-white border-b-2 border-r-2 border-sky-100 rotate-45"></div>
              </div>
           )}

           <div className="flex-1 w-full flex items-center justify-center">
             <div 
               dir="rtl" 
               className="text-4xl md:text-6xl text-center leading-[2.5] text-slate-700 font-amiri"
               dangerouslySetInnerHTML={{ __html: parseTajweedAndWrap(ayah.tajweed) }}
             />
           </div>

           {/* Controls Area */}
           <div className="w-full pb-6">
              {step === LessonStep.TEACHER_READS && (
                 <div className="text-center text-slate-400 font-bold animate-pulse">
                    Ustoz Noor is reading...
                 </div>
              )}

              {step === LessonStep.STUDENT_TURN && (
                 <div className="flex justify-center">
                    <AudioRecorder 
                        onRecordingComplete={handleRecording} 
                        isProcessing={false} 
                        language={language}
                        // Custom Kids Style Prop could be added to AudioRecorder or handled via CSS
                    />
                    
                 </div>
              )}
              
              {/* Manual Overrides */}
              <div className="flex justify-center gap-4 mt-6 opacity-60 hover:opacity-100 transition-opacity">
                 <button onClick={playQuran} className="p-3 bg-slate-100 rounded-full hover:bg-sky-100 text-slate-400 hover:text-sky-500">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
                 </button>
                 <button onClick={onNext} className="p-3 bg-slate-100 rounded-full hover:bg-sky-100 text-slate-400 hover:text-sky-500">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
                 </button>
              </div>
           </div>
        </div>

      </div>

      {reward && (
        <RewardPopup 
            stars={reward.stars} 
            message={reward.msg} 
            onClose={closeReward} 
        />
      )}
    </div>
  );
};

export default KidsLesson;