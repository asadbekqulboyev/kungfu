// @ts-nocheck
import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Sphere, Cylinder, Torus, Float, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { CharacterState } from '../../types';

interface Props {
  state: CharacterState;
}

const CharacterModel: React.FC<{ state: CharacterState }> = ({ state }) => {
  const groupRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Mesh>(null);
  const mouthRef = useRef<THREE.Mesh>(null);

  // Animation Loop
  useFrame((stateCtx, delta) => {
    if (!groupRef.current || !headRef.current || !mouthRef.current) return;

    const time = stateCtx.clock.getElapsedTime();

    // IDLE: Gentle breathing/floating handled by <Float> mostly, but add subtle scale
    if (state === CharacterState.IDLE) {
      groupRef.current.scale.y = 1 + Math.sin(time * 2) * 0.02;
      mouthRef.current.scale.y = 0.5 + Math.sin(time * 3) * 0.1;
      groupRef.current.position.y = 0;
    }

    // TALKING: Mouth opens/closes fast, head bobs
    if (state === CharacterState.TALKING) {
      mouthRef.current.scale.y = 0.5 + Math.abs(Math.sin(time * 15)) * 0.5;
      headRef.current.rotation.x = Math.sin(time * 10) * 0.05;
      groupRef.current.position.y = 0;
    }

    // CELEBRATING: Jump and spin
    if (state === CharacterState.CELEBRATING) {
      groupRef.current.position.y = Math.abs(Math.sin(time * 10)) * 0.5;
      groupRef.current.rotation.y += delta * 5;
      mouthRef.current.scale.y = 1; // Big smile
      mouthRef.current.scale.x = 1.2;
    } else {
      // Reset rotation
      groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, 0, delta * 5);
    }
  });

  return (
    <group ref={groupRef} position={[0, -0.5, 0]}>
      {/* Body */}
      <Cylinder args={[0.6, 0.4, 1.2, 32]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#3b82f6" metalness={0.1} roughness={0.5} />
      </Cylinder>
      
      {/* Collar/Robe Detail */}
      <Torus args={[0.55, 0.05, 16, 100]} position={[0, 0.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <meshStandardMaterial color="#fbbf24" />
      </Torus>

      {/* Head Group */}
      <group position={[0, 0.9, 0]} ref={headRef}>
        {/* Head Shape */}
        <Sphere args={[0.55, 32, 32]}>
          <meshStandardMaterial color="#fcd34d" metalness={0.1} roughness={0.4} />
        </Sphere>

        {/* Hat (Turban/Kufi style) */}
        <Sphere args={[0.56, 32, 32, 0, Math.PI * 2, 0, Math.PI / 2]} position={[0, 0.1, 0]}>
           <meshStandardMaterial color="#ffffff" side={THREE.DoubleSide} />
        </Sphere>
        <Torus args={[0.55, 0.08, 16, 100]} position={[0, 0.1, 0]} rotation={[Math.PI / 2, 0, 0]}>
           <meshStandardMaterial color="#ffffff" />
        </Torus>

        {/* Eyes */}
        <Sphere args={[0.08]} position={[-0.2, 0.1, 0.45]}>
          <meshStandardMaterial color="black" />
        </Sphere>
        <Sphere args={[0.08]} position={[0.2, 0.1, 0.45]}>
          <meshStandardMaterial color="black" />
        </Sphere>
        
        {/* Eye Shine */}
        <Sphere args={[0.03]} position={[-0.18, 0.15, 0.52]}>
          <meshStandardMaterial color="white" />
        </Sphere>
        <Sphere args={[0.03]} position={[0.22, 0.15, 0.52]}>
          <meshStandardMaterial color="white" />
        </Sphere>

        {/* Mouth */}
        <mesh ref={mouthRef} position={[0, -0.2, 0.48]} rotation={[0, 0, 0]}>
           <capsuleGeometry args={[0.05, 0.15, 4, 8]} />
           <meshStandardMaterial color="#ef4444" />
        </mesh>

        {/* Beard (Cute rounded) */}
        <Sphere args={[0.3, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2]} position={[0, -0.4, 0.2]} rotation={[Math.PI, 0, 0]}>
            <meshStandardMaterial color="#475569" />
        </Sphere>
      </group>
      
      {/* Arms (Simple blobs) */}
      <Sphere args={[0.2]} position={[-0.7, 0.2, 0]}>
         <meshStandardMaterial color="#3b82f6" />
      </Sphere>
      <Sphere args={[0.2]} position={[0.7, 0.2, 0]}>
         <meshStandardMaterial color="#3b82f6" />
      </Sphere>

    </group>
  );
};

const ThreeCharacter: React.FC<Props> = ({ state }) => {
  return (
    <div className="w-full h-full">
      <Canvas camera={{ position: [0, 1, 4], fov: 45 }}>
        <ambientLight intensity={1.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} />
        <pointLight position={[-10, -10, -10]} intensity={1} />
        
        <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
          <CharacterModel state={state} />
        </Float>
        
        <ContactShadows opacity={0.4} scale={10} blur={2.5} far={4} color="#0d9488" />
        <Environment preset="city" />
      </Canvas>
    </div>
  );
};

export default ThreeCharacter;