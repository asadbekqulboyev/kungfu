
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { decode, decodeAudioData, createBlob } from '../utils/audioUtils';
import { LiveTranscription } from '../types';
import { Mic, MicOff, Sparkles, MessageSquare, Activity } from 'lucide-react';

const LiveAssistant: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcriptions, setTranscriptions] = useState<LiveTranscription[]>([]);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'listening' | 'speaking'>('idle');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const analyzerRef = useRef<AnalyserNode | null>(null);
  const requestRef = useRef<number | null>(null);

  const startSession = async () => {
    try {
      setStatus('connecting');
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      outputAudioContextRef.current = outputCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const analyzer = inputCtx.createAnalyser();
      analyzer.fftSize = 256;
      analyzerRef.current = analyzer;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
          },
          systemInstruction: 'Siz "Hafiz Pro" ovozli ustozi va do\'stisiz. Talabani Qur\'on yodlashda, tajvidda muloyimlik bilan qo\'llab quvvatlang. Javoblaringiz qisqa va tabiiy bo\'lsin.',
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            const source = inputCtx.createMediaStreamSource(stream);
            source.connect(analyzer);
            
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
            setStatus('listening');
            setIsActive(true);
            animate();
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              setStatus('speaking');
              const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
              
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setStatus('listening');
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setStatus('listening');
            }

            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setTranscriptions(prev => [...prev.slice(-4), { text, role: 'user' }]);
            }
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setTranscriptions(prev => [...prev.slice(-4), { text, role: 'model' }]);
            }
          },
          onerror: (e) => stopSession(),
          onclose: () => stopSession()
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (error) {
      console.error('Failed to start:', error);
      setStatus('idle');
    }
  };

  const stopSession = () => {
    sessionRef.current?.close();
    streamRef.current?.getTracks().forEach(track => track.stop());
    outputAudioContextRef.current?.close();
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    setIsActive(false);
    setStatus('idle');
    setTranscriptions([]);
  };

  const animate = () => {
    if (!canvasRef.current || !analyzerRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    const bufferLength = analyzerRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      requestRef.current = requestAnimationFrame(draw);
      analyzerRef.current!.getByteFrequencyData(dataArray);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = 60;

      // Glow
      const grad = ctx.createRadialGradient(centerX, centerY, radius, centerX, centerY, radius + 100);
      grad.addColorStop(0, status === 'speaking' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(59, 130, 246, 0.1)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(centerX, centerY, radius + 100, 0, Math.PI * 2); ctx.fill();

      // Bars
      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * 80;
        const angle = (i * 2 * Math.PI) / bufferLength;
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle) * (radius + barHeight);
        const y2 = centerY + Math.sin(angle) * (radius + barHeight);
        ctx.strokeStyle = status === 'speaking' ? '#10b981' : '#3b82f6';
        ctx.lineWidth = 2; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      }
      
      ctx.fillStyle = '#0f172a'; ctx.beginPath(); ctx.arc(centerX, centerY, radius - 5, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = status === 'speaking' ? '#10b981' : '#3b82f6'; ctx.lineWidth = 4; ctx.stroke();
    };
    draw();
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-6 bg-[#F8FAFC]">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-black text-slate-800 mb-2">Live Ustoz</h2>
        <p className="text-slate-400 text-sm font-medium uppercase tracking-widest">Real vaqtda muloqot va qiroat tahlili</p>
      </div>

      <div className="relative w-80 h-80 flex items-center justify-center mb-10">
        <canvas ref={canvasRef} width={400} height={400} className="w-full h-full" />
        {!isActive ? (
          <button onClick={startSession} className="absolute z-10 bg-emerald-600 hover:bg-emerald-500 text-white w-24 h-24 rounded-[2.5rem] shadow-2xl transition-all transform hover:scale-105 flex items-center justify-center group shadow-emerald-200">
             {status === 'connecting' ? <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div> : <Mic size={32} />}
          </button>
        ) : (
          <div className="absolute z-10 text-center animate-in zoom-in duration-300">
            <div className={`text-[10px] font-black uppercase tracking-[0.3em] ${status === 'speaking' ? 'text-emerald-500' : 'text-blue-500'} animate-pulse`}>
              {status === 'speaking' ? 'Ustoz gapirmoqda' : 'Sizni eshityapman'}
            </div>
          </div>
        )}
      </div>

      <div className="w-full max-w-xl bg-white rounded-[2rem] p-6 shadow-xl border border-slate-100 min-h-[180px] mb-8 relative overflow-hidden">
        <div className="absolute top-4 right-4 opacity-10"><MessageSquare size={40} /></div>
        <div className="space-y-4">
          {transcriptions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-24 text-slate-300 gap-2">
               <Activity size={24} />
               <p className="text-[10px] font-black uppercase tracking-widest">Muloqot kutilmoqda...</p>
            </div>
          ) : (
            transcriptions.map((t, i) => (
              <div key={i} className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                <div className={`px-4 py-2.5 rounded-2xl text-xs font-bold ${t.role === 'user' ? 'bg-blue-50 text-blue-700' : 'bg-emerald-50 text-emerald-700'}`}>
                  {t.text}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {isActive && (
        <button onClick={stopSession} className="px-10 py-4 bg-slate-900 hover:bg-red-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all shadow-xl active:scale-95 flex items-center gap-2">
          <MicOff size={16} /> Yakunlash
        </button>
      )}
    </div>
  );
};

export default LiveAssistant;
