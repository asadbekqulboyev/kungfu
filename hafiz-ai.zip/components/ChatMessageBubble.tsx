
import React from 'react';
import { ChatMessage, ModelResponseJSON, FeedbackJSON, HifzPlanJSON, Language } from '../types';
import { t } from '../translations';

interface Props {
  message: ChatMessage;
  language: Language;
}

const ChatMessageBubble: React.FC<Props> = ({ message, language }) => {
  const isModel = message.role === 'model';
  const text = t[language];
  
  // Helper to extract JSON if it exists in code blocks
  const extractJson = (content: string): ModelResponseJSON | null => {
    const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/);
    if (jsonMatch && jsonMatch[1]) {
      try {
        return JSON.parse(jsonMatch[1]);
      } catch (e) {
        return null;
      }
    }
    return null;
  };

  const jsonData = isModel ? extractJson(message.content) : null;
  
  // Type guards
  const isFeedback = (data: any): data is FeedbackJSON => {
    return data && (data.type === 'analysis' || typeof data.accuracy === 'number');
  };

  const isHifzPlan = (data: any): data is HifzPlanJSON => {
    return data && data.type === 'hifz_plan';
  };

  // Helper for Severity Color
  const getSeverityColor = (severity?: string) => {
    switch(severity) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'low': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className={`flex w-full mb-6 ${isModel ? 'justify-start' : 'justify-end'}`}>
      <div className={`max-w-[95%] md:max-w-[85%] rounded-3xl px-5 py-5 shadow-sm ${
        isModel 
          ? 'bg-white border border-slate-100 text-slate-800 rounded-tl-none' 
          : 'bg-emerald-600 text-white rounded-br-none shadow-md'
      }`}>
        <div className={`text-[10px] font-bold uppercase tracking-widest mb-2 opacity-60 ${isModel ? 'text-slate-500' : 'text-emerald-100'}`}>
          {isModel ? text.hafizAi : text.you}
        </div>

        {jsonData ? (
          <div className="space-y-4">
            {/* --- ANALYSIS FEEDBACK RENDERER --- */}
            {isFeedback(jsonData) && (
              <>
                <div className="flex items-center justify-between border-b pb-3 border-slate-100">
                  <span className="font-bold text-slate-600 text-sm">{text.accuracy}</span>
                  <div className="flex items-center gap-2">
                    <div className={`h-2.5 w-2.5 rounded-full ${jsonData.accuracy >= 90 ? 'bg-green-500' : jsonData.accuracy >= 70 ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
                    <span className={`font-black text-2xl ${jsonData.accuracy >= 90 ? 'text-green-600' : jsonData.accuracy >= 70 ? 'text-yellow-600' : 'text-red-500'}`}>
                      {jsonData.accuracy}%
                    </span>
                  </div>
                </div>
                
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <p className="text-slate-700 text-sm leading-relaxed">{String(jsonData.overall_feedback || '')}</p>
                </div>
                
                {jsonData.transcription && (
                   <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">ASR Transcription (Heard):</div>
                      <p className="font-amiri text-lg text-slate-700 text-right leading-loose" dir="rtl">{String(jsonData.transcription)}</p>
                   </div>
                )}
                
                {jsonData.recognized_surah && (
                   <div className="bg-red-50 p-3 rounded-xl border border-red-100 flex items-center gap-2 text-red-700 text-sm font-bold">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                      Looks like you recited: {String(jsonData.recognized_surah)}
                   </div>
                )}

                {jsonData.errors && jsonData.errors.length > 0 && (
                  <div className="mt-3">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-3">{text.corrections}:</h4>
                    <div className="space-y-3">
                      {jsonData.errors.map((err, i) => (
                        <div key={i} className="flex flex-col bg-white rounded-lg p-3 border border-slate-100 shadow-sm relative overflow-hidden">
                          <div className={`absolute top-0 left-0 w-1 h-full ${err.severity === 'high' ? 'bg-red-500' : 'bg-orange-400'}`}></div>
                          
                          <div className="flex justify-between items-start mb-2 pl-2">
                             <div className="flex flex-col">
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase w-fit ${getSeverityColor(err.severity)}`}>
                                   {String(err.issue || '')}
                                </span>
                             </div>
                             <span className="font-bold text-slate-800 text-2xl font-amiri leading-none">{String(err.word || '')}</span>
                          </div>
                          
                          <div className="pl-2 mt-1 flex items-start gap-2 text-sm text-slate-600 bg-slate-50 p-2 rounded-lg">
                             <svg className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                             <span>{String(err.suggestion || '')}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* --- HIFZ PLAN RENDERER --- */}
            {isHifzPlan(jsonData) && (
              <div className="bg-gradient-to-br from-emerald-50 to-white rounded-2xl p-5 border border-emerald-100 shadow-sm">
                <div className="flex items-center gap-2 mb-4 border-b border-emerald-100 pb-3">
                   <div className="p-2 bg-emerald-100 rounded-full">
                     <svg className="w-5 h-5 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
                   </div>
                   <h3 className="font-bold text-emerald-900">{text.hifzPlan}</h3>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">{text.dailyGoal}</div>
                    <div className="font-bold text-emerald-600 text-xl">{String(jsonData.daily_goal)}</div>
                  </div>
                  <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">{text.totalLoad}</div>
                    <div className="font-bold text-slate-700 text-xl">{String(jsonData.total_ayahs)}</div>
                  </div>
                  <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-100 col-span-2">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">{text.completion}</div>
                    <div className="font-bold text-slate-800 flex items-center gap-2">
                      {String(jsonData.completion_date)} 
                      <span className="text-sm font-normal text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                        {String(jsonData.days_required)} {text.days}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">{text.targets}</div>
                  <div className="flex flex-wrap gap-2">
                    {jsonData.target_surahs.map((s, idx) => (
                      <span key={idx} className="bg-white border border-emerald-100 px-3 py-1 rounded-full text-xs font-bold text-emerald-700 shadow-sm">
                        {String(s)}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-emerald-500/10 p-3 rounded-xl border border-emerald-100 text-sm text-emerald-900 italic leading-relaxed">
                  "{String(jsonData.schedule_summary)}"
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="prose prose-sm max-w-none dark:prose-invert whitespace-pre-wrap leading-relaxed">
            {String(message.content.replace(/```json[\s\S]*?```/g, ''))}
          </div>
        )}
        
        <div className={`text-[10px] mt-3 ${isModel ? 'text-slate-400' : 'text-emerald-200'} text-right font-medium`}>
          {new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
        </div>
      </div>
    </div>
  );
};

export default ChatMessageBubble;
