
import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { t } from '../../translations';
import { authService } from '../../services/authService';
import { Shield, Smartphone, User as UserIcon, Lock, ChevronRight, Check, Copy, AlertTriangle, Eye, EyeOff, AlertCircle } from 'lucide-react';

interface Props {
  language: Language;
  onSuccess: (user: any) => void;
}

const AuthPage: React.FC<Props> = ({ language, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [formData, setFormData] = useState({ name: '', phone: '+998 ', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [nameError, setNameError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 2000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const triggerToast = (msg: string) => setToastMessage(msg);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^a-zA-Zа-яА-ЯёЁ\s']/g, '');
    if (value.length <= 30) {
      setFormData({ ...formData, name: value });
      setNameError(null);
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numbers = e.target.value.replace(/\D/g, '');
    if (!e.target.value.startsWith('+998')) {
        setFormData({ ...formData, phone: '+998 ' });
        return;
    }
    let formatted = '+998 ';
    const mainPart = numbers.startsWith('998') ? numbers.slice(3) : numbers;
    if (mainPart.length > 0) formatted += mainPart.slice(0, 2);
    if (mainPart.length > 2) formatted += ' ' + mainPart.slice(2, 5);
    if (mainPart.length > 5) formatted += ' ' + mainPart.slice(5, 7);
    if (mainPart.length > 7) formatted += ' ' + mainPart.slice(7, 9);
    
    if (formatted.length <= 17) {
      setFormData({ ...formData, phone: formatted });
      setPhoneError(null);
    }
  };

  const validateInputs = () => {
    let hasError = false;
    const VALID_OPERATORS = ['33', '50', '77', '88', '90', '91', '93', '94', '95', '97', '98', '99'];
    if (mode === 'register' && formData.name.trim().length < 2) {
      setNameError("Ismingizni to'liq kiriting");
      hasError = true;
    }
    const numbers = formData.phone.replace(/\D/g, '');
    if (numbers.length !== 12) {
      setPhoneError("Telefon raqami to'liq emas");
      hasError = true;
    } else {
      const operator = numbers.slice(3, 5);
      if (!VALID_OPERATORS.includes(operator)) {
        setPhoneError("Noto'g'ri operator kodi");
        hasError = true;
      }
    }
    return !hasError;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateInputs()) return;
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      if (mode === 'register') setStep('success');
      else onSuccess({ name: formData.name || 'Talaba', phone: formData.phone });
    } catch (err) {
      triggerToast("Xatolik yuz berdi");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsGoogleLoading(true);
    try {
      const result = await authService.googleLogin({
        email: 'demo@gmail.com',
        name: 'Google User',
        googleId: 'google_123',
        picture: 'https://i.pravatar.cc/150?u=google'
      });
      onSuccess(result.user);
    } catch (err) {
      triggerToast("Google xatoligi");
    } finally {
      setIsGoogleLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {toastMessage && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[1000] animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-full shadow-2xl border border-white/10 flex items-center gap-2">
            <Check size={14} className="text-emerald-400" />
            {toastMessage}
          </div>
        </div>
      )}

      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl border border-white relative z-10 overflow-hidden">
        {step === 'form' ? (
          <div className="p-8 md:p-10">
            <div className="text-center mb-6">
               <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-xl mx-auto mb-4 rotate-3">
                  <Shield size={28} />
               </div>
               <h2 className="text-2xl font-black text-slate-800 tracking-tight leading-none">
                 {mode === 'login' ? 'Xush Kelibsiz' : 'Ro\'yxatdan O\'tish'}
               </h2>
               <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mt-2">Hafiz AI Platformasi</p>
            </div>

            <div className="flex bg-slate-100 p-1 rounded-2xl mb-5">
               <button onClick={() => setMode('login')} className={`flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all ${mode === 'login' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}>Kirish</button>
               <button onClick={() => setMode('register')} className={`flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all ${mode === 'register' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400'}`}>Ro'yxatdan o'tish</button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              {mode === 'register' && (
                <div className="relative group">
                   <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={18} />
                   <input required type="text" placeholder="Ismingiz" className={`w-full pl-12 pr-6 py-3.5 bg-slate-50 border-2 rounded-2xl outline-none focus:bg-white transition-all font-bold text-slate-700 text-sm ${nameError ? 'border-red-500' : 'border-transparent focus:border-emerald-500'}`} value={formData.name} onChange={handleNameChange} />
                </div>
              )}
              <div className="relative group">
                 <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={18} />
                 <input required type="tel" placeholder="+998 90 123 45 67" className={`w-full pl-12 pr-6 py-3.5 bg-slate-50 border-2 rounded-2xl outline-none focus:bg-white transition-all font-bold text-slate-700 text-sm ${phoneError ? 'border-red-500' : 'border-transparent focus:border-emerald-500'}`} value={formData.phone} onChange={handlePhoneChange} />
              </div>
              <div className="relative group">
                 <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={18} />
                 <input required type={showPassword ? 'text' : 'password'} placeholder="Parol" className="w-full pl-12 pr-12 py-3.5 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-emerald-500 transition-all font-bold text-slate-700 text-sm" value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} />
                 <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                 </button>
              </div>
              <button type="submit" disabled={isLoading} className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] uppercase tracking-widest rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2">
                {isLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : 'Davom etish'}
                {!isLoading && <ChevronRight size={18} />}
              </button>
            </form>

            <div className="mt-4 pt-3 border-t border-slate-100 text-center">
                <p className="text-[9px] text-slate-400 font-black mb-2 uppercase tracking-widest leading-none">Yoki</p>
                <button onClick={handleGoogleLogin} className="w-full py-3.5 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-50 transition-all font-black text-[11px] text-slate-600 shadow-sm uppercase tracking-tight">
                   <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-4 h-4" alt="G" />
                   Google bilan kirish
                </button>
            </div>
          </div>
        ) : (
          <div className="p-10 text-center">
             <div className="w-20 h-20 bg-emerald-100 rounded-[2rem] flex items-center justify-center text-emerald-600 mx-auto mb-6"><Check size={40} /></div>
             <h3 className="text-2xl font-black text-slate-800 mb-1">Muvaffaqiyatli!</h3>
             <button onClick={() => onSuccess({ name: formData.name, phone: formData.phone })} className="w-full py-4.5 bg-emerald-600 text-white font-black text-[11px] uppercase rounded-2xl mt-6">Boshlash</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuthPage;
