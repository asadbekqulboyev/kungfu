
import React from 'react';
import Skeleton, { SkeletonTheme } from 'react-loading-skeleton';

const SkeletonAyah: React.FC = () => {
  return (
    <SkeletonTheme baseColor="#f1f5f9" highlightColor="#ffffff">
      <div className="w-full max-w-4xl mx-auto space-y-10 pt-10">
        
        {/* Arabic Text Lines */}
        <div className="flex flex-col items-center gap-6">
          <Skeleton width="90%" height={60} borderRadius={8} />
          <Skeleton width="70%" height={60} borderRadius={8} />
        </div>

        {/* Progress Bar Placeholder */}
        <div className="w-full max-w-lg mx-auto mt-8">
           <div className="flex justify-between mb-2">
              <Skeleton width={80} height={16} />
              <Skeleton width={40} height={20} />
           </div>
           <Skeleton height={16} borderRadius={8} />
        </div>

        {/* Translation */}
        <div className="space-y-3 max-w-3xl mx-auto pt-4">
          <Skeleton count={1} height={20} width="100%" />
          <Skeleton count={1} height={20} width="85%" />
          <Skeleton count={1} height={20} width="90%" />
        </div>

        {/* Tafsir Placeholder */}
        <div className="max-w-3xl mx-auto pt-4">
          <Skeleton height={50} borderRadius={12} />
        </div>

      </div>
    </SkeletonTheme>
  );
};

export default SkeletonAyah;
