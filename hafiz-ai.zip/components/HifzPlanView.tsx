
import React, { useState, useEffect } from 'react';
import { Surah, HifzPlanJSON, HifzDayTask, AppMode, Language } from '../types';
import { 
  Calendar, Target, Clock, Zap, ChevronRight, Loader2, 
  PlayCircle, Info, Star, Award, CheckCircle2, TrendingUp, 
  BellRing, Quote, BrainCircuit, LayoutList, CheckCircle,
  Sparkles, PartyPopper, ArrowRight, Smile
} from 'lucide-react';
import { getSurahNameUz } from '../utils/quranUtils';
import HifzPlanningWizard from './HifzPlanningWizard';

interface Props {
  surahs: Surah[];
  onStartAyah: (surahNum: number, ayahIdx: number) => void;
}

const MOTIVATIONS = [
  "MashaAlloh! Bugungi tilovatingiz sizni jannat darajalariga ko'taradi.",
  "Har bir yodlagan harfingiz uchun o'nta hasana bor. Davom eting!",
  "Qur'on qalbning bahori va nuridir. Bugun qalbingizni nurlantiring.",
  "Eng yaxshilaringiz - Qur'onni o'rganib, uni o'rgatganingizdir.",
  "Sabr qiling! Qur'on yodlashning har bir mashaqqati ajrdir."
];

const HifzPlanView: React.FC<Props> = ({ surahs, onStartAyah }) => {
  const [activePlan, setActivePlan] = useState<HifzPlanJSON | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showWizard, setShowWizard] = useState(false);
  const [motivation, setMotivation] = useState("");
  const [showBonusPrompt, setShowBonusPrompt] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('active_hifz_plan');
    if (saved) setActivePlan(JSON.parse(saved));
    setIsLoading(false);
    setMotivation(MOTIVATIONS[Math.floor(Math.random() * MOTIVATIONS.length)]);
  }, []);

  const currentTask = activePlan?.schedule.find(t => {
     const taskDate = new Date(t.date).toDateString();
     const today = new Date().toDateString();
     return taskDate === today;
  }) || activePlan?.schedule[activePlan ? activePlan.currentDay - 1 : 0];

  const handleCompleteTask = () => {
    if (!activePlan || !currentTask) return;
    const updated = { ...activePlan };
    const taskIdx = updated.schedule.findIndex(t => t.day === currentTask.day);
    if (taskIdx !== -1) {
        updated.schedule[taskIdx].isCompleted = true;
        // Check if there's a next task to suggest bonus
        const nextTask = updated.schedule[taskIdx + 1];
        if (nextTask) {
          setShowBonusPrompt(true);
        }
        localStorage.setItem('active_hifz_plan', JSON.stringify(updated));
        setActivePlan(updated);
    }
  };

  const startBonusTask = () => {
    setShowBonusPrompt(false);
    if (!activePlan || !currentTask) return;
    const taskIdx = activePlan.schedule.findIndex(t => t.day === currentTask.day);
    const nextTask = activePlan.schedule[taskIdx + 1];
    if (nextTask) {
      onStartAyah(nextTask.surahNumber, nextTask.startAyah - 1);
    }
  };

  if (isLoading) return <div className="p-20 text-center"><Loader2 className="animate-spin mx-auto text-emerald-600" /></div>;

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] font-sans relative">
      <div className="bg-white border-b px-6 py-8 md:px-12 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shrink-0">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg"><LayoutList size={20} /></div>
             <h2 className="text-2xl font-black text-slate-800 tracking-tight">Hifz Boshqaruvi</h2>
          </div>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Shaxsiy AI Muallim Rejasi</p>
        </div>
        <button onClick={() => setShowWizard(true)} className="px-8 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl shadow-slate-200 hover:bg-emerald-600 transition-all flex items-center gap-3 active:scale-95">
          <Zap size={16} /> Rejani Yangilash
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-12">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {activePlan && currentTask ? (
            <>
              {/* Motivatsiya Banner */}
              <div className="bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group">
                <div className="relative z-10">
                  <div className="flex items-center gap-2 mb-6">
                     <Quote size={24} className="text-emerald-300" />
                     <span className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-200">AI Kunlik Motivatsiya</span>
                  </div>
                  <h3 className="text-2xl md:text-3xl font-black leading-tight italic max-w-2xl">"{motivation}"</h3>
                </div>
                <BrainCircuit className="absolute right-[-20px] bottom-[-20px] w-64 h-64 text-white/10 group-hover:scale-110 transition-transform duration-1000" />
              </div>

              {/* Bugungi Vazifa Main Card */}
              <div className="bg-white rounded-[3.5rem] p-10 md:p-16 border-2 border-emerald-50 shadow-xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-12 opacity-[0.03] group-hover:scale-110 transition-transform duration-700"><Target size={250} /></div>
                
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-10">
                    <span className="px-5 py-2 bg-emerald-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl shadow-emerald-100">Bugun</span>
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em]">{currentTask.date} • Kun {currentTask.day}</span>
                  </div>

                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-14">
                    <div className="flex items-center gap-8">
                      <div className="w-24 h-24 bg-emerald-50 text-emerald-600 rounded-[2.5rem] flex items-center justify-center font-black text-4xl shadow-inner border-2 border-white">{currentTask.surahNumber}</div>
                      <div className="space-y-1">
                        <h3 className="text-4xl font-black text-slate-900 tracking-tighter">{getSurahNameUz(surahs.find(s => s.number === currentTask.surahNumber)?.englishName || '')}</h3>
                        <p className="text-slate-400 font-bold text-xl uppercase tracking-tighter">{currentTask.startAyah}-{currentTask.endAyah} oyatlar</p>
                      </div>
                    </div>
                    <div className="bg-slate-50 px-8 py-6 rounded-[2.5rem] border border-slate-100">
                       <p className="text-[10px] font-black text-slate-300 uppercase mb-2 tracking-widest">Eslatma</p>
                       <div className="text-2xl font-black text-slate-800 flex items-center gap-3"><BellRing size={24} className="text-amber-500 animate-swing" /> {activePlan.notification_time}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <button 
                      onClick={() => onStartAyah(currentTask.surahNumber, currentTask.startAyah - 1)}
                      className="py-7 bg-emerald-600 text-white rounded-[2.5rem] font-black text-xs uppercase tracking-[0.3em] shadow-2xl shadow-emerald-100 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center gap-4 group/btn"
                    >
                      Boshlash <PlayCircle size={24} className="group-hover/btn:scale-125 transition-transform" />
                    </button>
                    <button 
                      onClick={handleCompleteTask}
                      disabled={currentTask.isCompleted}
                      className={`py-7 rounded-[2.5rem] font-black text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-4 ${currentTask.isCompleted ? 'bg-slate-100 text-slate-300 cursor-default' : 'bg-white border-4 border-emerald-600 text-emerald-600 hover:bg-emerald-50 active:scale-95 shadow-xl shadow-slate-100'}`}
                    >
                      {currentTask.isCompleted ? 'Bajarildi' : 'Tugatdim'} <CheckCircle size={24} />
                    </button>
                  </div>
                </div>
              </div>

              {/* Progress & Info Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 {[
                   { label: 'Tugatish Sanasi', value: activePlan.target_date, icon: Calendar, color: 'text-blue-500', bg: 'bg-blue-50' },
                   { label: 'Kunlik Maqsad', value: activePlan.daily_goal_weight + ' oyat (vazn)', icon: Zap, color: 'text-amber-500', bg: 'bg-amber-50' },
                   { label: 'Umumiy Progress', value: `${activePlan.currentDay}/${activePlan.days_required} kun`, icon: TrendingUp, color: 'text-purple-500', bg: 'bg-purple-50' }
                 ].map((item, i) => (
                   <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-50 flex items-center gap-5 shadow-sm hover:shadow-xl transition-all group">
                      <div className={`w-14 h-14 ${item.bg} rounded-2xl flex items-center justify-center ${item.color} group-hover:scale-110 transition-transform`}><item.icon size={28} /></div>
                      <div>
                        <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1">{item.label}</p>
                        <p className="text-base font-black text-slate-800">{item.value}</p>
                      </div>
                   </div>
                 ))}
              </div>
            </>
          ) : (
            <div className="py-32 flex flex-col items-center text-center space-y-10 animate-in zoom-in-95">
               <div className="relative">
                  <div className="absolute inset-0 bg-emerald-100 rounded-full blur-[60px] opacity-50 animate-pulse"></div>
                  <div className="w-32 h-32 bg-white rounded-[3.5rem] flex items-center justify-center text-slate-200 relative z-10 shadow-2xl border border-slate-50"><Target size={64} /></div>
               </div>
               <div className="space-y-3">
                 <h3 className="text-3xl font-black text-slate-800 tracking-tighter">Hifz rejangizni tuzing</h3>
                 <p className="text-slate-400 text-base max-w-sm mx-auto font-medium leading-relaxed">AI Muallim yordamida Qur'onni tizimli va oson yodlashni boshlang. Vaqtingizni oqilona taqsimlaymiz.</p>
               </div>
               <button onClick={() => setShowWizard(true)} className="px-16 py-6 bg-emerald-600 text-white rounded-[2rem] font-black uppercase text-xs tracking-[0.3em] shadow-2xl shadow-emerald-200 hover:scale-105 active:scale-95 transition-all">Rejani Shakllantirish</button>
            </div>
          )}
        </div>
      </div>

      {/* BONUS PROMPT MODAL */}
      {showBonusPrompt && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[3rem] p-8 md:p-12 shadow-2xl border border-emerald-50 text-center relative overflow-hidden animate-in zoom-in-95 duration-300">
             <div className="absolute -top-10 -right-10 w-40 h-40 bg-emerald-50 rounded-full blur-3xl opacity-50 animate-pulse"></div>
             
             <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner">
                <PartyPopper size={40} />
             </div>
             
             <h3 className="text-2xl font-black text-slate-800 mb-4 tracking-tight leading-tight">Barakalloh, {MOTIVATIONS[0].split('!')[0]}!</h3>
             <p className="text-slate-500 font-medium mb-10 leading-relaxed italic">
               Bugungi vazifani 100% bajardingiz. MashaAlloh! Ertangi rejangizdan ham bir ozini (1-2 oyat) hoziroq bajarib qo'yishni xohlaysizmi? Bu sizga ertangi yuklamani kamaytirishga yordam beradi.
             </p>
             
             <div className="space-y-3">
                <button 
                  onClick={startBonusTask}
                  className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-emerald-100 hover:bg-emerald-700 active:scale-95 transition-all flex items-center justify-center gap-3"
                >
                  Ha, albatta <Sparkles size={18} />
                </button>
                <button 
                  onClick={() => setShowBonusPrompt(false)}
                  className="w-full py-5 bg-white text-slate-400 font-black text-[11px] uppercase tracking-widest rounded-2xl border-2 border-slate-50 hover:bg-slate-50 transition-all"
                >
                  Bugun yetarli <Smile size={18} className="inline ml-1" />
                </button>
             </div>
          </div>
        </div>
      )}

      {showWizard && <HifzPlanningWizard surahs={surahs} language={Language.UZ} onClose={() => setShowWizard(false)} onComplete={plan => { setActivePlan(plan); setShowWizard(false); }} />}
      
      <style>{`
        @keyframes swing {
          0%, 100% { transform: rotate(0); }
          25% { transform: rotate(15deg); }
          75% { transform: rotate(-15deg); }
        }
        .animate-swing {
          animation: swing 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default HifzPlanView;
