
import React, { useState } from 'react';
import { User } from '../types';
import { authService } from '../services/api';
import { Phone, Lock, UserCircle, LogIn } from 'lucide-react';

const Auth: React.FC<{ onAuth: (u: User) => void }> = ({ onAuth }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ name: '', phone: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = isLogin 
        ? await authService.login({ phone: formData.phone, password: formData.password })
        : await authService.register(formData);
      
      // Fix: Removed non-existent error property check on User type since authService returns a User object on success.
      onAuth(res);
    } catch (err: any) {
      setError(err?.message || 'Tizim xatosi, qayta urinib ko\'ring');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-emerald-50">
      <div className="w-full max-w-md bg-white rounded-[3rem] shadow-2xl p-10 border border-emerald-100 flex flex-col items-center">
        <div className="w-20 h-20 bg-emerald-600 rounded-3xl flex items-center justify-center text-white mb-6 shadow-xl shadow-emerald-200 rotate-6">
          <LogIn size={32} />
        </div>
        
        <h2 className="text-3xl font-black text-slate-800 mb-2">Hafiz AI</h2>
        <p className="text-slate-400 mb-10 text-sm font-medium">Qur'onni biz bilan yodlang</p>

        {error && <div className="w-full p-4 mb-6 bg-red-50 text-red-500 rounded-2xl text-xs font-bold text-center border border-red-100 animate-shake">{error}</div>}

        <form onSubmit={handleSubmit} className="w-full space-y-4">
          {!isLogin && (
            <div className="relative">
              <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
              <input 
                type="text" 
                placeholder="Ismingiz" 
                className="w-full pl-12 pr-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500 font-medium"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
              />
            </div>
          )}
          <div className="relative">
            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
            <input 
              type="tel" 
              placeholder="Telefon raqami" 
              className="w-full pl-12 pr-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500 font-medium"
              value={formData.phone}
              onChange={(e) => setFormData({...formData, phone: e.target.value})}
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
            <input 
              type="password" 
              placeholder="Parol" 
              className="w-full pl-12 pr-6 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500 font-medium"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              required
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-xl shadow-emerald-100 transition-all active:scale-95 disabled:opacity-50 mt-4"
          >
            {loading ? 'Tekshirilmoqda...' : isLogin ? 'Kirish' : 'Roʻyxatdan oʻtish'}
          </button>
        </form>

        <button 
          onClick={() => setIsLogin(!isLogin)}
          className="mt-8 text-sm font-bold text-emerald-600 hover:underline"
        >
          {isLogin ? "Hisobingiz yo'qmi? Roʻyxatdan oʻting" : "Hisobingiz bormi? Kirish"}
        </button>
      </div>
    </div>
  );
};

export default Auth;
