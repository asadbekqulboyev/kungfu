
import React from 'react';

export const ListSkeleton = () => (
  <div className="space-y-4 w-full animate-pulse p-4">
    {[1, 2, 3, 4, 5].map(i => (
      <div key={i} className="h-16 bg-emerald-100/50 rounded-2xl border border-emerald-50"></div>
    ))}
  </div>
);

export const AyahSkeleton = () => (
  <div className="space-y-6 w-full animate-pulse p-8">
    <div className="h-8 bg-slate-100 w-1/3 mx-auto rounded"></div>
    <div className="h-32 bg-slate-100 w-full rounded-3xl"></div>
    <div className="h-10 bg-slate-100 w-2/3 mx-auto rounded"></div>
  </div>
);
