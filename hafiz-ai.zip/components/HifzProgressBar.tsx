
import React from 'react';

interface Props {
  count: number;
}

const TOTAL_AYAHS = 6236;

const HifzProgressBar: React.FC<Props> = ({ count }) => {
  const percentage = Math.min(100, Math.max(0, (count / TOTAL_AYAHS) * 100));
  
  // To'q va qattiq ranglar o'rniga yumshoq "Modern Zen" ranglari
  const progressColor = 'bg-emerald-400';
  const trackColor = 'bg-emerald-50';

  return (
    <div className="w-full relative group">
      <div className={`h-1.5 md:h-2 w-full ${trackColor} rounded-full overflow-hidden flex shadow-inner border border-emerald-100/30`}>
        <div 
          className={`h-full ${progressColor} transition-all duration-1000 ease-out shadow-[0_0_8px_rgba(52,211,153,0.3)] rounded-full`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      
      {/* Tooltip */}
      <div className="absolute top-4 right-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-50 px-2">
         <div className="bg-white border border-emerald-100 px-3 py-1.5 rounded-xl shadow-xl whitespace-nowrap">
           <span className="text-[10px] font-black text-emerald-600">
             {count} / {TOTAL_AYAHS} oyat ({percentage.toFixed(1)}%)
           </span>
         </div>
      </div>
      
      {/* Percentage Label */}
      {percentage > 0 && (
         <div className="absolute -top-4 right-0 text-[9px] font-black text-emerald-400 tracking-wider">
            {percentage.toFixed(1)}%
         </div>
      )}
    </div>
  );
};

export default HifzProgressBar;
