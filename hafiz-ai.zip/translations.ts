
import { Language } from './types';

export const t = {
  [Language.EN]: {
    // Auth
    loginTitle: "Login to Hafiz AI",
    registerTitle: "Create Account",
    phoneLabel: "Phone Number",
    nameLabel: "Your Name",
    continueBtn: "Continue",
    otpTitle: "Verification",
    otpSubtitle: "Enter the code sent to",
    resend: "Resend Code",
    googleBtn: "Continue with Google",
    orSeparator: "OR",
    alreadyHaveAccount: "Already have an account?",
    noAccount: "Don't have an account?",
    loginLink: "Login",
    registerLink: "Register",
    logout: "Logout",
    profile: "My Profile",

    // Landing Page
    heroTitle: "Master the Quran with AI",
    heroSubtitle: "Your personal tutor for Hifz, Tajweed, and Recitation. Anytime, anywhere.",
    startJourney: "Start Journey",
    standardMode: "Standard Mode",
    standardDesc: "For serious students. Focus on Hifz, Tajweed rules, and detailed analysis.",
    kidsMode: "Kids Mode",
    kidsDesc: "Fun, encouraging, and gentle guidance for young learners.",
    startBtn: "Select Mode",
    resumeBtn: "Resume Session",
    creatingSession: "Creating session...",
    sessionError: "Could not start session. Please try again.",
    
    // Landing Features
    featuresTitle: "Why Choose Hafiz AI?",
    feature1Title: "Real-time Tajweed",
    feature1Desc: "Instant feedback on your pronunciation using advanced AI listening technology.",
    feature2Title: "Smart Hifz Plan",
    feature2Desc: "Adaptive schedules that calculate daily goals based on your memorization speed.",
    feature3Title: "Voice Powered",
    feature3Desc: "Interact naturally. Just speak to control the app, recite, and get corrections.",

    // Header
    appTitle: "Hafiz AI",
    appSubtitle: "Quran Tutor",
    planHifz: "+ Plan Hifz",
    
    // Progress
    mastered: "Mastered",
    learning: "Learning",
    review: "Review",
    
    // Sidebar
    surahIndex: "Surah Index",
    loadingSurah: "Loading Surah...",
    
    // Modes
    teaching: "Teaching",
    testing: "Testing",
    analysis: "Analysis",
    modeSuffix: "Mode",
    
    // Ayah Card
    ayahPrefix: "Ayah",
    revelationType: "Revelation",
    tafsirLabel: "Tafsir & Meaning",
    tafsirUnavailable: "Tafsir interpretation is not available for this specific ayah yet. Consult the detailed analysis from Hafiz AI for more context.",
    textHidden: "Text hidden in Testing Mode",
    submittingAyah: "You are submitting Surah {surah}, Ayah {ayah}",
    
    // Controls
    listen: "Listen to Ustoz",
    playing: "Playing...",
    record: "Record",
    analyzing: "Analyzing...",
    holdToRecord: "Hold to Record",
    
    // Chat
    tutorChat: "Tutor Chat",
    tutorFeedback: "Feedback",
    you: "You",
    hafizAi: "Hafiz AI",
    noMessages: "No messages yet",
    startPrompt: "Start recording or ask for a Hifz plan to begin.",
    voicePlaceholder: "Voice commands only for now...",
    
    // Chat Bubble Cards
    accuracy: "Accuracy Score",
    feedback: "Overall Feedback",
    corrections: "Detailed Corrections",
    try: "Try",
    hifzPlan: "Your Hifz Plan",
    dailyGoal: "Daily Goal",
    totalLoad: "Total Load",
    completion: "Completion Date",
    days: "days",
    targets: "Target Surahs",
    
    // Messages / Prompts
    welcome: "As-salamu alaykum! I am Hafiz AI. Choose a mode or ask me to create a Hifz Plan.",
    networkError: "Network error. Please try again.",
    analyzeReq: "Please analyze my recitation.",
    checkReq: "I have recited this ayah. Check it.",
    planReq: "I want to create a structured Hifz memorization plan.",
    planPrompt: "I want to create a Hifz plan. Guide me.",

    // Wizard
    wizardTitle: "Hifz Planning Wizard",
    step1: "Select Target Surahs",
    step2: "Select Known Surahs",
    step3: "Time & Capacity",
    next: "Next",
    back: "Back",
    finish: "Generate Plan",
    exit: "Exit",
    searchSurah: "Search Surah...",
    selectTargetsMsg: "Which Surahs do you want to memorize?",
    selectKnownMsg: "Which of these do you already know? (They will be excluded)",
    totalAyahs: "Total Ayahs",
    daysToComplete: "Days to complete",
    dailyCapacity: "Daily memorization limit (ayahs)",
    calculating: "Calculating...",
    summary: "Summary",
    selected: "selected",
    generatePlanPrompt: "I have completed the planning wizard. Please generate a JSON Hifz Plan based on this data:\nTargets: {targets}\nExcluded (Known): {known}\nTimeframe: {days} days\nDaily Capacity: {daily} ayahs.\nEnsure the output is strictly the HifzPlanJSON format.",

    // Analysis View
    analysisTitle: "Quran Search & Analysis",
    analysisSubtitle: "Recite, type arabic, or type meaning to find Ayah",
    typePlaceholder: "Type text or meaning (e.g. 'The Sun', 'Inna a'tayna')",
    identifyBtn: "Identify",
    foundMatches: "Found Matches",
    confidence: "Confidence",
    playAudio: "Listen",
    goToAyah: "Go to Ayah",
    noMatches: "No matches found. Try clarifying the meaning or recitation.",
    startAnalysis: "Recite or type meaning",

    // Kids Mode
    kidsHome: "Kids Home",
    learnSurahs: "Learn Surahs",
    playMemorize: "Play & Memorize",
    myRewards: "My Rewards",
    parentsArea: "Parents Dashboard",
    helloFriend: "Hello friend! I am Ustoz Noor.",
    readyToLearn: "Are you ready to learn Quran?",
    perfect: "Perfect! MashaAllah!",
    goodTry: "Good try! Let's do it again.",
    tryAgain: "Let's practice one more time.",
    listenBtn: "Listen",
    recordBtn: "Recite",
    nextBtn: "Next",
    stars: "Stars",
    streak: "Streak",
    lessonComplete: "Lesson Complete!",
    youEarned: "You Earned:",
    totalStars: "Total Stars",
    
    // Ustoz Noor Dialogue
    ustozGreeting: "As-salamu alaykum! Let's learn Surah {surah} together!",
    ustozListen: "First, listen to me carefully.",
    ustozYourTurn: "Now it's your turn! Recite loudly.",
    ustozCorrect: "MashaAllah! That was beautiful!",
    ustozAlmost: "Very good! Just watch the red letters.",
    ustozRetry: "Don't worry, let's try together again."
  },
  [Language.UZ]: {
    // Auth
    loginTitle: "Hofiz AI - Kirish",
    registerTitle: "Ro'yxatdan O'tish",
    phoneLabel: "Telefon raqamingiz",
    nameLabel: "Ismingiz",
    continueBtn: "Davom Etish",
    otpTitle: "Tasdiqlash Kodi",
    otpSubtitle: "Kod ushbu raqamga yuborildi",
    resend: "Qayta yuborish",
    googleBtn: "Google orqali kirish",
    orSeparator: "YOKI",
    alreadyHaveAccount: "Akkountingiz bormi?",
    noAccount: "Akkountingiz yo'qmi?",
    loginLink: "Kirish",
    registerLink: "Ro'yxatdan o'tish",
    logout: "Chiqish",
    profile: "Mening Profilim",

    // Landing Page
    heroTitle: "Qur'onni AI bilan Mukammal O'rganing",
    heroSubtitle: "Sizning shaxsiy Hifz va Tajvid ustozingiz. Istalgan vaqtda, istalgan joyda.",
    startJourney: "Boshlash",
    standardMode: "Standart Rejim",
    standardDesc: "Jiddiy o'quvchilar uchun. Hifz, Tajvid qoidalari va chuqur tahlil.",
    kidsMode: "Bolalar Rejimi",
    kidsDesc: "Yosh o'quvchilar uchun qiziqarli va yengil uslub.",
    startBtn: "Rejimni Tanlash",
    resumeBtn: "Davom Ettirish",
    creatingSession: "Sessiya yaratilmoqda...",
    sessionError: "Sessiyani boshlashda xatolik. Qayta urinib ko'ring.",

    // Landing Features
    featuresTitle: "Nega aynan Hofiz AI?",
    feature1Title: "Jonli Tajvid Tahlili",
    feature1Desc: "Sun'iy intellekt yordamida talaffuzingizdagi xatolarni darhol aniqlang va tuzating.",
    feature2Title: "Aqlli Hifz Rejasi",
    feature2Desc: "Sizning yodlash tezligingizga moslashuvchi shaxsiy va moslashuvchan reja.",
    feature3Title: "Ovozli Boshqaruv",
    feature3Desc: "Tabiiy muloqot qiling. Ilovani boshqarish va savol berish uchun shunchaki gapiring.",

    // Header
    appTitle: "Hofiz AI",
    appSubtitle: "Qur'on Muallimi",
    planHifz: "+ Hifz Reja",
    
    // Progress
    mastered: "O'zlashtirildi",
    learning: "O'rganilmoqda",
    review: "Takrorlash",
    
    // Sidebar
    surahIndex: "Suralar Ro'yxati",
    loadingSurah: "Sura yuklanmoqda...",
    
    // Modes
    teaching: "O'rgatish",
    testing: "Sinov",
    analysis: "Tahlil",
    modeSuffix: "Rejimi",
    
    // Ayah Card
    ayahPrefix: "Oyat",
    revelationType: "Vahiy",
    tafsirLabel: "Tafsir va Ma'no",
    tafsirUnavailable: "Ushbu oyat uchun tafsir mavjud emas. Tafsilotlar uchun Hofiz AI tahliliga murojaat qiling.",
    textHidden: "Sinov rejimida matn yashirilgan",
    submittingAyah: "Siz {surah} surasi {ayah}-oyatini topshirmoqdasiz",
    
    // Controls
    listen: "Ustozni Tinglash",
    playing: "O'qilmoqda...",
    record: "Yozish",
    analyzing: "Tahlil...",
    holdToRecord: "Yozish Uchun Bosing",
    
    // Chat
    tutorChat: "Ustoz Chat",
    tutorFeedback: "Ustoz Fikri",
    you: "Siz",
    hafizAi: "Hofiz AI",
    noMessages: "Xabarlar yo'q",
    startPrompt: "Boshlash uchun yozing yoki reja so'rang.",
    voicePlaceholder: "Faqat ovozli buyruqlar...",
    
    // Chat Bubble Cards
    accuracy: "Aniqlik Darajasi",
    feedback: "Umumiy Xulosa",
    corrections: "Batafsil Tuzatishlar",
    try: "To'g'risi",
    hifzPlan: "Hifz Rejangiz",
    dailyGoal: "Kunlik Maqsad",
    totalLoad: "Jami Hajm",
    completion: "Tugatish Sanasi",
    days: "kun",
    targets: "Maqsadli Suralar",
    
    // Messages / Prompts
    welcome: "Assalomu alaykum! Men Hofiz AI man. Bugun nima qilamiz?",
    networkError: "Tarmoq xatosi. Qayta urinib ko'ring.",
    analyzeReq: "Iltimos, qiroatimni tahlil qiling.",
    checkReq: "O'qib bo'ldim. Tekshiring.",
    planReq: "Hifz rejasini tuzmoqchiman.",
    planPrompt: "Hifz rejasini tuzishda yordam bering.",

    // Wizard
    wizardTitle: "Hifz Rejalashtirish",
    step1: "Suralarni Tanlash",
    step2: "Bilganlaringizni Belgilang",
    step3: "Vaqt va Qobiliyat",
    next: "Keyingi",
    back: "Orqaga",
    finish: "Rejani Tuzish",
    exit: "Chiqish",
    searchSurah: "Surani izlash...",
    selectTargetsMsg: "Qaysi suralarni yodlamoqchisiz?",
    selectKnownMsg: "Bulardan qaysilarini allaqachon bilasiz? (Ular chiqarib tashlanadi)",
    totalAyahs: "Jami Oyatlar",
    daysToComplete: "Necha kunda tugatasiz?",
    dailyCapacity: "Kunlik yodlash limiti (oyat)",
    calculating: "Hisoblanmoqda...",
    summary: "Xulosa",
    selected: "tanlandi",
    generatePlanPrompt: "Men rejalashtirish ustasini yakunladim. Iltimos, ushbu ma'lumotlarga asoslanib JSON Hifz Rejasini tuzing:\nMaqsad: {targets}\nBilganlarim (chiqarib tashlash): {known}\nVaqt: {days} kun\nKunlik limit: {daily} oyat.\nJavob faqat HifzPlanJSON formatida bo'lsin.",
    
    // Analysis View
    analysisTitle: "Qur'on Qidiruvi va Tahlil",
    analysisSubtitle: "Matn, audio yoki ma'nosi bo'yicha izlash",
    typePlaceholder: "Matn yoki ma'nosini yozing (masalan: 'Quyosh', 'Inna a'tayna')",
    identifyBtn: "Aniqlash",
    foundMatches: "Topilgan Oyatlar",
    confidence: "Aniqlik",
    playAudio: "Eshiting",
    goToAyah: "Oyatga o'tish",
    noMatches: "Oyat topilmadi. Ma'nosini aniqroq yozib ko'ring.",
    startAnalysis: "O'qing yoki ma'nosini yozing",

    // Kids Mode
    kidsHome: "Bolalar Menyusi",
    learnSurahs: "Suralarni O'rganish",
    playMemorize: "O'yin va Yodlash",
    myRewards: "Yutuqlarim",
    parentsArea: "Ota-onalar Uchun",
    helloFriend: "Salom do'stim! Men Ustoz Nurman.",
    readyToLearn: "Qur'on o'rganishga tayyormisiz?",
    perfect: "Ajoyib! Barakalla!",
    goodTry: "Yaxshi urinish! Yana bir bor.",
    tryAgain: "Keling, yana mashq qilamiz.",
    listenBtn: "Tinglash",
    recordBtn: "O'qish",
    nextBtn: "Keyingi",
    stars: "Yulduzchalar",
    streak: "Kunlik",
    lessonComplete: "Dars Tugadi!",
    youEarned: "Siz yutdingiz:",
    totalStars: "Jami Yulduzlar",

    // Ustoz Noor Dialogue
    ustozGreeting: "Assalomu alaykum! Keling, {surah} surasini birga o'rganamiz!",
    ustozListen: "Avval men o'qib beraman, diqqat bilan eshiting.",
    ustozYourTurn: "Ana endi navbat sizga! Baland ovozda o'qing.",
    ustozCorrect: "MashaAlloh! Juda chiroyli o'qidingiz!",
    ustozAlmost: "Juda yaxshi! Faqat qizil harflarga e'tibor bering.",
    ustozRetry: "Hechqisi yo'q, keling yana bir bor birga qaytaramiz."
  }
};
