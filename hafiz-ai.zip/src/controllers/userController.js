import User from '../models/User.js';

// @desc    Update Language
// @route   PATCH /user/language
export const updateLanguage = async (req, res) => {
  const { language } = req.body;

  if (!['uz', 'en', 'ru'].includes(language)) {
    return res.status(400).json({ error: 'Invalid language selection' });
  }

  try {
    const user = req.user;
    user.language = language;
    await user.save();

    res.status(200).json({
      success: true,
      language: user.language,
      message: 'Language updated'
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// @desc    Get User Stats (Placeholder)
// @route   GET /user/stats
export const getUserStats = async (req, res) => {
  // Logic to aggregate data from Progress model would go here
  res.status(200).json({
    totalMemorized: 0,
    currentStreak: 0,
    lastActivity: req.user.lastLogin
  });
};