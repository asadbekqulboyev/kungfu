import HifzPlan from '../models/HifzPlan.js';
import Progress from '../models/Progress.js';

// @desc    Create/Update Hifz Plan
// @route   POST /hifz/plan
export const createPlan = async (req, res) => {
  const { selectedSurahs, dailyGoal } = req.body;

  try {
    // Placeholder logic
    const plan = await HifzPlan.create({
      userId: req.user._id,
      selectedSurahs,
      dailyGoal,
      estimatedCompletion: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // Mock 30 days
    });

    res.status(201).json({ success: true, plan });
  } catch (error) {
    res.status(500).json({ error: 'Error creating plan' });
  }
};

// @desc    Save Progress for Ayah
// @route   POST /hifz/progress
export const saveProgress = async (req, res) => {
  const { surahNumber, ayahNumber, status } = req.body;

  try {
    const progress = await Progress.findOneAndUpdate(
      { userId: req.user._id, surahNumber, ayahNumber },
      { status, lastReviewed: Date.now() },
      { upsert: true, new: true }
    );

    res.status(200).json({ success: true, progress });
  } catch (error) {
    res.status(500).json({ error: 'Error saving progress' });
  }
};

// @desc    Get User Progress
// @route   GET /hifz/progress
export const getProgress = async (req, res) => {
  try {
    const progress = await Progress.find({ userId: req.user._id });
    res.status(200).json({ success: true, count: progress.length, progress });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching progress' });
  }
};