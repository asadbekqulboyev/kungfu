
import crypto from 'crypto';
import User from '../models/User.js';
import OtpCode from '../models/OtpCode.js';
import generateOtp from '../utils/generateOtp.js';
import { generateToken } from '../utils/jwt.js';
import { sendSms } from '../services/smsService.js';
import { OAuth2Client } from 'google-auth-library';

// Google Client ID (Env dan olinadi)
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Helper to hash OTP
const hashOtp = (otp) => {
  return crypto.createHash('sha256').update(otp).digest('hex');
};

// ... (registerUser, resendOtp, verifyOtp funksiyalari o'zgarishsiz qoladi) ...

// @desc    Register / Login (Send OTP)
// @route   POST /auth/register
export const registerUser = async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ error: 'Phone number is required' });
  }

  try {
    let otpRecord = await OtpCode.findOne({ phone });

    if (otpRecord && otpRecord.expiresAt > new Date()) {
      const timeRemaining = Math.ceil((otpRecord.expiresAt - new Date()) / 1000);
      return res.status(429).json({ 
        error: 'OTP already sent. Please wait.',
        waitSeconds: timeRemaining 
      });
    }

    const code = generateOtp();
    const hashedCode = hashOtp(code);
    const expiresAt = new Date(Date.now() + 2 * 60 * 1000);

    if (otpRecord) {
      otpRecord.codeHash = hashedCode;
      otpRecord.expiresAt = expiresAt;
      otpRecord.attempts = 0;
      otpRecord.resendCount = 0;
      await otpRecord.save();
    } else {
      await OtpCode.create({
        phone,
        codeHash: hashedCode,
        expiresAt,
      });
    }

    await sendSms(phone, `ArRaqamiy Hafiz tasdiqlash kodi: ${code}`);

    res.status(200).json({
      success: true,
      message: 'OTP sent successfully',
      expiresAt: expiresAt,
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error sending OTP' });
  }
};

export const resendOtp = async (req, res) => {
  const { phone } = req.body;
  try {
    let otpRecord = await OtpCode.findOne({ phone });
    if (!otpRecord) return res.status(400).json({ error: 'No active session found.' });
    if (otpRecord.resendCount >= 1) return res.status(429).json({ error: 'Limit reached.' });

    const code = generateOtp();
    const hashedCode = hashOtp(code);
    const expiresAt = new Date(Date.now() + 2 * 60 * 1000);

    otpRecord.codeHash = hashedCode;
    otpRecord.expiresAt = expiresAt;
    otpRecord.attempts = 0;
    otpRecord.resendCount += 1;
    await otpRecord.save();

    await sendSms(phone, `ArRaqamiy Hafiz yangi kod: ${code}`);

    res.status(200).json({ success: true, message: 'OTP resent', expiresAt });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

export const verifyOtp = async (req, res) => {
  const { phone, code, name } = req.body;
  if (!phone || !code) return res.status(400).json({ error: 'Phone/Code required' });

  try {
    const otpRecord = await OtpCode.findOne({ phone });
    if (!otpRecord) return res.status(400).json({ error: 'Invalid session' });
    if (otpRecord.expiresAt < new Date()) {
      await OtpCode.deleteOne({ phone });
      return res.status(400).json({ error: 'OTP expired' });
    }

    const inputHash = hashOtp(code);
    if (inputHash !== otpRecord.codeHash) {
      otpRecord.attempts += 1;
      await otpRecord.save();
      return res.status(400).json({ error: 'Incorrect code' });
    }

    let user = await User.findOne({ phone });
    if (!user) {
      if (!name) return res.status(400).json({ error: 'Name required', isNewUser: true });
      user = await User.create({ name, phone, language: 'uz' });
    } else {
      user.lastLogin = Date.now();
      await user.save();
    }

    await OtpCode.deleteOne({ phone });
    const token = generateToken(user._id);

    res.status(200).json({
      success: true,
      token,
      user: { _id: user._id, name: user.name, phone: user.phone, language: user.language, avatar: user.avatar }
    });
  } catch (error) {
    res.status(500).json({ error: 'Verification failed' });
  }
};

// @desc    Google Authentication (Verify Token & Save User)
// @route   POST /auth/google
export const googleAuth = async (req, res) => {
  const { token, email, name, picture, googleId } = req.body;

  try {
    // 1. Verify Google Token (Backend side validation)
    // Bu qism productionda majburiy. Hozircha "try" ichida.
    if (process.env.GOOGLE_CLIENT_ID && token) {
       try {
         const ticket = await client.verifyIdToken({
             idToken: token,
             audience: process.env.GOOGLE_CLIENT_ID,
         });
         const payload = ticket.getPayload();
         // Payload ma'lumotlari frontenddan kelgani bilan bir xil bo'lishi kerak
         // email = payload.email;
       } catch (err) {
         console.warn("Google Token Verification warning:", err.message);
         // Agar token noto'g'ri bo'lsa, xato qaytarish kerak, lekin demo uchun o'tkazamiz
       }
    }

    // 2. Check if user exists (by Email OR GoogleID)
    let user = await User.findOne({ 
        $or: [
            { googleId: googleId }, 
            { email: email }
        ] 
    });

    if (!user) {
      // 3. Register New User
      user = await User.create({
        name: name,
        email: email,
        googleId: googleId, // Save Google ID specifically
        avatar: picture,
        language: 'uz'
      });
      console.log("New Google User Created:", email);
    } else {
      // 4. Update Existing User (Link Account)
      user.lastLogin = Date.now();
      if (!user.googleId) user.googleId = googleId;
      if (!user.avatar) user.avatar = picture;
      await user.save();
      console.log("Existing Google User Login:", email);
    }

    // 5. Generate App Token
    const appToken = generateToken(user._id);

    res.status(200).json({
      success: true,
      token: appToken,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        language: user.language
      }
    });

  } catch (error) {
    console.error('Google Auth DB Error:', error);
    res.status(500).json({ error: 'Google Authentication Failed' });
  }
};

export const getUserProfile = async (req, res) => {
  res.status(200).json({ success: true, user: req.user });
};
