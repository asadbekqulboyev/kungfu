
import express from 'express';
import { registerUser, verifyOtp, resendOtp, getUserProfile, googleAuth } from '../controllers/authController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register', registerUser); // Sends OTP
router.post('/verify', verifyOtp);      // Checks OTP -> Returns Token
router.post('/resend', resendOtp);      // Resends OTP if allowed
router.post('/google', googleAuth);     // Google Login/Register
router.get('/profile', protect, getUserProfile);

export default router;
