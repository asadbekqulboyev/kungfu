import express from 'express';
import { updateLanguage, getUserStats } from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.patch('/language', protect, updateLanguage);
router.get('/stats', protect, getUserStats);
router.get('/me', protect, (req, res) => res.json(req.user));

export default router;