import express from 'express';
import { createPlan, saveProgress, getProgress } from '../controllers/hifzController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/plan', protect, createPlan);
router.post('/progress', protect, saveProgress);
router.get('/progress', protect, getProgress);

export default router;