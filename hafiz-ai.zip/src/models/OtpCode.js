import mongoose from 'mongoose';

const otpCodeSchema = mongoose.Schema({
  phone: {
    type: String,
    required: true,
    index: true, 
  },
  codeHash: {
    type: String,
    required: true,
  },
  expiresAt: {
    type: Date,
    required: true,
  },
  attempts: {
    type: Number,
    default: 0,
  },
  resendCount: {
    type: Number,
    default: 0,
  }
}, { timestamps: true });

// Auto-delete document after expiration time + buffer (e.g., 5 mins)
otpCodeSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 300 });

const OtpCode = mongoose.model('OtpCode', otpCodeSchema);
export default OtpCode;