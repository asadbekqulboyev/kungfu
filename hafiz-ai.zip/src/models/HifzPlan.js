import mongoose from 'mongoose';

const hifzPlanSchema = mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  selectedSurahs: [{
    type: Number, // Surah number
  }],
  dailyGoal: {
    type: Number,
    default: 5, // Ayahs per day
  },
  estimatedCompletion: {
    type: Date,
  },
  isActive: {
    type: Boolean,
    default: true,
  }
}, { timestamps: true });

const HifzPlan = mongoose.model('HifzPlan', hifzPlanSchema);
export default HifzPlan;