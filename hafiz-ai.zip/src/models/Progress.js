import mongoose from 'mongoose';

const progressSchema = mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  surahNumber: {
    type: Number,
    required: true,
  },
  ayahNumber: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['new', 'learning', 'review', 'mastered'],
    default: 'new',
  },
  lastReviewed: {
    type: Date,
    default: Date.now,
  }
}, { timestamps: true });

// Compound index for efficient lookup
progressSchema.index({ userId: 1, surahNumber: 1, ayahNumber: 1 }, { unique: true });

const Progress = mongoose.model('Progress', progressSchema);
export default Progress;