export const sendSms = async (phone, message) => {
  // In production, integrate with providers like Twilio, Eskiz, or PlayMobile
  console.log(`[SMS SERVICE] Sending to ${phone}: "${message}"`);
  return true;
};