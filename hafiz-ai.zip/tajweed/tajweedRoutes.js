
import express from 'express';
import * as tajweedController from './tajweedController.js';
import { protect } from '../middleware/authMiddleware.js';
import { analysisLimiter } from '../middleware/rateLimiter.js';

const router = express.Router();

// Mounting analyze endpoint with protection and rate limiting
router.post('/analyze', protect, analysisLimiter, tajweedController.analyze);

export default router;
