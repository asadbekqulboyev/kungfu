
import { GoogleGenAI } from "@google/genai";

/**
 * Service to handle Tajweed analysis using GenAI
 */
export const analyzeTajweedText = async (text) => {
  if (!text || text.trim().length === 0) {
    throw new Error("Tahlil uchun matn taqdim etilmadi.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `
    Siz professional Tajvid ustozisiz. Berilgan arabcha matn yoki transkripsiyadagi asosiy Tajvid qoidasini aniqlang.
    
    QOIDALAR:
    - Faqat bitta eng asosiy qoidani aniqlang.
    - Javobni FAQAT quyidagi JSON formatida qaytaring:
    {
      "detected_rule": "Qoida nomi",
      "explanation": "Qoidaning batafsil izohi (O'zbek tilida)",
      "confidence": 0.0 dan 1.0 gacha bo'lgan son,
      "suggestions": ["Amaliy maslahat 1", "Amaliy maslahat 2"]
    }
    - Agar matn arabcha bo'lmasa yoki qoida topilmasa, confidence past bo'lsin va tegishli izoh bering.
    - Til: O'zbek.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Matn: "${text}"`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.2
      }
    });

    const result = JSON.parse(response.text);
    return result;
  } catch (error) {
    console.error("Tajweed Analysis Error:", error);
    // Fallback response for safety
    return {
      detected_rule: "Noma'lum",
      explanation: "Tizim hozirda tahlil qila olmadi. Iltimos, qayta urinib ko'ring.",
      confidence: 0.1,
      suggestions: ["Qayta urinib ko'ring"]
    };
  }
};
