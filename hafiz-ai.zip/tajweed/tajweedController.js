
import * as tajweedService from './tajweedService.js';

/**
 * @desc    Analyze text for Tajweed rules
 * @route   POST /api/tajweed/analyze
 * @access  Protected
 */
export const analyze = async (req, res, next) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ error: "Text maydoni bo'sh bo'lmasligi kerak." });
    }

    const analysis = await tajweedService.analyzeTajweedText(text);

    res.status(200).json(analysis);
  } catch (error) {
    next(error);
  }
};
