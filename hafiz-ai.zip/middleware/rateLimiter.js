
// Fallback for environments without express-rate-limit installed 
// In a real project, run `npm install express-rate-limit`
// For now, providing a logic skeleton or assuming standard usage
import rateLimit from 'express-rate-limit';

export const analysisLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // limit each IP to 50 requests per windowMs
  message: {
    error: "Huda juda ko'p so'rov yuborildi. Iltimos, 15 daqiqadan so'ng qayta urinib ko'ring."
  },
  standardHeaders: true,
  legacyHeaders: false,
});
